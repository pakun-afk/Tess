plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.nullx.ppl"
    compileSdk = 35
    ndkVersion = "27.0.12077973"

    compileOptions {
        // ✅ DISAMAKAN KE JAVA 17 AGAR STABIL DENGAN SDK 35
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        // ✅ DISAMAKAN KE JAVA 17
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.nullx.ppl"
        minSdk = 23 
        targetSdk = 35
        
        // Menggunakan fallback jika flutter.version error
        versionCode = flutter.versionCode?.toInt() ?: 1
        versionName = flutter.versionName ?: "1.0.0"

        // ✅ TAMBAHKAN MULTIDEX (Penting karena banyak library media)
        multiDexEnabled = true
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            
            // ✅ OPTIMASI RELEASE
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

dependencies {
    // ✅ TAMBAHKAN MULTIDEX SUPPORT
    implementation("androidx.multidex:multidex:2.0.1")
}

flutter {
    source = "../.."
}
