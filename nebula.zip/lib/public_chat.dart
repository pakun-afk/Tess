import 'dart:convert';
import 'config_service.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:web_socket_channel/web_socket_channel.dart';

// wsUrl dari config_service.dart

class PublicChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  const PublicChatPage({super.key, required this.username, required this.sessionKey, required this.role});
  @override State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> with TickerProviderStateMixin {
  static const Color _red    = Color(0xFFB22222);
  static const Color _accent = Color(0xFFFF4444);
  static const Color _neon   = Color(0xFF00FF88);
  static const Color _cyan   = Color(0xFF00BFFF);
  static const Color _gold   = Color(0xFFFFD700);

  final TextEditingController _msgCtrl  = TextEditingController();
  final ScrollController       _scroll  = ScrollController();
  WebSocketChannel? _ws;

  List<Map<String, dynamic>> _messages = [];
  List<String> _onlineUsers = [];
  int  _onlineCount = 0;
  bool _connected   = false;
  bool _sending     = false;
  bool _showOnline  = false;
  Timer? _pingTimer;
  Timer? _reconnectTimer;

  late AnimationController _fadeCtrl;
  late Animation<double>   _fadeAnim;

  // role colors
  Color _roleColor(String? role) {
    switch (role) {
      case 'owner':     return _gold;
      case 'reseller':
      case 'reseller1': return _cyan;
      case 'vip':       return const Color(0xFFAA00FF);
      default:          return Colors.white70;
    }
  }
  Color _roleBg(String? role) => _roleColor(role).withOpacity(0.12);

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400))..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _connect();
  }

  void _connect() {
    _reconnectTimer?.cancel();
    try {
      _ws = WebSocketChannel.connect(Uri.parse('${wsBaseUrl}/ws?key=${widget.sessionKey}'));
      _ws!.stream.listen(
        _onMessage,
        onDone: _onDisconnect,
        onError: (_) => _onDisconnect(),
      );
      // join public chat
      Future.delayed(const Duration(milliseconds: 300), () {
        _send({'type': 'publicJoin'});
        _pingTimer = Timer.periodic(const Duration(seconds: 25), (_) => _send({'type': 'ping'}));
      });
    } catch (_) { _scheduleReconnect(); }
  }

  void _onDisconnect() {
    if (!mounted) return;
    setState(() => _connected = false);
    _pingTimer?.cancel();
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 4), () { if (mounted) _connect(); });
  }

  void _send(Map<String, dynamic> data) {
    try { _ws?.sink.add(jsonEncode(data)); } catch (_) {}
  }

  void _onMessage(dynamic raw) {
    if (!mounted) return;
    try {
      final data = jsonDecode(raw as String) as Map<String, dynamic>;
      final type = data['type'] as String?;

      if (type == 'publicHistory') {
        final msgs = List<Map<String, dynamic>>.from(data['messages'] ?? []);
        setState(() { _messages = msgs; _connected = true; });
        _scrollBottom();
      } else if (type == 'publicMessage') {
        setState(() { _messages.add(data); _connected = true; });
        _scrollBottom();
      } else if (type == 'publicSystem') {
        setState(() {
          _messages.add({'type': 'system', 'message': data['message'], 'time': DateTime.now().toIso8601String()});
        });
        _scrollBottom();
      } else if (type == 'publicOnline') {
        setState(() {
          _onlineCount = data['count'] ?? 0;
          _onlineUsers = List<String>.from(data['users'] ?? []);
          _connected   = true;
        });
      } else if (type == 'authOk') {
        setState(() => _connected = true);
        _send({'type': 'publicJoin'});
      }
    } catch (_) {}
  }

  void _scrollBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  void _sendMessage() {
    final msg = _msgCtrl.text.trim();
    if (msg.isEmpty || _sending) return;
    setState(() => _sending = true);
    _send({'type': 'publicMessage', 'message': msg});
    _msgCtrl.clear();
    setState(() => _sending = false);
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _pingTimer?.cancel();
    _reconnectTimer?.cancel();
    _send({'type': 'publicLeave'});
    _ws?.sink.close();
    super.dispose();
  }

  String _fmtTime(String? iso) {
    if (iso == null) return '';
    try {
      final dt = DateTime.parse(iso).toLocal();
      final h  = dt.hour.toString().padLeft(2,'0');
      final m  = dt.minute.toString().padLeft(2,'0');
      return '$h:$m';
    } catch (e) { return ''; }
  }

  bool _isMe(String? from) => from == widget.username;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Container(decoration: BoxDecoration(
          gradient: RadialGradient(center: Alignment.topCenter, radius: 1.4,
            colors: [_red.withOpacity(0.10), Colors.black]))),
        SafeArea(child: FadeTransition(opacity: _fadeAnim, child: Column(children: [
          _buildHeader(),
          if (_showOnline) _buildOnlinePanel(),
          Expanded(child: _buildMessages()),
          _buildInput(),
        ]))),
      ]),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        border: Border(bottom: BorderSide(color: _accent.withOpacity(0.2)))),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(width: 38, height: 38,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), borderRadius: BorderRadius.circular(10), border: Border.all(color: _accent.withOpacity(0.3))),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 15))),
        const SizedBox(width: 12),
        Container(width: 42, height: 42,
          decoration: BoxDecoration(shape: BoxShape.circle, color: _neon.withOpacity(0.1), border: Border.all(color: _neon.withOpacity(0.5))),
          child: const Icon(Icons.forum_rounded, color: Color(0xFF00FF88), size: 20)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Text('PUBLIC CHAT', style: TextStyle(fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 1.5, shadows: [Shadow(color: Color(0xFF00FF88), blurRadius: 10)])),
            const SizedBox(width: 6),
            Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: _connected ? _neon : Colors.red, boxShadow: [BoxShadow(color: _connected ? _neon : Colors.red, blurRadius: 4)])),
          ]),
          Text('${_onlineCount} online', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _neon.withOpacity(0.7))),
        ])),
        GestureDetector(
          onTap: () => setState(() => _showOnline = !_showOnline),
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: _cyan.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: _cyan.withOpacity(0.3))),
            child: Row(children: [
              Icon(Icons.people_rounded, color: _cyan, size: 14),
              const SizedBox(width: 4),
              Text('$_onlineCount', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _cyan)),
            ]))),
      ]),
    );
  }

  Widget _buildOnlinePanel() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 0),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _cyan.withOpacity(0.25))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('🟢 Online (${_onlineUsers.length})', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: Color(0xFF00BFFF))),
        const SizedBox(height: 6),
        Wrap(spacing: 6, runSpacing: 4, children: _onlineUsers.map((u) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(color: _cyan.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: _cyan.withOpacity(0.3))),
          child: Text(u, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: u == widget.username ? _neon : Colors.white70)))).toList()),
      ]),
    );
  }

  Widget _buildMessages() {
    if (_messages.isEmpty && _connected) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.chat_bubble_outline, color: _neon.withOpacity(0.3), size: 48),
        const SizedBox(height: 12),
        Text('Belum ada pesan.\nJadi yang pertama ngobrol!', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: Colors.white.withOpacity(0.3))),
      ]));
    }
    if (!_connected && _messages.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const CircularProgressIndicator(color: Color(0xFFFF4444), strokeWidth: 2),
        const SizedBox(height: 12),
        Text('Menghubungkan...', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white38)),
      ]));
    }
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      itemCount: _messages.length,
      itemBuilder: (_, i) {
        final msg = _messages[i];
        if (msg['type'] == 'system') return _buildSystemMsg(msg);
        return _buildChatBubble(msg);
      },
    );
  }

  Widget _buildSystemMsg(Map<String, dynamic> msg) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), borderRadius: BorderRadius.circular(20)),
        child: Text(msg['message'] ?? '', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: Colors.white38))),
    );
  }

  Widget _buildChatBubble(Map<String, dynamic> msg) {
    final from  = msg['from'] as String? ?? '';
    final me    = _isMe(from);
    final role  = msg['role'] as String? ?? 'member';
    final emoji = msg['roleEmoji'] as String? ?? '👤';
    final time  = _fmtTime(msg['time'] as String?);
    final text  = msg['message'] as String? ?? '';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: me ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!me) ...[
            Container(width: 30, height: 30, margin: const EdgeInsets.only(right: 6),
              decoration: BoxDecoration(shape: BoxShape.circle, color: _roleColor(role).withOpacity(0.15), border: Border.all(color: _roleColor(role).withOpacity(0.4))),
              child: Center(child: Text(emoji, style: const TextStyle(fontSize: 13)))),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
              decoration: BoxDecoration(
                color: me ? _accent.withOpacity(0.18) : Colors.white.withOpacity(0.07),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(me ? 16 : 4), bottomRight: Radius.circular(me ? 4 : 16)),
                border: Border.all(color: (me ? _accent : _roleColor(role)).withOpacity(0.3))),
              child: Column(crossAxisAlignment: me ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
                if (!me) Row(children: [
                  Text(from, style: TextStyle(fontFamily: 'Orbitron', fontSize: 10, color: _roleColor(role), fontWeight: FontWeight.bold)),
                  const SizedBox(width: 4),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                    decoration: BoxDecoration(color: _roleColor(role).withOpacity(0.15), borderRadius: BorderRadius.circular(4)),
                    child: Text(role.toUpperCase(), style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 7, color: _roleColor(role)))),
                ]),
                if (!me) const SizedBox(height: 3),
                Text(text, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: Colors.white.withOpacity(0.87))),
                const SizedBox(height: 3),
                Text(time, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white38)),
              ]),
            ),
          ),
          if (me) const SizedBox(width: 6),
        ],
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        border: Border(top: BorderSide(color: _accent.withOpacity(0.2)))),
      child: Row(children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.07),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _accent.withOpacity(0.3))),
            child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 13, color: Colors.white),
              maxLines: 1,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _sendMessage(),
              decoration: InputDecoration(
                hintText: _connected ? 'Tulis pesan...' : 'Menghubungkan...',
                hintStyle: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: Colors.white30),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: InputBorder.none),
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _sendMessage,
          child: Container(width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [_red, _accent]),
              boxShadow: [BoxShadow(color: _accent.withOpacity(0.4), blurRadius: 12)]),
            child: const Icon(Icons.send_rounded, color: Colors.white, size: 18)),
        ),
      ]),
    );
  }
}
