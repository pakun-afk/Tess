import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class QuizBattlePage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String roomId;
  final String opponent;
  final WebSocketChannel wsChannel;
  const QuizBattlePage({super.key, required this.username, required this.sessionKey, required this.roomId, required this.opponent, required this.wsChannel});
  @override State<QuizBattlePage> createState() => _QuizBattlePageState();
}

class _QuizBattlePageState extends State<QuizBattlePage> with TickerProviderStateMixin {
  static const Color _red  = Color(0xFFB22222);
  static const Color _acc  = Color(0xFFFF4444);
  static const Color _neon = Color(0xFF00FF88);
  static const Color _gold = Color(0xFFFFD700);
  static const Color _cyan = Color(0xFF00BFFF);

  // Question state
  String  _question  = '';
  List<String> _options = [];
  int _qIndex  = 0;
  int _total   = 10;
  int _timeLeft = 15;
  int? _myAnswer;
  int? _correctAnswer;
  int? _hostAnswer;
  int? _guestAnswer;
  bool _answered  = false;
  bool _showResult = false;

  // Score
  int _myScore   = 0;
  int _oppScore  = 0;
  bool _gameOver = false;
  String? _winner;
  bool _opponentLeft = false;

  // Game state
  bool _waiting = true;   // waiting for first question
  StreamSubscription? _sub;
  Timer? _timer;
  late AnimationController _barCtrl;
  late AnimationController _ansCtrl;
  late Animation<double>   _barAnim;
  late Animation<double>   _ansAnim;

  bool get _isHost => widget.username == widget.username; // both have role, server decides

  @override
  void initState() {
    super.initState();
    _barCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 15));
    _ansCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _barAnim = CurvedAnimation(parent: _barCtrl, curve: Curves.linear);
    _ansAnim = CurvedAnimation(parent: _ansCtrl, curve: Curves.elasticOut);
    _sub = widget.wsChannel.stream.listen(_onMessage);
  }

  @override
  void dispose() {
    _barCtrl.dispose(); _ansCtrl.dispose();
    _timer?.cancel(); _sub?.cancel();
    super.dispose();
  }

  void _onMessage(dynamic raw) {
    if (!mounted) return;
    try {
      final data = jsonDecode(raw as String) as Map<String, dynamic>;
      final type = data['type'] as String? ?? '';

      if (type == 'quizQuestion' && data['roomId'] == widget.roomId) {
        _timer?.cancel();
        setState(() {
          _waiting = false;
          _question = data['q'] as String? ?? '';
          _options  = List<String>.from(data['options'] ?? []);
          _qIndex   = data['qIndex'] as int? ?? 0;
          _total    = data['total']  as int? ?? 10;
          _timeLeft = data['timeLimit'] as int? ?? 15;
          _myAnswer = null; _correctAnswer = null;
          _hostAnswer = null; _guestAnswer = null;
          _answered = false; _showResult = false;
        });
        _barCtrl.duration = Duration(seconds: _timeLeft);
        _barCtrl.forward(from: 0);
        _timer = Timer.periodic(const Duration(seconds: 1), (_) {
          if (!mounted) return;
          setState(() => _timeLeft--);
          if (_timeLeft <= 0) { _timer?.cancel(); setState(() { _answered = true; }); }
        });
      }

      else if (type == 'quizResult' && data['roomId'] == widget.roomId) {
        _timer?.cancel();
        _barCtrl.stop();
        final scores = data['scores'] as Map<String, dynamic>? ?? {};
        _ansCtrl.forward(from: 0);
        setState(() {
          _answered    = true;
          _showResult  = true;
          _correctAnswer = data['correct'] as int?;
          _hostAnswer  = data['hostAnswer']  as int?;
          _guestAnswer = data['guestAnswer'] as int?;
          _myScore  = (scores[widget.username] ?? 0) as int;
          _oppScore = (scores[widget.opponent] ?? 0) as int;
        });
      }

      else if (type == 'quizOver' && data['roomId'] == widget.roomId) {
        _timer?.cancel();
        final scores = data['scores'] as Map<String, dynamic>? ?? {};
        final w = data['winner'] as String?;
        setState(() {
          _gameOver = true; _winner  = w;
          _myScore  = (scores[widget.username] ?? 0) as int;
          _oppScore = (scores[widget.opponent] ?? 0) as int;
        });
        _showGameOverDialog();
      }

      else if (type == 'opponentLeft' && data['roomId'] == widget.roomId) {
        _timer?.cancel();
        setState(() { _opponentLeft = true; _gameOver = true; _winner = widget.username; });
        _showGameOverDialog();
      }
    } catch (_) {}
  }

  void _answer(int i) {
    if (_answered) return;
    _timer?.cancel();
    _barCtrl.stop();
    setState(() { _myAnswer = i; _answered = true; });
    widget.wsChannel.sink.add(jsonEncode({'type': 'quizAnswer', 'roomId': widget.roomId, 'answer': i, 'qIndex': _qIndex}));
  }

  void _showGameOverDialog() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final isWin  = _winner == widget.username;
      final isDraw = _winner == null && !_opponentLeft;
      showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        title: Text(_opponentLeft?'🏆 Lawan keluar!':isWin?'🏆 MENANG!':isDraw?'🤝 SERI!':'😞 KALAH', textAlign: TextAlign.center, style: TextStyle(fontFamily:'Orbitron',fontSize:16,color:isWin||_opponentLeft?_gold:isDraw?Colors.white:_acc)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(_opponentLeft?'Lawan keluar dari quiz!':isWin?'Kamu menang quiz!':isDraw?'Nilai sama!':'${widget.opponent} menang!', textAlign:TextAlign.center, style:const TextStyle(fontFamily:'ShareTechMono',fontSize:11,color:Colors.white70)),
          const SizedBox(height:12),
          Row(mainAxisAlignment:MainAxisAlignment.center,children:[
            _finalScore(widget.username, _myScore, isWin||_opponentLeft, _gold),
            const SizedBox(width:20),
            _finalScore(widget.opponent, _oppScore, !isWin&&!isDraw&&!_opponentLeft, _acc),
          ]),
        ]),
        actions: [TextButton(onPressed:(){Navigator.pop(context);Navigator.pop(context);}, child:const Text('KELUAR',style:TextStyle(color:Color(0xFFFF4444),fontFamily:'Orbitron',fontSize:11)))],
      ));
    });
  }

  Widget _finalScore(String name, int score, bool isWinner, Color color) {
    return Column(children:[
      Text(name,style:TextStyle(fontFamily:'ShareTechMono',fontSize:10,color:isWinner?color:Colors.white38)),
      Text('$score',style:TextStyle(fontFamily:'Orbitron',fontSize:24,color:isWinner?color:Colors.white38,fontWeight:FontWeight.bold)),
      Text('poin',style:const TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:Colors.white24)),
    ]);
  }

  Color _optionColor(int i) {
    if (!_showResult) {
      return _myAnswer == i ? _acc.withOpacity(0.2) : Colors.white.withOpacity(0.05);
    }
    if (i == _correctAnswer) return _neon.withOpacity(0.25);
    if (_myAnswer == i && _myAnswer != _correctAnswer) return _acc.withOpacity(0.2);
    return Colors.white.withOpacity(0.03);
  }

  Color _optionBorder(int i) {
    if (!_showResult) return _myAnswer == i ? _acc.withOpacity(0.6) : Colors.white.withOpacity(0.12);
    if (i == _correctAnswer) return _neon.withOpacity(0.7);
    if (_myAnswer == i && _myAnswer != _correctAnswer) return _acc.withOpacity(0.5);
    return Colors.white.withOpacity(0.12);
  }

  @override
  Widget build(BuildContext context) {
    if (_waiting) return _buildWaiting();
    return _buildGame();
  }

  Widget _buildWaiting() {
    return Scaffold(backgroundColor: Colors.black, body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const CircularProgressIndicator(color: Color(0xFFFF4444), strokeWidth: 2),
      const SizedBox(height: 16),
      const Text('⏳ Quiz akan segera dimulai...', style: TextStyle(fontFamily: 'Orbitron', fontSize: 13, color: Colors.white)),
      const SizedBox(height: 6),
      Text('vs ${widget.opponent}', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white38)),
    ])));
  }

  Widget _buildGame() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Container(decoration: BoxDecoration(gradient: RadialGradient(center: Alignment.topCenter, radius: 1.3, colors: [_red.withOpacity(0.1), Colors.black]))),
        SafeArea(child: Column(children: [
          _buildHeader(),
          const SizedBox(height: 8),
          _buildTimerBar(),
          const SizedBox(height: 12),
          _buildScores(),
          const SizedBox(height: 16),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(16), border: Border.all(color: _acc.withOpacity(0.25))),
            child: Column(children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(color: _acc.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                child: Text('Soal ${_qIndex + 1} / $_total', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: Color(0xFFFF4444)))),
              Text(_question, textAlign: TextAlign.center, style: const TextStyle(fontFamily: 'Orbitron', fontSize: 14, color: Colors.white, fontWeight: FontWeight.bold, height: 1.5)),
            ]),
          )),
          const SizedBox(height: 14),
          Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 2.4, crossAxisSpacing: 10, mainAxisSpacing: 10),
            itemCount: _options.length,
            itemBuilder: (_, i) {
              final letters = ['A','B','C','D'];
              return GestureDetector(
                onTap: _answered ? null : () => _answer(i),
                child: AnimatedContainer(duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: _optionColor(i), borderRadius: BorderRadius.circular(12), border: Border.all(color: _optionBorder(i))),
                  child: Row(children: [
                    Container(width: 22, height: 22, decoration: BoxDecoration(shape: BoxShape.circle, color: _optionBorder(i).withOpacity(0.2), border: Border.all(color: _optionBorder(i))),
                      child: Center(child: Text(letters[i], style: TextStyle(fontFamily: 'Orbitron', fontSize: 9, color: _optionBorder(i), fontWeight: FontWeight.bold)))),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_options[i], style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white))),
                    if (_showResult && i == _correctAnswer) const Text('✓', style: TextStyle(color: Color(0xFF00FF88), fontSize: 14, fontWeight: FontWeight.bold)),
                    if (_showResult && _myAnswer == i && _myAnswer != _correctAnswer) const Text('✗', style: TextStyle(color: Color(0xFFFF4444), fontSize: 14, fontWeight: FontWeight.bold)),
                  ])),
              );
            },
          ))),
          if (_showResult) _buildResultRow(),
          const SizedBox(height: 8),
        ])),
      ]),
    );
  }

  Widget _buildHeader() {
    return Padding(padding: const EdgeInsets.fromLTRB(12,12,12,0), child: Row(children: [
      GestureDetector(
        onTap: () { widget.wsChannel.sink.add(jsonEncode({'type':'roomLeave','roomId':widget.roomId})); Navigator.pop(context); },
        child: Container(width:36,height:36,decoration:BoxDecoration(color:Colors.white.withOpacity(0.07),borderRadius:BorderRadius.circular(10),border:Border.all(color:_acc.withOpacity(0.3))),child:Icon(Icons.arrow_back_ios_new,color:Colors.white,size:14))),
      const SizedBox(width:10),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('QUIZ BATTLE',style:TextStyle(fontFamily:'Orbitron',fontSize:14,color:Colors.white,letterSpacing:1.5,shadows:[Shadow(color:Color(0xFF00FF88),blurRadius:10)])),
        Text('vs ${widget.opponent}',style:const TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:Colors.white38)),
      ]),
      const Spacer(),
      Container(padding:EdgeInsets.symmetric(horizontal:10,vertical:4),decoration:BoxDecoration(color:_gold.withOpacity(0.1),borderRadius:BorderRadius.circular(8),border:Border.all(color:_gold.withOpacity(0.4))),
        child:Text('⏱ $_timeLeft',style:TextStyle(fontFamily:'Orbitron',fontSize:12,color:_timeLeft<=5?_acc:_gold))),
    ]));
  }

  Widget _buildTimerBar() {
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: AnimatedBuilder(
      animation: _barAnim,
      builder: (_, __) => LinearProgressIndicator(
        value: 1 - _barAnim.value,
        backgroundColor: Colors.white.withOpacity(0.12),
        color: _timeLeft <= 5 ? _acc : _neon,
        minHeight: 4,
      ),
    ));
  }

  Widget _buildScores() {
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Row(children: [
      _scoreChip(widget.username, _myScore, _cyan, true),
      const Spacer(),
      Text('${_qIndex + 1}/$_total', style: const TextStyle(fontFamily: 'Orbitron', fontSize: 11, color: Colors.white38)),
      const Spacer(),
      _scoreChip(widget.opponent, _oppScore, _neon, false),
    ]));
  }

  Widget _scoreChip(String name, int score, Color c, bool isMe) {
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: c.withOpacity(0.3))),
      child: Row(children: [
        Text('$score', style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, color: c, fontWeight: FontWeight.bold)),
        const SizedBox(width: 6),
        Text(isMe ? 'KAMU' : name, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white38)),
      ]));
  }

  Widget _buildResultRow() {
    final myAnswerText = _myAnswer != null && _myAnswer! < _options.length ? _options[_myAnswer!] : 'Timeout';
    final oppAnswer    = widget.username == widget.username /* host check */ ? _guestAnswer : _hostAnswer;
    final oppAnswerText = oppAnswer != null && oppAnswer >= 0 && oppAnswer < _options.length ? _options[oppAnswer] : 'Timeout';
    final myCorrect   = _myAnswer == _correctAnswer;
    return Padding(padding: const EdgeInsets.fromLTRB(14, 4, 14, 4), child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.12))),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Jawaban kamu', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white38)),
          Text(myAnswerText, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: myCorrect ? _neon : _acc)),
        ]),
        Text(myCorrect ? '+1 ✓' : '0 ✗', style: TextStyle(fontFamily: 'Orbitron', fontSize: 13, color: myCorrect ? _neon : _acc)),
      ]),
    ));
  }
}
