import 'dart:convert';
import 'config_service.dart';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'welcome_screen.dart';
import 'debug_page.dart';

// baseUrl dari config_service.dart (dynamic)

class _Particle {
  double x, y, size, speed, opacity;
  _Particle({required this.x, required this.y, required this.size, required this.speed, required this.opacity});
}

class _ParticlePainter extends CustomPainter {
  final List<_Particle> particles;
  final Color color;
  _ParticlePainter(this.particles, this.color);
  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      canvas.drawCircle(
        Offset(p.x * size.width, p.y * size.height),
        p.size,
        Paint()..color = color.withOpacity(p.opacity),
      );
    }
  }
  @override
  bool shouldRepaint(_ParticlePainter old) => true;
}

class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter(this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color.withOpacity(0.06)..strokeWidth = 0.5;
    const sp = 35.0;
    for (double x = 0; x < size.width; x += sp) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += sp) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }
  @override
  bool shouldRepaint(_GridPainter old) => false;
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _particleController;
  late AnimationController _cardController;
  late AnimationController _logoController;
  late AnimationController _glowController;
  late Animation<double> _cardFade;
  late Animation<Offset> _cardSlide;
  late Animation<double> _logoScale;
  late Animation<double> _glowAnim;

  final _random = Random();
  late List<_Particle> _particles;

  static const Color _primary = Color(0xFFB22222);
  static const Color _accent = Color(0xFFFF4444);
  static const Color _neon = Color(0xFF00FF88);

  @override
  void initState() {
    super.initState();
    _particles = List.generate(50, (i) => _Particle(
      x: _random.nextDouble(), y: _random.nextDouble(),
      size: _random.nextDouble() * 2 + 0.5,
      speed: _random.nextDouble() * 0.002 + 0.0005,
      opacity: _random.nextDouble() * 0.4 + 0.1,
    ));

    _particleController = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();
    _particleController.addListener(() {
      setState(() {
        for (final p in _particles) {
          p.y -= p.speed;
          if (p.y < 0) { p.y = 1.0; p.x = _random.nextDouble(); }
        }
      });
    });

    _cardController = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _cardFade = CurvedAnimation(parent: _cardController, curve: Curves.easeOut);
    _cardSlide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _cardController, curve: Curves.easeOutCubic));

    _logoController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..forward();
    _logoScale = CurvedAnimation(parent: _logoController, curve: Curves.elasticOut);

    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _glowAnim = CurvedAnimation(parent: _glowController, curve: Curves.easeInOut);

    _initLogin();
  }

  Future<void> _initLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");
    if (savedUser != null && savedPass != null && savedKey != null) {
      try {
        final uri = Uri.parse("$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => WelcomeScreen(
            username: savedUser, password: savedPass,
            role: data['role'], sessionKey: data['key'],
            expiredDate: data['expiredDate'],
            listBug: (data['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
            listDoos: (data['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
            news: (data['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          )));
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      return android.id;
    } catch (_) { return "unknown_device"; }
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => isLoading = true);
    try {
      // Pastikan baseUrl sudah siap dari Gist
      if (baseUrl.isEmpty) {
        if (mounted) _showError("Server sedang diinisialisasi, tunggu sebentar lalu coba lagi...");
        // Coba fetch ulang config
        await ConfigService().fetchConfig();
        if (baseUrl.isEmpty) {
          if (mounted) {
            setState(() => isLoading = false);
            _showError("Tidak dapat menghubungi server. Cek koneksi internet kamu.");
          }
          return;
        }
      }

      final uri = Uri.parse("$baseUrl/login?username=${userController.text.trim()}&password=${passController.text.trim()}&androidId=$androidId");
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString("username", userController.text.trim());
        await prefs.setString("password", passController.text.trim());
        await prefs.setString("key", data['key']);
        if (mounted) {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => WelcomeScreen(
            username: userController.text.trim(), password: passController.text.trim(),
            role: data['role'], sessionKey: data['key'],
            expiredDate: data['expiredDate'],
            listBug: (data['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
            listDoos: (data['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
            news: (data['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          )));
        }
      } else {
        if (mounted) _showError(data['message'] ?? "Login gagal. Cek username & password.");
      }
    } on Exception catch (e) {
      if (mounted) {
        final msg = e.toString();
        if (msg.contains('TimeoutException') || msg.contains('timeout')) {
          _showError("Server timeout. Cek koneksi & coba lagi.");
        } else if (msg.contains('SocketException') || msg.contains('Connection refused')) {
          _showError("Tidak dapat menghubungi server. Pastikan server aktif.");
        } else {
          _showError("Koneksi gagal: ${msg.replaceAll('Exception: ', '')}");
        }
      }
    }
    if (mounted) setState(() => isLoading = false);
  }

  // Buka debug page (tap 5x logo)
int _debugTapCount = 0;
void _onDebugTap() {
  _debugTapCount++;
  if (_debugTapCount >= 5) {
    _debugTapCount = 0;
    Navigator.push(context, MaterialPageRoute(builder: (_) => const DebugPage()));
  }
}

void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Icons.error_outline, color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: _primary,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  @override
  void dispose() {
    _particleController.dispose();
    _cardController.dispose();
    _logoController.dispose();
    _glowController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _accent, letterSpacing: 2)),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          obscureText: isPassword ? _obscurePassword : false,
          style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
          validator: validator,
          decoration: InputDecoration(
            prefixIcon: Icon(icon, color: _accent.withOpacity(0.7), size: 18),
            suffixIcon: isPassword ? IconButton(
              icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility, color: Colors.white38, size: 18),
              onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
            ) : null,
            filled: true,
            fillColor: Colors.white.withOpacity(0.05),
            hintText: isPassword ? "••••••••" : "Masukkan username",
            hintStyle: const TextStyle(color: Colors.white24, fontSize: 13),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _accent.withOpacity(0.2))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: _accent.withOpacity(0.2))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _accent, width: 1.5)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Colors.red)),
            focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Colors.red, width: 1.5)),
            errorStyle: const TextStyle(color: Colors.redAccent, fontSize: 10),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          CustomPaint(painter: _GridPainter(_accent), size: size),
          Container(decoration: BoxDecoration(gradient: RadialGradient(
            center: Alignment.topCenter, radius: 1.2,
            colors: [_primary.withOpacity(0.25), Colors.black.withOpacity(0.85), Colors.black],
          ))),
          AnimatedBuilder(animation: _glowAnim, builder: (_, __) => Positioned(
            top: -80, left: -80,
            child: Container(width: 300, height: 300, decoration: BoxDecoration(shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _primary.withOpacity(0.15 + _glowAnim.value * 0.1), blurRadius: 120, spreadRadius: 60)])),
          )),
          AnimatedBuilder(animation: _glowAnim, builder: (_, __) => Positioned(
            bottom: -60, right: -60,
            child: Container(width: 250, height: 250, decoration: BoxDecoration(shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _neon.withOpacity(0.05 + _glowAnim.value * 0.07), blurRadius: 100, spreadRadius: 40)])),
          )),
          CustomPaint(painter: _ParticlePainter(_particles, _accent), size: size),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Logo
                    GestureDetector(
                      onTap: _onDebugTap,
                      child: ScaleTransition(
                      scale: _logoScale,
                      child: Column(children: [
                        AnimatedBuilder(animation: _glowAnim, builder: (_, __) => Container(
                          width: 90, height: 90,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: _accent.withOpacity(0.6 + _glowAnim.value * 0.4), width: 2),
                            boxShadow: [BoxShadow(color: _primary.withOpacity(0.4 + _glowAnim.value * 0.3), blurRadius: 30 + _glowAnim.value * 20, spreadRadius: 5)],
                            image: const DecorationImage(image: AssetImage('assets/images/logo.jpg'), fit: BoxFit.cover),
                          ),
                        )),
                        const SizedBox(height: 16),
                        AnimatedBuilder(animation: _glowAnim, builder: (_, __) => Text("BTR APPS", style: TextStyle(
                          fontFamily: 'Orbitron', fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 4,
                          shadows: [Shadow(color: _accent.withOpacity(0.5 + _glowAnim.value * 0.5), blurRadius: 20 + _glowAnim.value * 15)],
                        ))),
                        const SizedBox(height: 6),
                        Text("SISTEM AKSES TERENKRIPSI", style: TextStyle(
                          fontFamily: 'ShareTechMono', fontSize: 10, color: _neon.withOpacity(0.7), letterSpacing: 2)),
                      ]),
                    )),

                    const SizedBox(height: 36),

                    // Login Card
                    FadeTransition(
                      opacity: _cardFade,
                      child: SlideTransition(
                        position: _cardSlide,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(28),
                          child: BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                            child: AnimatedBuilder(animation: _glowAnim, builder: (_, __) => Container(
                              padding: const EdgeInsets.all(28),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.04),
                                borderRadius: BorderRadius.circular(28),
                                border: Border.all(color: _accent.withOpacity(0.2 + _glowAnim.value * 0.15), width: 1.5),
                                boxShadow: [BoxShadow(color: _primary.withOpacity(0.15 + _glowAnim.value * 0.1), blurRadius: 40, spreadRadius: 5)],
                              ),
                              child: Form(
                                key: _formKey,
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    Container(width: 4, height: 20, decoration: BoxDecoration(
                                      color: _accent, borderRadius: BorderRadius.circular(4),
                                      boxShadow: [const BoxShadow(color: _accent, blurRadius: 8)],
                                    )),
                                    const SizedBox(width: 10),
                                    const Text("AUTENTIKASI", style: TextStyle(fontFamily: 'Orbitron', fontSize: 13, color: Colors.white70, letterSpacing: 2)),
                                  ]),
                                  const SizedBox(height: 24),
                                  _buildInputField(
                                    controller: userController, label: "USERNAME", icon: Icons.person_outline,
                                    validator: (v) => (v == null || v.isEmpty) ? "Username wajib diisi" : null,
                                  ),
                                  const SizedBox(height: 16),
                                  _buildInputField(
                                    controller: passController, label: "PASSWORD", icon: Icons.lock_outline,
                                    isPassword: true,
                                    validator: (v) => (v == null || v.isEmpty) ? "Password wajib diisi" : null,
                                  ),
                                  const SizedBox(height: 28),
                                  SizedBox(
                                    width: double.infinity, height: 52,
                                    child: GestureDetector(
                                      onTap: isLoading ? null : _login,
                                      child: AnimatedScale(
                                        scale: isLoading ? 0.97 : 1.0,
                                        duration: const Duration(milliseconds: 150),
                                        child: AnimatedBuilder(
                                          animation: _glowAnim,
                                          builder: (_, __) => Container(
                                            decoration: BoxDecoration(
                                              gradient: const LinearGradient(
                                                colors: [_primary, Color(0xFFFF4444), _primary],
                                                begin: Alignment.centerLeft,
                                                end: Alignment.centerRight,
                                              ),
                                              borderRadius: BorderRadius.circular(16),
                                              boxShadow: [BoxShadow(
                                                color: _primary.withOpacity(0.5 + _glowAnim.value * 0.3),
                                                blurRadius: 20 + _glowAnim.value * 10,
                                                spreadRadius: 2,
                                              )],
                                            ),
                                            child: Center(
                                              child: isLoading
                                                ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                    const SizedBox(width: 18, height: 18,
                                                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                                                    const SizedBox(width: 10),
                                                    const Text("MEMVERIFIKASI...",
                                                      style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white, fontSize: 13, letterSpacing: 1)),
                                                  ])
                                                : const Text("MASUK SISTEM",
                                                    style: TextStyle(fontFamily: 'Orbitron', color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 2)),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ]),
                              ),
                            )),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 10),

                    // ─── Connection Status + Debug Button ────────
                    ListenableBuilder(
                      listenable: cfg,
                      builder: (_, __) => GestureDetector(
                        onTap: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => const DebugPage())),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 400),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: cfg.statusColor.withOpacity(0.07),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: cfg.statusColor.withOpacity(0.3))),
                          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            AnimatedContainer(duration: const Duration(milliseconds: 400),
                              width: 8, height: 8,
                              decoration: BoxDecoration(shape: BoxShape.circle, color: cfg.statusColor,
                                boxShadow: [BoxShadow(color: cfg.statusColor, blurRadius: 6)])),
                            const SizedBox(width: 8),
                            Text(cfg.connMsg,
                              style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: cfg.statusColor)),
                            const SizedBox(width: 8),
                            Icon(Icons.bug_report_outlined, size: 13, color: cfg.statusColor.withOpacity(0.7)),
                          ]),
                        ),
                      ),
                    ),

                    const SizedBox(height: 14),

                    FadeTransition(
                      opacity: _cardFade,
                      child: GestureDetector(
                        onTap: () async {
                          final uri = Uri.parse("https://t.me/none");
                          if (await canLaunchUrl(uri)) launchUrl(uri, mode: LaunchMode.externalApplication);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.04),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: _neon.withOpacity(0.3)),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.shopping_cart_outlined, color: _neon, size: 16),
                            const SizedBox(width: 8),
                            const Text("BELI AKSES → @none", style: TextStyle(fontFamily: 'ShareTechMono', color: _neon, fontSize: 12, letterSpacing: 1)),
                          ]),
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),
                    Text("v2.0.0 — ENGINE NEW", style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white.withOpacity(0.2), letterSpacing: 2)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
