import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:web_socket_channel/web_socket_channel.dart';

class ChessGamePage extends StatefulWidget {
  final String  username;
  final String  sessionKey;
  final String  roomId;
  final String  opponent;
  final bool    myTurn;
  final String  myColor;
  final List<List<String>>? initialBoard;
  final WebSocketChannel wsChannel;
  const ChessGamePage({super.key, required this.username, required this.sessionKey, required this.roomId, required this.opponent, required this.myTurn, required this.myColor, this.initialBoard, required this.wsChannel});
  @override State<ChessGamePage> createState() => _ChessGamePageState();
}

class _ChessGamePageState extends State<ChessGamePage> with TickerProviderStateMixin {
  static const Color _red   = Color(0xFFB22222);
  static const Color _acc   = Color(0xFFFF4444);
  static const Color _gold  = Color(0xFFFFD700);
  static const Color _neon  = Color(0xFF00FF88);

  late List<List<String>> board;
  late bool myTurn;
  int? selR, selC;
  List<List<int>> validMoves = [];
  String status = '';
  bool gameOver = false;
  List<String> capturedByMe = [], capturedByOpp = [];
  String? winner;
  bool opponentLeft = false;
  StreamSubscription? _sub;
  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  bool get isWhite => widget.myColor == 'white';
  bool _isW(String p) => p.isNotEmpty && p == p.toUpperCase();
  bool _isB(String p) => p.isNotEmpty && p == p.toLowerCase();
  bool _mine(String p) => isWhite ? _isW(p) : _isB(p);
  bool _opp(String p)  => isWhite ? _isB(p) : _isW(p);

  @override
  void initState() {
    super.initState();
    board  = widget.initialBoard ?? _initBoard();
    myTurn = widget.myTurn;
    status = myTurn ? '⚔️ Giliranmu!' : '⏳ Menunggu ${widget.opponent}...';
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
    _glow = CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut);
    _sub = widget.wsChannel.stream.listen(_onMessage);
  }

  List<List<String>> _initBoard() => [
    ['r','n','b','q','k','b','n','r'],
    ['p','p','p','p','p','p','p','p'],
    ['','','','','','','',''],['','','','','','','',''],
    ['','','','','','','',''],['','','','','','','',''],
    ['P','P','P','P','P','P','P','P'],
    ['R','N','B','Q','K','B','N','R'],
  ];

  void _onMessage(dynamic raw) {
    if (!mounted) return;
    try {
      final data = jsonDecode(raw as String) as Map<String, dynamic>;
      final type = data['type'] as String? ?? '';
      if (type == 'gameMove' && data['roomId'] == widget.roomId) {
        final move = data['move'] as Map<String, dynamic>;
        setState(() {
          board  = List<List<String>>.from((move['board'] as List).map((r) => List<String>.from(r as List)));
          myTurn = true;
          status = '⚔️ Giliranmu!';
        });
      } else if (type == 'gameOver' && data['roomId'] == widget.roomId) {
        final w = data['winner'] as String?;
        setState(() { gameOver = true; winner = w; status = w == widget.username ? '🏆 KAMU MENANG!' : w == null ? '🤝 SERI!' : '😞 KAMU KALAH'; });
        _showGameOverDialog();
      } else if (type == 'opponentLeft' && data['roomId'] == widget.roomId) {
        setState(() { opponentLeft = true; gameOver = true; winner = widget.username; status = '🏆 Lawan keluar — Kamu menang!'; });
        _showGameOverDialog();
      }
    } catch (_) {}
  }

  void _tap(int r, int c) {
    if (gameOver || !myTurn) return;
    // flip row for black player
    final actualR = isWhite ? r : 7 - r;
    final actualC = isWhite ? c : 7 - c;
    final p = board[actualR][actualC];
    if (selR == null) {
      if (!_mine(p)) return;
      setState(() { selR = actualR; selC = actualC; validMoves = _calcMoves(actualR, actualC, p); });
    } else {
      final ok = validMoves.any((m) => m[0] == actualR && m[1] == actualC);
      if (ok) {
        _doMove(selR!, selC!, actualR, actualC);
      } else if (_mine(p)) {
        setState(() { selR = actualR; selC = actualC; validMoves = _calcMoves(actualR, actualC, p); });
      } else {
        setState(() { selR = null; selC = null; validMoves = []; });
      }
    }
  }

  void _doMove(int fr, int fc, int tr, int tc) {
    final newBoard = board.map((r) => List<String>.from(r)).toList();
    final t = newBoard[tr][tc];
    if (t.isNotEmpty) {
      if (_isW(t)) capturedByOpp.add(t); else capturedByMe.add(t);
      if (t.toLowerCase() == 'k') {
        // notify server
        widget.wsChannel.sink.add(jsonEncode({'type': 'gameOver', 'roomId': widget.roomId, 'winner': widget.username, 'loser': widget.opponent}));
        setState(() { newBoard[tr][tc] = newBoard[fr][fc]; newBoard[fr][fc] = ''; board = newBoard; gameOver = true; winner = widget.username; status = '🏆 KAMU MENANG!'; selR=null; selC=null; validMoves=[]; });
        _showGameOverDialog(); return;
      }
    }
    String mv = newBoard[fr][fc];
    if (mv == 'P' && tr == 0) mv = 'Q';
    if (mv == 'p' && tr == 7) mv = 'q';
    newBoard[tr][tc] = mv; newBoard[fr][fc] = '';
    setState(() { board = newBoard; myTurn = false; selR=null; selC=null; validMoves=[]; status = '⏳ Giliran ${widget.opponent}...'; });
    widget.wsChannel.sink.add(jsonEncode({'type': 'gameMove', 'roomId': widget.roomId, 'move': {'board': newBoard, 'fr': fr, 'fc': fc, 'tr': tr, 'tc': tc}}));
  }

  List<List<int>> _calcMoves(int r, int c, String p) {
    final moves = <List<int>>[];
    final pt = p.toLowerCase();
    void add(int r2, int c2) { if (r2>=0&&r2<8&&c2>=0&&c2<8&&!_mine(board[r2][c2])) moves.add([r2,c2]); }
    void slide(List<List<int>> dirs, {int max=7}) { for (final d in dirs) { for (int i=1;i<=max;i++) { final nr=r+d[0]*i,nc=c+d[1]*i; if(nr<0||nr>7||nc<0||nc>7) break; if(_mine(board[nr][nc])) break; moves.add([nr,nc]); if(_opp(board[nr][nc])) break; } } }
    switch (pt) {
      case 'p':
        final dir = isWhite ? (_isW(p)?-1:1) : (_isW(p)?1:-1);
        final start = isWhite ? (_isW(p)?6:1) : (_isW(p)?1:6);
        if (r+dir>=0&&r+dir<8&&board[r+dir][c].isEmpty) { moves.add([r+dir,c]); if(r==start&&board[r+2*dir][c].isEmpty) moves.add([r+2*dir,c]); }
        for (final dc in [-1,1]) { final nc=c+dc; if(nc>=0&&nc<8&&_opp(board[r+dir][nc])) moves.add([r+dir,nc]); }
        break;
      case 'n': for (final d in [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) add(r+d[0],c+d[1]); break;
      case 'b': slide([[-1,-1],[-1,1],[1,-1],[1,1]]); break;
      case 'r': slide([[-1,0],[1,0],[0,-1],[0,1]]); break;
      case 'q': slide([[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]); break;
      case 'k': slide([[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]], max:1); break;
    }
    return moves;
  }

  void _showGameOverDialog() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        title: Text(winner == widget.username ? '🏆 MENANG!' : opponentLeft ? '🏆 MENANG!' : '😞 KALAH', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, color: winner==widget.username?_gold:_acc)),
        content: Text(status, textAlign: TextAlign.center, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: Colors.white70)),
        actions: [TextButton(onPressed: () { Navigator.pop(context); Navigator.pop(context); }, child: const Text('KELUAR', style: TextStyle(color: Color(0xFFFF4444), fontFamily: 'Orbitron', fontSize: 12)))],
      ));
    });
  }

  String _pieceEmoji(String p) {
    const m = {'K':'♔','Q':'♕','R':'♖','B':'♗','N':'♘','P':'♙','k':'♚','q':'♛','r':'♜','b':'♝','n':'♞','p':'♟'};
    return m[p] ?? '';
  }

  @override
  void dispose() { _glowCtrl.dispose(); _sub?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final sz = (MediaQuery.of(context).size.width - 8) / 8;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Container(decoration: BoxDecoration(gradient: RadialGradient(center: Alignment.topCenter, radius: 1.2, colors: [_red.withOpacity(0.08), Colors.black]))),
        SafeArea(child: Column(children: [
          _buildHeader(),
          const SizedBox(height: 4),
          _buildCaptured(capturedByMe, isMe: true),
          const SizedBox(height: 4),
          Expanded(child: Center(child: _buildBoard(sz))),
          _buildCaptured(capturedByOpp, isMe: false),
          _buildStatus(),
          const SizedBox(height: 8),
        ])),
      ]),
    );
  }

  Widget _buildHeader() {
    return Padding(padding: const EdgeInsets.fromLTRB(12,12,12,0), child: Row(children: [
      GestureDetector(
        onTap: () { if (!gameOver) widget.wsChannel.sink.add(jsonEncode({'type':'roomLeave','roomId':widget.roomId})); Navigator.pop(context); },
        child: Container(width:36,height:36,decoration:BoxDecoration(color:Colors.white.withOpacity(0.07),borderRadius:BorderRadius.circular(10),border:Border.all(color:_acc.withOpacity(0.3))),child:Icon(Icons.arrow_back_ios_new,color:Colors.white,size:14))),
      const SizedBox(width:10),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('CHESS MULTIPLAYER',style:TextStyle(fontFamily:'Orbitron',fontSize:12,color:Colors.white,letterSpacing:1,shadows:[Shadow(color:Color(0xFFFFD700),blurRadius:8)])),
        Text('vs ${widget.opponent} · ${isWhite?"PUTIH":"HITAM"}',style:const TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:Colors.white38)),
      ]),
      const Spacer(),
      Container(padding:EdgeInsets.symmetric(horizontal:8,vertical:4),decoration:BoxDecoration(color:myTurn?_neon.withOpacity(0.1):Colors.white.withOpacity(0.05),borderRadius:BorderRadius.circular(8),border:Border.all(color:myTurn?_neon.withOpacity(0.5):Colors.white.withOpacity(0.12))),
        child:Text(myTurn?'GILIRANMU':'MENUNGGU',style:TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:myTurn?_neon:Colors.white38))),
    ]));
  }

  Widget _buildCaptured(List<String> pieces, {required bool isMe}) {
    return Padding(padding:const EdgeInsets.symmetric(horizontal:12), child:Row(children:[
      Text(isMe?'Tangkapanku: ':'Tangkapan lawan: ',style:const TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:Colors.white38)),
      Wrap(spacing:1,children:pieces.map((p)=>Text(_pieceEmoji(p),style:const TextStyle(fontSize:12))).toList()),
    ]));
  }

  Widget _buildBoard(double sz) {
    return Container(
      decoration: BoxDecoration(border: Border.all(color: _gold.withOpacity(0.3), width: 2), borderRadius: BorderRadius.circular(4)),
      child: Column(mainAxisSize: MainAxisSize.min, children: List.generate(8, (ri) {
        return Row(mainAxisSize: MainAxisSize.min, children: List.generate(8, (ci) {
          final actualR = isWhite ? ri : 7 - ri;
          final actualC = isWhite ? ci : 7 - ci;
          final p    = board[actualR][actualC];
          final light = (actualR + actualC) % 2 == 0;
          final isSel = selR == actualR && selC == actualC;
          final isVM  = validMoves.any((m) => m[0] == actualR && m[1] == actualC);
          Color bg = light ? const Color(0xFFD4A96A) : const Color(0xFF8B5E3C);
          if (isSel) bg = _gold.withOpacity(0.7);
          else if (isVM) bg = _neon.withOpacity(0.45);
          return GestureDetector(
            onTap: () => _tap(ri, ci),
            child: Container(width: sz, height: sz, color: bg,
              child: Center(child: Text(_pieceEmoji(p), style: TextStyle(fontSize: sz * 0.62, shadows: [Shadow(color: Colors.black.withOpacity(0.4), blurRadius: 3)])))),
          );
        }));
      })),
    );
  }

  Widget _buildStatus() {
    return Padding(padding: const EdgeInsets.fromLTRB(12,6,12,0), child: Container(
      width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(color: myTurn?_acc.withOpacity(0.12):Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(10), border: Border.all(color: myTurn?_acc.withOpacity(0.4):Colors.white.withOpacity(0.12))),
      child: Text(status, textAlign: TextAlign.center, style: TextStyle(fontFamily: 'Orbitron', fontSize: 12, color: myTurn?_acc:Colors.white38))));
  }
}
