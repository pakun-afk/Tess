import 'dart:convert';
import 'config_service.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'chess_game.dart';
import 'tictactoe_game.dart';
import 'quiz_battle.dart';

String get _wsBase => wsBaseUrl;

class GameHubPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const GameHubPage({super.key, required this.username, required this.sessionKey});
  @override State<GameHubPage> createState() => _GameHubPageState();
}

class _GameHubPageState extends State<GameHubPage> with TickerProviderStateMixin {
  static const Color _red    = Color(0xFFB22222);
  static const Color _accent = Color(0xFFFF4444);
  static const Color _neon   = Color(0xFF00FF88);
  static const Color _gold   = Color(0xFFFFD700);

  late TabController _tabCtrl;
  late AnimationController _fadeCtrl;
  late Animation<double> _fade;

  WebSocketChannel? _ws;
  bool _connected = false;
  Timer? _pingTimer;
  Timer? _reconnectTimer;

  final Map<String, List<Map<String, dynamic>>> _rooms = {
    'chess': [], 'tictactoe': [], 'quiz': [],
  };
  bool _creating = false;
  bool _joining  = false;

  final List<Map<String, dynamic>> _gameConfig = [
    {'key':'chess','title':'CATUR','icon':Icons.grid_on,'color':Color(0xFFFFD700)},
    {'key':'tictactoe','title':'TIC TAC TOE','icon':Icons.close,'color':Color(0xFF00BFFF)},
    {'key':'quiz','title':'QUIZ BATTLE','icon':Icons.quiz_outlined,'color':Color(0xFF00FF88)},
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl  = TabController(length: 3, vsync: this);
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500))..forward();
    _fade     = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _tabCtrl.addListener(() { if (!_tabCtrl.indexIsChanging) _loadRooms(); });
    _connectWS();
  }

  @override
  void dispose() {
    _tabCtrl.dispose(); _fadeCtrl.dispose();
    _pingTimer?.cancel(); _reconnectTimer?.cancel();
    _ws?.sink.close();
    super.dispose();
  }

  void _connectWS() {
    _reconnectTimer?.cancel();
    try {
      _ws = WebSocketChannel.connect(Uri.parse('${wsBaseUrl}/ws?key=${widget.sessionKey}'));
      _ws!.stream.listen(_onMessage, onDone: _onDisconnect, onError: (_) => _onDisconnect());
      Future.delayed(const Duration(milliseconds: 400), () {
        _sendWS({'type':'auth','key':widget.sessionKey});
        _loadRooms();
        _pingTimer = Timer.periodic(const Duration(seconds:25), (_) => _sendWS({'type':'ping'}));
      });
    } catch (_) { _scheduleReconnect(); }
  }

  void _onDisconnect() {
    if (!mounted) return;
    setState(() => _connected = false);
    _pingTimer?.cancel();
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds:4), () { if (mounted) _connectWS(); });
  }

  void _sendWS(Map<String,dynamic> data) {
    try { _ws?.sink.add(jsonEncode(data)); } catch (_) {}
  }

  void _onMessage(dynamic raw) {
    if (!mounted) return;
    try {
      final data = jsonDecode(raw as String) as Map<String,dynamic>;
      final type = data['type'] as String? ?? '';

      if (type == 'authOk') {
        setState(() => _connected = true);
        _loadRooms();
      } else if (type == 'roomList') {
        final game  = data['game'] as String?;
        final rooms = List<Map<String,dynamic>>.from(data['rooms'] ?? []);
        if (game != null && _rooms.containsKey(game)) setState(() { _rooms[game] = rooms; });
      } else if (type == 'roomCreated') {
        setState(() => _creating = false);
        _showWaitingDialog(data['roomId'] as String, data['game'] as String, data['name'] as String? ?? 'Room');
      } else if (type == 'roomStarted') {
        // HOST: lawan masuk — pop dialog waiting lalu buka game
        if (Navigator.of(context).canPop()) Navigator.of(context).pop();
        _openGame(data);
      } else if (type == 'roomJoined') {
        // GUEST: langsung buka game
        setState(() => _joining = false);
        _openGame(data);
      } else if (type == 'roomError') {
        setState(() { _creating = false; _joining = false; });
        _showSnack(data['msg'] ?? 'Error', isError: true);
      } else if (type == 'opponentLeft') {
        _showSnack('Lawan keluar dari room', isError: true);
      }
    } catch (_) {}
  }

  void _loadRooms() {
    for (final g in ['chess','tictactoe','quiz']) _sendWS({'type':'roomList','game':g});
  }

  // ── BUAT ROOM ────────────────────────────────────────────────────
  void _createRoom(String game) async {
    if (_creating) return;
    final nameCtrl = TextEditingController(text: "${widget.username}'s Room");
    final passCtrl = TextEditingController();
    bool passVisible = false;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _accent.withOpacity(0.4))),
        title: Row(children: [
          Icon(Icons.add_box_outlined, color: _accent, size: 18),
          const SizedBox(width: 8),
          Text('Buat Room ${game.toUpperCase()}',
            style: const TextStyle(fontFamily: 'Orbitron', fontSize: 13, color: Colors.white)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            controller: nameCtrl,
            style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
            decoration: InputDecoration(
              labelText: 'Nama Room',
              labelStyle: const TextStyle(color: Colors.white38, fontSize: 11),
              prefixIcon: const Icon(Icons.meeting_room, color: Colors.white24, size: 16),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.12))),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: _accent.withOpacity(0.6))))),
          const SizedBox(height: 12),
          TextField(
            controller: passCtrl,
            obscureText: !passVisible,
            style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
            decoration: InputDecoration(
              labelText: 'Password Room',
              labelStyle: const TextStyle(color: Colors.white38, fontSize: 11),
              prefixIcon: const Icon(Icons.lock_outline, color: Colors.white24, size: 16),
              suffixIcon: GestureDetector(
                onTap: () => setS(() => passVisible = !passVisible),
                child: Icon(passVisible ? Icons.visibility : Icons.visibility_off,
                  color: Colors.white38, size: 16)),
              helperText: 'Bagikan password ke lawan agar bisa masuk',
              helperStyle: const TextStyle(color: Colors.white24, fontSize: 9),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.12))),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: _accent.withOpacity(0.6))))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white38))),
          ElevatedButton(
            onPressed: () {
              if (passCtrl.text.trim().isEmpty) return;
              Navigator.pop(ctx, true);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _accent.withOpacity(0.2),
              side: BorderSide(color: _accent.withOpacity(0.5)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
            child: const Text('BUAT', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, color: Color(0xFFFF4444)))),
        ],
      )),
    );

    if (confirmed != true || passCtrl.text.trim().isEmpty) return;
    setState(() => _creating = true);
    _sendWS({'type':'roomCreate','game':game,'name':nameCtrl.text.trim(),'password':passCtrl.text.trim()});
  }

  // ── JOIN ROOM (input password) ───────────────────────────────────
  void _joinRoom(String roomId, String roomName) async {
    if (_joining) return;
    final passCtrl = TextEditingController();
    bool passVisible = false;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _neon.withOpacity(0.4))),
        title: Row(children: [
          Icon(Icons.lock_open_outlined, color: _neon, size: 18),
          const SizedBox(width: 8),
          const Text('Masuk Room', style: TextStyle(fontFamily: 'Orbitron', fontSize: 13, color: Colors.white)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(color: _neon.withOpacity(0.07), borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _neon.withOpacity(0.2))),
            child: Row(children: [
              Icon(Icons.meeting_room, color: _neon, size: 14),
              const SizedBox(width: 6),
              Expanded(child: Text(roomName,
                style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: Colors.white70))),
            ])),
          const SizedBox(height: 12),
          TextField(
            controller: passCtrl,
            obscureText: !passVisible,
            autofocus: true,
            style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
            decoration: InputDecoration(
              labelText: 'Password Room',
              labelStyle: const TextStyle(color: Colors.white38, fontSize: 11),
              prefixIcon: const Icon(Icons.key, color: Colors.white24, size: 16),
              suffixIcon: GestureDetector(
                onTap: () => setS(() => passVisible = !passVisible),
                child: Icon(passVisible ? Icons.visibility : Icons.visibility_off,
                  color: Colors.white38, size: 16)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.12))),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: _neon.withOpacity(0.6))))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white38))),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _neon.withOpacity(0.15),
              side: BorderSide(color: _neon.withOpacity(0.5)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
            child: Text('JOIN', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, color: _neon))),
        ],
      )),
    );

    if (confirmed != true) return;
    setState(() => _joining = true);
    _sendWS({'type':'roomJoin','roomId':roomId,'password':passCtrl.text.trim()});
  }

  // ── WAITING DIALOG ───────────────────────────────────────────────
  void _showWaitingDialog(String roomId, String game, String name) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => WillPopScope(
        onWillPop: () async {
          _sendWS({'type':'roomLeave','roomId':roomId});
          return true;
        },
        child: AlertDialog(
          backgroundColor: const Color(0xFF111111),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: _accent.withOpacity(0.3))),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 8),
            CircularProgressIndicator(color: _accent, strokeWidth: 2),
            const SizedBox(height: 16),
            const Text('⏳ Menunggu lawan masuk...',
              style: TextStyle(fontFamily: 'Orbitron', fontSize: 12, color: Colors.white)),
            const SizedBox(height: 6),
            Text(name, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white54)),
            const SizedBox(height: 12),
            Container(padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.white.withOpacity(0.12))),
              child: Column(children: const [
                Icon(Icons.lock, color: Colors.orange, size: 16),
                SizedBox(height: 4),
                Text('Room ini berpassword\nBagikan nama + password ke lawan',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white38)),
              ])),
          ]),
          actions: [
            TextButton(
              onPressed: () {
                _sendWS({'type':'roomLeave','roomId':roomId});
                Navigator.pop(context);
                setState(() => _creating = false);
              },
              child: const Text('Batalkan', style: TextStyle(color: Colors.white38))),
          ],
        ),
      ),
    );
    _loadRooms();
  }

  // ── BUKA GAME — FIX: TANPA popUntil ─────────────────────────────
  void _openGame(Map<String,dynamic> data) {
    if (!mounted) return;
    final game     = data['game']     as String? ?? '';
    final roomId   = data['roomId']   as String? ?? '';
    final opponent = data['opponent'] as String? ?? '';
    final myTurn   = data['myTurn']   as bool?   ?? false;
    final myColor  = data['myColor']  as String?;
    final board    = data['board'];

    Widget page;
    switch (game) {
      case 'chess':
        page = ChessGamePage(
          username: widget.username, sessionKey: widget.sessionKey,
          roomId: roomId, opponent: opponent, myTurn: myTurn,
          myColor: myColor ?? 'white',
          initialBoard: board != null
            ? List<List<String>>.from((board as List).map((r) => List<String>.from(r as List)))
            : null,
          wsChannel: _ws!);
        break;
      case 'tictactoe':
        page = TicTacToePage(
          username: widget.username, sessionKey: widget.sessionKey,
          roomId: roomId, opponent: opponent, myTurn: myTurn, wsChannel: _ws!);
        break;
      default:
        page = QuizBattlePage(
          username: widget.username, sessionKey: widget.sessionKey,
          roomId: roomId, opponent: opponent, wsChannel: _ws!);
    }

    // JANGAN pakai popUntil — itu bikin layar abu-abu!
    // Pakai push biasa dengan fade transition
    Navigator.push(context, PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
      transitionDuration: const Duration(milliseconds: 300),
    ));
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: isError ? Colors.red.shade900 : Colors.green.shade900,
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Container(decoration: BoxDecoration(gradient: RadialGradient(
          center: Alignment.topCenter, radius: 1.5,
          colors: [_red.withOpacity(0.12), Colors.black]))),
        SafeArea(child: FadeTransition(opacity: _fade, child: Column(children: [
          _buildHeader(),
          _buildTabBar(),
          Expanded(child: TabBarView(controller: _tabCtrl,
            children: _gameConfig.map((g) => _buildGameTab(g)).toList())),
        ]))),
      ]),
    );
  }

  Widget _buildHeader() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
    child: Row(children: [
      GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(width: 38, height: 38,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _accent.withOpacity(0.3))),
          child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 15))),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('GAME CENTER', style: TextStyle(fontFamily: 'Orbitron', fontSize: 18,
          fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 2,
          shadows: [Shadow(color: Color(0xFFFF4444), blurRadius: 15)])),
        Row(children: [
          const Text('Multiplayer Online',
            style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: Colors.white38)),
          const SizedBox(width: 6),
          Container(width: 6, height: 6, decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _connected ? _neon : Colors.red,
            boxShadow: _connected ? [BoxShadow(color: _neon, blurRadius: 4)] : [])),
        ]),
      ])),
      GestureDetector(
        onTap: _loadRooms,
        child: Container(width: 36, height: 36,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.white24)),
          child: const Icon(Icons.refresh_rounded, color: Colors.white54, size: 18))),
    ]),
  );

  Widget _buildTabBar() => Container(
    margin: const EdgeInsets.fromLTRB(16, 14, 16, 0),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.05),
      borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.12))),
    child: TabBar(
      controller: _tabCtrl,
      indicator: BoxDecoration(borderRadius: BorderRadius.circular(10),
        color: _accent.withOpacity(0.25), border: Border.all(color: _accent.withOpacity(0.5))),
      labelColor: Colors.white, unselectedLabelColor: Colors.white38,
      labelStyle: const TextStyle(fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 0.5),
      tabs: _gameConfig.map((g) {
        final color = g['color'] as Color;
        return Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(g['icon'] as IconData, size: 12, color: color),
          const SizedBox(width: 4),
          Text(g['title'] as String, style: TextStyle(color: color, fontSize: 9)),
        ]));
      }).toList(),
    ),
  );

  Widget _buildGameTab(Map<String,dynamic> gCfg) {
    final gameKey = gCfg['key'] as String;
    final color   = gCfg['color'] as Color;
    final rooms   = _rooms[gameKey] ?? [];
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
        child: GestureDetector(
          onTap: () => _createRoom(gameKey),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 13),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(colors: [color.withOpacity(0.2), color.withOpacity(0.08)]),
              border: Border.all(color: color.withOpacity(0.5))),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              if (_creating) const SizedBox(width: 14, height: 14,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              else Icon(Icons.add_circle_outline_rounded, color: color, size: 18),
              const SizedBox(width: 8),
              Text('BUAT ROOM ${(gCfg['title'] as String)}',
                style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, color: color, letterSpacing: 1)),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 10),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          const Icon(Icons.public, color: Colors.white24, size: 12),
          const SizedBox(width: 4),
          const Text('ROOM PUBLIK',
            style: TextStyle(fontFamily: 'Orbitron', fontSize: 10, color: Colors.white38, letterSpacing: 1)),
          const Spacer(),
          Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6),
              border: Border.all(color: color.withOpacity(0.3))),
            child: Text('${rooms.length} room',
              style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: color))),
        ]),
      ),
      const SizedBox(height: 6),
      Expanded(
        child: rooms.isEmpty
          ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(gCfg['icon'] as IconData, color: color.withOpacity(0.2), size: 42),
              const SizedBox(height: 10),
              const Text('Belum ada room.\nBuat room dan tunggu lawan!',
                textAlign: TextAlign.center,
                style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white24)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: rooms.length,
              itemBuilder: (_, i) => _buildRoomCard(rooms[i], color)),
      ),
    ]);
  }

  Widget _buildRoomCard(Map<String,dynamic> room, Color color) {
    final id      = room['id']          as String? ?? '';
    final name    = room['name']        as String? ?? 'Room';
    final host    = room['host']        as String? ?? '';
    final hasPass = room['hasPassword'] as bool?   ?? false;
    final isMe    = host == widget.username;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(14),
        border: Border.all(color: (isMe ? _accent : color).withOpacity(0.3))),
      child: Row(children: [
        Container(width: 42, height: 42,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.15),
            border: Border.all(color: color.withOpacity(0.4))),
          child: Center(child: Text(host.isNotEmpty ? host[0].toUpperCase() : '?',
            style: TextStyle(fontFamily: 'Orbitron', fontSize: 15, color: color, fontWeight: FontWeight.bold)))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: 'Orbitron', fontSize: 12,
                color: Colors.white, fontWeight: FontWeight.bold))),
            if (hasPass) Container(
              margin: const EdgeInsets.only(left: 4),
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
              decoration: BoxDecoration(color: Colors.orange.withOpacity(0.15),
                borderRadius: BorderRadius.circular(5), border: Border.all(color: Colors.orange.withOpacity(0.4))),
              child: Row(mainAxisSize: MainAxisSize.min, children: const [
                Icon(Icons.lock, size: 9, color: Colors.orange),
                SizedBox(width: 2),
                Text('PASS', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 7, color: Colors.orange)),
              ])),
          ]),
          const SizedBox(height: 3),
          Row(children: [
            Text('Host: $host', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: Colors.white38)),
            if (isMe) ...[
              const SizedBox(width: 6),
              Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(color: _accent.withOpacity(0.2), borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: _accent.withOpacity(0.4))),
                child: const Text('KAMU', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: Color(0xFFFF4444)))),
            ],
          ]),
          Text('Menunggu lawan...', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: color.withOpacity(0.5))),
        ])),
        const SizedBox(width: 8),
        if (!isMe) GestureDetector(
          onTap: _joining ? null : () => _joinRoom(id, name),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [color, color.withOpacity(0.7)]),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [BoxShadow(color: color.withOpacity(0.35), blurRadius: 8)]),
            child: _joining
              ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : Column(mainAxisSize: MainAxisSize.min, children: const [
                  Icon(Icons.play_arrow_rounded, color: Colors.white, size: 16),
                  Text('JOIN', style: TextStyle(fontFamily: 'Orbitron', fontSize: 8, color: Colors.white)),
                ])),
        ),
      ]),
    );
  }
}
