import 'package:flutter/material.dart';
import 'config_service.dart';
import 'debug_page.dart';
import 'dart:ui';
import 'package:video_player/video_player.dart';
import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  late AnimationController _fadeController;
  late AnimationController _textController;
  late AnimationController _btnController;
  late Animation<double> _fadeAnim;
  late Animation<double> _textSlide;
  late Animation<double> _btnFade;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);

    _textController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _textSlide = CurvedAnimation(parent: _textController, curve: Curves.easeOutCubic);

    _btnController = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _btnFade = CurvedAnimation(parent: _btnController, curve: Curves.easeIn);

    _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        setState(() => _videoInitialized = true);
        _videoController.setVolume(0.1);
        _videoController.setLooping(true);
        _videoController.play();
        Future.delayed(const Duration(milliseconds: 300), () {
          _textController.forward();
        });
        Future.delayed(const Duration(milliseconds: 800), () {
          _btnController.forward();
        });
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _textController.dispose();
    _btnController.dispose();
    super.dispose();
  }

  void _goToLogin() {
    Navigator.pushReplacement(context, PageRouteBuilder(
      pageBuilder: (_, anim, __) => FadeTransition(opacity: anim, child: const LoginPage()),
      transitionDuration: const Duration(milliseconds: 600),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── Video Background ──
          if (_videoInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoController.value.size.width,
                height: _videoController.value.size.height,
                child: VideoPlayer(_videoController),
              ),
            )
          else
            Container(color: Colors.black),

          // ── Dark overlay ──
          Container(decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.75), Colors.black.withOpacity(0.95)],
            ),
          )),

          // ── Scanline effect ──
          IgnorePointer(child: CustomPaint(painter: _ScanlinePainter(), size: MediaQuery.of(context).size)),

          // ── Content ──
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Column(
                children: [
                  const Spacer(),

                  // Logo area
                  AnimatedBuilder(
                    animation: _textSlide,
                    builder: (_, __) => Transform.translate(
                      offset: Offset(0, 40 * (1 - _textSlide.value)),
                      child: Opacity(
                        opacity: _textSlide.value,
                        child: Column(children: [
                          // Logo
                          Container(
                            width: 80, height: 80,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Color(0xFFFF4444).withOpacity(0.7), width: 2),
                              boxShadow: [BoxShadow(color: Color(0xFFB22222).withOpacity(0.6), blurRadius: 30, spreadRadius: 5)],
                              image: const DecorationImage(image: AssetImage('assets/images/logo.jpg'), fit: BoxFit.cover),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // Welcome text
                          const Text("SELAMAT DATANG", style: TextStyle(
                            fontFamily: 'ShareTechMono', fontSize: 13, color: Color(0xFF00FF88),
                            letterSpacing: 4, shadows: [Shadow(color: Color(0xFF00FF88), blurRadius: 15)],
                          )),
                          const SizedBox(height: 10),
                          const Text("BTR APPS", style: TextStyle(
                            fontFamily: 'Orbitron', fontSize: 40, fontWeight: FontWeight.bold,
                            color: Colors.white, letterSpacing: 5,
                            shadows: [Shadow(color: Color(0xFFFF4444), blurRadius: 25), Shadow(color: Color(0xFFB22222), blurRadius: 50)],
                          )),
                          const SizedBox(height: 12),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.07),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                                ),
                                child: const Text("SISTEM CANGGIH VERSI BARU", style: TextStyle(
                                  fontFamily: 'ShareTechMono', fontSize: 11, color: Colors.white60, letterSpacing: 2)),
                              ),
                            ),
                          ),
                        ]),
                      ),
                    ),
                  ),

                  const SizedBox(height: 50),

                  // Enter button
                  AnimatedBuilder(
                    animation: _btnFade,
                    builder: (_, __) => Opacity(
                      opacity: _btnFade.value,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 40),
                        child: GestureDetector(
                          onTap: _goToLogin,
                          child: Container(
                            width: double.infinity, height: 58,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFB22222), Color(0xFFFF4444), Color(0xFFB22222)],
                                begin: Alignment.centerLeft, end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(18),
                              boxShadow: [BoxShadow(color: Color(0xFFB22222).withOpacity(0.6), blurRadius: 25, spreadRadius: 3)],
                            ),
                            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              const Icon(Icons.power_settings_new, color: Colors.white, size: 22),
                              const SizedBox(width: 12),
                              const Text("MULAI SEKARANG", style: TextStyle(
                                fontFamily: 'Orbitron', color: Colors.white, fontSize: 15,
                                fontWeight: FontWeight.bold, letterSpacing: 2)),
                            ]),
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  AnimatedBuilder(
                    animation: _btnFade,
                    builder: (_, __) => Opacity(
                      opacity: _btnFade.value,
                      child: Text("© 2025 BTR APPS Project",
                        style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white.withOpacity(0.2), letterSpacing: 2)),
                    ),
                  ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withOpacity(0.04)..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 3) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(_ScanlinePainter old) => false;
}
