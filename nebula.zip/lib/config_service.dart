import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ─── ISI URL GIST KAMU ─────────────────────────────────────
const String _GIST_URL = 'https://gist.githubusercontent.com/pakun-afk/97f1b034dfac9756313f4519b793f91a/raw/config.json';

const Duration _TIMEOUT  = Duration(seconds: 8);
const String   _PREF_BASE = 'cfg_baseUrl';
const String   _PREF_WS   = 'cfg_wsUrl';
const String   _PREF_TS   = 'cfg_timestamp';
const int      _CACHE_HRS  = 6;

enum ConnStatus { checking, online, offline }

class ConfigService extends ChangeNotifier {
  static final ConfigService _i = ConfigService._();
  factory ConfigService() => _i;
  ConfigService._();

  String  baseUrl    = 'https://reseller-web.jhonaley.net:4180';
  String  wsUrl      = 'ws://reseller-web.jhonaley.net:4180';
  bool    loaded     = false;
  bool    fromGist   = false;
  ConnStatus connStatus = ConnStatus.checking;
  String  connMsg    = 'Menghubungkan...';
  int     pingMs     = -1;
  String? lastError;

  Future<void> init() async {
    await _loadCached();
    await _fetchGist();
    if (baseUrl.isNotEmpty) await _ping();
    loaded = true;
    notifyListeners();
  }

  Future<void> _loadCached() async {
    final p  = await SharedPreferences.getInstance();
    final b  = p.getString(_PREF_BASE);
    final w  = p.getString(_PREF_WS);
    final ts = p.getInt(_PREF_TS) ?? 0;
    final age = DateTime.now().millisecondsSinceEpoch - ts;
    if (b != null && b.isNotEmpty && age < _CACHE_HRS * 3600 * 1000) {
      baseUrl  = b;
      wsUrl    = w ?? '';
      fromGist = true;
      debugLog('📦 Cache: $baseUrl');
    }
  }

  // Public method untuk retry config dari login page
  Future<void> fetchConfig() => _fetchGist();

  Future<void> _fetchGist() async {
    try {
      final res = await http.get(
        Uri.parse('$_GIST_URL?t=${DateTime.now().millisecondsSinceEpoch}'),
        headers: {'Cache-Control': 'no-cache'},
      ).timeout(_TIMEOUT);

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final b = (json['baseUrl'] as String? ?? '').trim();
        final w = (json['wsUrl']   as String? ?? '').trim();
        if (b.isNotEmpty) {
          baseUrl  = b;
          wsUrl    = w;
          fromGist = true;
          lastError = null;
          final p = await SharedPreferences.getInstance();
          await p.setString(_PREF_BASE, b);
          await p.setString(_PREF_WS,   w);
          await p.setInt(_PREF_TS, DateTime.now().millisecondsSinceEpoch);
          debugLog('✅ Gist: $baseUrl');
        } else {
          lastError = 'Gist OK tapi baseUrl kosong';
          debugLog('⚠️  $lastError');
        }
      } else {
        lastError = 'Gist HTTP ${res.statusCode}';
        debugLog('❌ $lastError');
      }
    } catch (e) {
      lastError = 'Gist error: $e';
      debugLog('❌ $lastError');
    }
  }

  Future<void> _ping() async {
    connStatus = ConnStatus.checking;
    connMsg    = 'Mengecek server...';
    notifyListeners();
    try {
      final t0  = DateTime.now().millisecondsSinceEpoch;
      final res = await http.get(Uri.parse('$baseUrl/ping')).timeout(_TIMEOUT);
      final t1  = DateTime.now().millisecondsSinceEpoch;
      if (res.statusCode == 200) {
        pingMs     = t1 - t0;
        connStatus = ConnStatus.online;
        connMsg    = 'Online · ${pingMs}ms';
        debugLog('🏓 Ping OK ${pingMs}ms');
      } else {
        throw Exception('HTTP ${res.statusCode}');
      }
    } catch (e) {
      connStatus = ConnStatus.offline;
      connMsg    = 'Server offline';
      lastError  = 'Ping: $e';
      pingMs     = -1;
      debugLog('❌ Ping gagal: $e');
    }
    notifyListeners();
  }

  Future<Map<String, dynamic>> testLogin(String username, String password) async {
    if (baseUrl.isEmpty) return {'ok': false, 'msg': 'Base URL belum ada (Gist gagal)'};
    try {
      final t0  = DateTime.now().millisecondsSinceEpoch;
      final res = await http.get(
        Uri.parse('$baseUrl/login?username=$username&password=$password&androidId=debug'),
      ).timeout(_TIMEOUT);
      final t1  = DateTime.now().millisecondsSinceEpoch;
      final body = jsonDecode(res.body);
      return {
        'ok':       body['valid'] == true,
        'msg':      body['message'] ?? (body['valid'] == true ? 'Login berhasil' : 'Login gagal'),
        'status':   res.statusCode,
        'ping':     t1 - t0,
        'raw':      res.body.length > 300 ? res.body.substring(0, 300) + '...' : res.body,
      };
    } catch (e) {
      return {'ok': false, 'msg': 'Error: $e'};
    }
  }

  Future<void> refresh() async {
    loaded     = false;
    connStatus = ConnStatus.checking;
    connMsg    = 'Refresh...';
    lastError  = null;
    notifyListeners();
    await _fetchGist();
    if (baseUrl.isNotEmpty) await _ping();
    loaded = true;
    notifyListeners();
  }

  Color get statusColor {
    switch (connStatus) {
      case ConnStatus.online:  return const Color(0xFF00FF88);
      case ConnStatus.offline: return const Color(0xFFFF4444);
      default:                 return Colors.white38;
    }
  }

  static final List<String> logs = [];
  static void debugLog(String msg) {
    final ts = DateTime.now().toLocal().toString().substring(11, 19);
    final e  = '[$ts] $msg';
    logs.add(e);
    if (logs.length > 300) logs.removeAt(0);
    // ignore: avoid_print
    print(e);
  }
}

ConfigService get cfg => ConfigService();
ConfigService get configInstance => ConfigService();
String get baseUrl    => cfg.baseUrl;
String get wsBaseUrl  => cfg.wsUrl;
