import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class TicTacToePage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String roomId;
  final String opponent;
  final bool   myTurn;
  final WebSocketChannel wsChannel;
  const TicTacToePage({super.key, required this.username, required this.sessionKey, required this.roomId, required this.opponent, required this.myTurn, required this.wsChannel});
  @override State<TicTacToePage> createState() => _TicTacToePageState();
}

class _TicTacToePageState extends State<TicTacToePage> with TickerProviderStateMixin {
  static const Color _red   = Color(0xFFB22222);
  static const Color _acc   = Color(0xFFFF4444);
  static const Color _neon  = Color(0xFF00FF88);
  static const Color _cyan  = Color(0xFF00BFFF);

  List<String> board    = List.filled(9, '');
  bool   myTurn         = false;
  late String myMark, oppMark;
  String? winner;
  List<int> winLine     = [];
  int scoreMe = 0, scoreOpp = 0;
  bool gameOver = false;
  bool opponentLeft = false;
  StreamSubscription? _sub;

  late AnimationController _winCtrl;
  late Animation<double>   _winAnim;

  @override
  void initState() {
    super.initState();
    myTurn  = widget.myTurn;
    myMark  = widget.myTurn ? 'X' : 'O';
    oppMark = widget.myTurn ? 'O' : 'X';
    _winCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _winAnim = CurvedAnimation(parent: _winCtrl, curve: Curves.elasticOut);
    _sub = widget.wsChannel.stream.listen(_onMessage);
  }

  @override
  void dispose() { _winCtrl.dispose(); _sub?.cancel(); super.dispose(); }

  void _onMessage(dynamic raw) {
    if (!mounted) return;
    try {
      final data = jsonDecode(raw as String) as Map<String, dynamic>;
      final type = data['type'] as String? ?? '';
      if (type == 'gameMove' && data['roomId'] == widget.roomId) {
        final move = data['move'] as Map<String, dynamic>;
        setState(() {
          board  = List<String>.from(move['board'] as List);
          myTurn = true;
          _checkWin();
          if (!gameOver) winner = null;
        });
      } else if (type == 'gameOver' && data['roomId'] == widget.roomId) {
        final w = data['winner'] as String?;
        setState(() { gameOver=true; winner=w; });
        _showResultDialog(w);
      } else if (type == 'opponentLeft' && data['roomId'] == widget.roomId) {
        setState(() { opponentLeft=true; gameOver=true; winner=widget.username; scoreMe++; });
        _showResultDialog(widget.username, left: true);
      }
    } catch (_) {}
  }

  void _tap(int i) {
    if (board[i].isNotEmpty || winner != null || !myTurn || gameOver) return;
    final nb = List<String>.from(board);
    nb[i] = myMark;
    setState(() { board = nb; myTurn = false; _checkWin(); });
    widget.wsChannel.sink.add(jsonEncode({'type':'gameMove','roomId':widget.roomId,'move':{'index':i,'board':nb,'mark':myMark}}));
    if (gameOver) {
      widget.wsChannel.sink.add(jsonEncode({'type':'gameOver','roomId':widget.roomId,'winner':winner??'draw','loser':winner==null?null:widget.opponent}));
    }
  }

  void _checkWin() {
    const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for (final l in lines) {
      if (board[l[0]].isNotEmpty && board[l[0]]==board[l[1]] && board[l[1]]==board[l[2]]) {
        winner  = board[l[0]] == myMark ? widget.username : widget.opponent;
        winLine = l; gameOver = true;
        if (winner == widget.username) scoreMe++; else scoreOpp++;
        _winCtrl.forward(from: 0);
        _showResultDialog(winner);
        return;
      }
    }
    if (!board.contains('')) { winner = null; gameOver = true; _showResultDialog(null); }
  }

  void _showResultDialog(String? w, {bool left = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final isWin  = w == widget.username;
      final isDraw = w == null && !left;
      showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        title: Text(left?'🏆 Lawan keluar!':isWin?'🏆 MENANG!':isDraw?'🤝 SERI!':'😞 KALAH', textAlign:TextAlign.center, style:TextStyle(fontFamily:'Orbitron',fontSize:16,color:isWin||left?_neon:isDraw?Colors.white:_acc)),
        content: Text(left?'Lawan meninggalkan game. Kamu menang!':isWin?'Selamat! Kamu kalahkan ${widget.opponent}!':isDraw?'Tidak ada yang menang!':'${widget.opponent} menang kali ini...', textAlign:TextAlign.center, style:const TextStyle(fontFamily:'ShareTechMono',fontSize:11,color:Colors.white70)),
        actions: [
          TextButton(onPressed:(){setState((){board=List.filled(9,'');winner=null;winLine=[];gameOver=false;myTurn=widget.myTurn;_winCtrl.reset();});Navigator.pop(context);}, child:const Text('MAIN LAGI',style:TextStyle(color:Color(0xFF00FF88),fontFamily:'Orbitron',fontSize:11))),
          TextButton(onPressed:(){if(!gameOver) widget.wsChannel.sink.add(jsonEncode({'type':'roomLeave','roomId':widget.roomId}));Navigator.pop(context);Navigator.pop(context);}, child:const Text('KELUAR',style:TextStyle(color:Color(0xFFFF4444),fontFamily:'Orbitron',fontSize:11))),
        ],
      ));
    });
  }

  Color _cellColor(int i) {
    if (winLine.contains(i)) return board[i]==myMark?_neon.withOpacity(0.3):_acc.withOpacity(0.3);
    if (board[i]==myMark) return _cyan.withOpacity(0.08);
    if (board[i]==oppMark) return _neon.withOpacity(0.08);
    return Colors.white.withOpacity(0.04);
  }

  @override
  Widget build(BuildContext context) {
    final sz = (MediaQuery.of(context).size.width - 64) / 3;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Container(decoration: BoxDecoration(gradient: RadialGradient(center: Alignment.center, radius: 1.2, colors: [_red.withOpacity(0.1), Colors.black]))),
        SafeArea(child: Column(children: [
          _buildHeader(),
          const SizedBox(height: 12),
          _buildScores(),
          const SizedBox(height: 16),
          Expanded(child: Center(child: _buildBoard(sz))),
          _buildStatusBar(),
          const SizedBox(height: 12),
        ])),
      ]),
    );
  }

  Widget _buildHeader() {
    return Padding(padding: const EdgeInsets.fromLTRB(12,12,12,0), child: Row(children: [
      GestureDetector(
        onTap: () { if (!gameOver) widget.wsChannel.sink.add(jsonEncode({'type':'roomLeave','roomId':widget.roomId})); Navigator.pop(context); },
        child: Container(width:36,height:36,decoration:BoxDecoration(color:Colors.white.withOpacity(0.07),borderRadius:BorderRadius.circular(10),border:Border.all(color:_acc.withOpacity(0.3))),child:Icon(Icons.arrow_back_ios_new,color:Colors.white,size:14))),
      const SizedBox(width:10),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('TIC TAC TOE',style:TextStyle(fontFamily:'Orbitron',fontSize:14,color:Colors.white,letterSpacing:1.5,shadows:[Shadow(color:Color(0xFF00BFFF),blurRadius:10)])),
        Text('vs ${widget.opponent} · $myMark',style:const TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:Colors.white38)),
      ]),
      const Spacer(),
      Container(padding:EdgeInsets.symmetric(horizontal:8,vertical:4),decoration:BoxDecoration(color:myTurn?_cyan.withOpacity(0.1):Colors.white.withOpacity(0.05),borderRadius:BorderRadius.circular(8),border:Border.all(color:myTurn?_cyan.withOpacity(0.5):Colors.white.withOpacity(0.12))),
        child:Text(myTurn?'GILIRANMU':'MENUNGGU',style:TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:myTurn?_cyan:Colors.white38))),
    ]));
  }

  Widget _buildScores() {
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Row(children: [
      _scoreBox(widget.username, myMark, scoreMe, _cyan, true),
      const Expanded(child: Center(child: Text('VS', style: TextStyle(fontFamily:'Orbitron',fontSize:12,color:Colors.white38)))),
      _scoreBox(widget.opponent, oppMark, scoreOpp, _neon, false),
    ]));
  }

  Widget _scoreBox(String name, String mark, int score, Color color, bool isMe) {
    return Column(children: [
      Container(padding:EdgeInsets.symmetric(horizontal:16,vertical:8),decoration:BoxDecoration(color:color.withOpacity(0.1),borderRadius:BorderRadius.circular(12),border:Border.all(color:color.withOpacity(0.3))),
        child:Column(children:[
          Text(mark,style:TextStyle(fontSize:20,color:color)),
          Text('$score',style:TextStyle(fontFamily:'Orbitron',fontSize:18,color:color,fontWeight:FontWeight.bold)),
          Text(isMe?'KAMU':name,style:const TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:Colors.white38)),
        ])),
    ]);
  }

  Widget _buildBoard(double sz) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.12))),
      child: GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.all(4),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 6, mainAxisSpacing: 6),
        itemCount: 9,
        itemBuilder: (_, i) => GestureDetector(
          onTap: () => _tap(i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(color: _cellColor(i), borderRadius: BorderRadius.circular(12), border: Border.all(color: winLine.contains(i)?Colors.white.withOpacity(0.4):Colors.white.withOpacity(0.12))),
            child: Center(child: board[i].isEmpty ? null : ScaleTransition(scale: _winAnim, child: Text(board[i], style: TextStyle(fontSize: sz*0.5, color: board[i]==myMark?_cyan:_neon, fontWeight: FontWeight.bold, shadows: [Shadow(color: board[i]==myMark?_cyan:_neon, blurRadius: 12)])))),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBar() {
    String msg;
    Color color;
    if (gameOver) { msg = winner==widget.username?'🏆 MENANG!':winner==null?'🤝 SERI!':'😞 KALAH'; color=winner==widget.username?_neon:winner==null?Colors.white:_acc; }
    else if (myTurn) { msg='⚔️ Giliranmu! Pilih kotak'; color=_cyan; }
    else { msg='⏳ Giliran ${widget.opponent}...'; color=Colors.white38; }
    return Padding(padding:EdgeInsets.symmetric(horizontal:16),child:Container(width:double.infinity,padding:EdgeInsets.symmetric(vertical:10),decoration:BoxDecoration(color:color.withOpacity(0.1),borderRadius:BorderRadius.circular(10),border:Border.all(color:color.withOpacity(0.3))),child:Text(msg,textAlign:TextAlign.center,style:TextStyle(fontFamily:'Orbitron',fontSize:12,color:color))));
  }
}
