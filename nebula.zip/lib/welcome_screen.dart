import 'dart:async';
import 'package:flutter/material.dart';
import 'dashboard_page.dart';

class WelcomeScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const WelcomeScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with TickerProviderStateMixin {

  static const _red   = Color(0xFFB22222);
  static const _acc   = Color(0xFFFF4444);
  static const _neon  = Color(0xFF00FF88);

  late AnimationController _ctrl;
  late Animation<double> _barAnim;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();

    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));

    _barAnim  = CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.85, curve: Curves.easeOut));
    _fadeAnim = CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.5,  curve: Curves.easeIn));

    _ctrl.forward();

    // Langsung ke dashboard setelah bar selesai
    Future.delayed(const Duration(milliseconds: 1500), _goToDashboard);
  }

  void _goToDashboard() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, __, ___) => DashboardPage(
          username:    widget.username,
          password:    widget.password,
          role:        widget.role,
          sessionKey:  widget.sessionKey,
          expiredDate: widget.expiredDate,
          listBug:     widget.listBug,
          listDoos:    widget.listDoos,
          news:        widget.news,
        ),
        transitionsBuilder: (_, anim, __, child) =>
          FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Stack(children: [

          // Background glow
          Positioned(top: -40, left: -40, child: Container(width: 180, height: 180,
            decoration: BoxDecoration(shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _red.withOpacity(0.15), blurRadius: 120, spreadRadius: 60)]))),
          Positioned(bottom: -40, right: -40, child: Container(width: 160, height: 160,
            decoration: BoxDecoration(shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _neon.withOpacity(0.07), blurRadius: 100, spreadRadius: 40)]))),

          // Konten tengah
          Center(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 36),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    // Label kecil
                    Text('SISTEM AKTIF',
                      style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10,
                        color: _neon.withOpacity(0.7), letterSpacing: 3)),

                    const SizedBox(height: 10),

                    // Selamat Datang
                    const Text('SELAMAT\nDATANG,',
                      style: TextStyle(fontFamily: 'Orbitron', fontSize: 32,
                        fontWeight: FontWeight.bold, color: Colors.white, height: 1.1,
                        shadows: [Shadow(color: Color(0xFFFF4444), blurRadius: 20)])),

                    const SizedBox(height: 8),

                    // Username
                    Text(widget.username.toUpperCase(),
                      style: const TextStyle(fontFamily: 'Orbitron', fontSize: 22,
                        color: Color(0xFFFF4444), letterSpacing: 2,
                        shadows: [Shadow(color: Color(0xFFFF4444), blurRadius: 15)])),

                    const SizedBox(height: 28),

                    // Loading bar — balok bertumpuk
                    _buildLoadingBar(),

                    const SizedBox(height: 12),

                    // Status text
                    Text(
                      _barAnim.value < 0.99 ? 'Memuat sistem...' : 'Siap!',
                      style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10,
                        color: Colors.white.withOpacity(0.4), letterSpacing: 1)),
                  ],
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildLoadingBar() {
    const blockCount = 16;
    final filled = (_barAnim.value * blockCount).floor();

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Balok-balok
      Row(children: List.generate(blockCount, (i) {
        final active = i < filled;
        final isCurrent = i == filled;
        return Expanded(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 80),
            height: 18,
            margin: const EdgeInsets.symmetric(horizontal: 1.5),
            decoration: BoxDecoration(
              color: active
                ? _acc.withOpacity(0.85)
                : isCurrent
                ? _acc.withOpacity(0.3)
                : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(3),
              boxShadow: active ? [BoxShadow(color: _acc.withOpacity(0.5), blurRadius: 6)] : [],
            ),
          ),
        );
      })),

      const SizedBox(height: 6),

      // Persentase
      Text('${(_barAnim.value * 100).toInt()}%',
        style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10,
          color: Color(0xFFFF4444), letterSpacing: 1)),
    ]);
  }
}
