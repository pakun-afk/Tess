import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  bool _videoReady = false;
  bool _fadeOutStarted = false;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    _videoController =
        VideoPlayerController.asset("assets/videos/splash.mp4")
          ..initialize().then((_) {
            setState(() => _videoReady = true);
            _videoController.setLooping(false);
            _videoController.play();

            _videoController.addListener(_onVideoProgress);
          }).catchError((_) {
            // Kalau video gagal, langsung ke welcome
            _goToWelcome();
          });
  }

  void _onVideoProgress() {
    if (!mounted || _navigated) return;

    final pos = _videoController.value.position;
    final dur = _videoController.value.duration;

    // Mulai fade-out 1 detik sebelum selesai
    if (dur.inMilliseconds > 0 &&
        pos >= dur - const Duration(seconds: 1) &&
        !_fadeOutStarted) {
      _fadeOutStarted = true;
      _fadeController.forward();
    }

    // Navigasi saat video habis
    if (dur.inMilliseconds > 0 && pos >= dur) {
      _goToWelcome();
    }
  }

  void _goToWelcome() {
    if (_navigated) return;
    _navigated = true;
    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, anim, __) => FadeTransition(
          opacity: anim,
          child: WelcomeScreen(
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listDoos: widget.listDoos,
            news: widget.news,
          ),
        ),
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  void dispose() {
    _videoController.removeListener(_onVideoProgress);
    _videoController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Video background
          if (_videoReady)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoController.value.size.width,
                height: _videoController.value.size.height,
                child: VideoPlayer(_videoController),
              ),
            )
          else
            Container(
              color: Colors.black,
              child: const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFFB22222),
                  strokeWidth: 2,
                ),
              ),
            ),

          // Nama app di bawah
          Positioned(
            bottom: 80,
            left: 0, right: 0,
            child: Center(
              child: Text(
                "Riff Base",
                style: TextStyle(
                  fontSize: 42,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  color: Colors.white,
                  letterSpacing: 4,
                  shadows: [
                    Shadow(
                      color: Colors.redAccent.withOpacity(0.9),
                      blurRadius: 20,
                      offset: const Offset(2, 2),
                    ),
                    Shadow(
                      color: Colors.black.withOpacity(0.8),
                      blurRadius: 15,
                      offset: const Offset(-2, -2),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Fade-out overlay
          if (_fadeOutStarted)
            AnimatedBuilder(
              animation: _fadeController,
              builder: (_, __) => Opacity(
                opacity: _fadeController.value,
                child: Container(color: Colors.black),
              ),
            ),
        ],
      ),
    );
  }
}
