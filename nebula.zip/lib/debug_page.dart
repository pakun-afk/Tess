import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'config_service.dart';

class DebugPage extends StatefulWidget {
  const DebugPage({super.key});
  @override State<DebugPage> createState() => _DebugPageState();
}

class _DebugPageState extends State<DebugPage> {
  static const _bg    = Colors.black;
  static const _red   = Color(0xFFB22222);
  static const _acc   = Color(0xFFFF4444);
  static const _neon  = Color(0xFF00FF88);
  static const _gold  = Color(0xFFFFD700);
  static const _mono  = 'ShareTechMono';
  static const _orb   = 'Orbitron';

  bool _refreshing   = false;
  bool _testLoading  = false;
  Map<String, dynamic>? _testResult;
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure   = true;
  int  _tab       = 0; // 0=status, 1=test login, 2=logs

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: cfg,
      builder: (_, __) => Scaffold(
        backgroundColor: _bg,
        body: Stack(children: [
          // bg glow
          Positioned(top: -60, left: -60, child: Container(width: 200, height: 200,
            decoration: BoxDecoration(shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _red.withOpacity(0.12), blurRadius: 100, spreadRadius: 50)]))),
          SafeArea(child: Column(children: [
            _header(),
            _tabs(),
            Expanded(child: SingleChildScrollView(
              padding: const EdgeInsets.all(14),
              child: _tab == 0 ? _statusTab()
                   : _tab == 1 ? _testLoginTab()
                   : _logsTab(),
            )),
          ])),
        ]),
      ),
    );
  }

  // ─── HEADER ────────────────────────────────────────────────
  Widget _header() => Container(
    padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: _acc.withOpacity(0.15)))),
    child: Row(children: [
      _iconBtn(Icons.arrow_back_ios_new, onTap: () => Navigator.pop(context)),
      const SizedBox(width: 12),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('DEBUG PANEL', style: TextStyle(fontFamily: _orb, fontSize: 13, color: Colors.white, letterSpacing: 2,
          shadows: [Shadow(color: _neon, blurRadius: 8)])),
        Text('Connection & Test', style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white38)),
      ]),
      const Spacer(),
      _refreshing
        ? const SizedBox(width: 34, height: 34, child: Center(
            child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _neon, strokeWidth: 2))))
        : _iconBtn(Icons.refresh_rounded, color: _neon, onTap: _doRefresh),
    ]),
  );

  Widget _iconBtn(IconData ic, {Color color = Colors.white, VoidCallback? onTap}) =>
    GestureDetector(onTap: onTap, child: Container(width: 34, height: 34,
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), borderRadius: BorderRadius.circular(9),
        border: Border.all(color: color.withOpacity(0.25))),
      child: Icon(ic, color: color, size: 15)));

  // ─── TABS ───────────────────────────────────────────────────
  Widget _tabs() => Container(
    margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(10)),
    child: Row(children: [
      _tabItem(0, '🔌 Status'),
      _tabItem(1, '🔑 Test Login'),
      _tabItem(2, '📋 Log'),
    ]),
  );

  Widget _tabItem(int i, String label) {
    final active = _tab == i;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _tab = i),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: active ? _acc.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: active ? _acc.withOpacity(0.5) : Colors.transparent)),
        child: Text(label, textAlign: TextAlign.center,
          style: TextStyle(fontFamily: _mono, fontSize: 10,
            color: active ? _acc : Colors.white38,
            fontWeight: active ? FontWeight.bold : FontWeight.normal)),
      ),
    ));
  }

  // ─── STATUS TAB ─────────────────────────────────────────────
  Widget _statusTab() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const SizedBox(height: 14),

    // Koneksi status besar
    _card(child: Column(children: [
      Row(children: [
        AnimatedContainer(duration: const Duration(milliseconds: 400),
          width: 14, height: 14,
          decoration: BoxDecoration(shape: BoxShape.circle, color: cfg.statusColor,
            boxShadow: [BoxShadow(color: cfg.statusColor, blurRadius: 8, spreadRadius: 2)])),
        const SizedBox(width: 10),
        Text(cfg.connMsg, style: TextStyle(fontFamily: _mono, fontSize: 13, color: cfg.statusColor)),
        const Spacer(),
        if (cfg.pingMs >= 0) _badge('${cfg.pingMs}ms', _neon),
      ]),
      const SizedBox(height: 14),
      _row('Gist', cfg.fromGist ? '✅ Berhasil' : '❌ Gagal', valueColor: cfg.fromGist ? _neon : _acc),
      _row('Base URL', cfg.baseUrl.isEmpty ? '⚠️ Kosong' : cfg.baseUrl,
           valueColor: cfg.baseUrl.isEmpty ? _gold : Colors.white70),
      _row('WS URL', cfg.wsUrl.isEmpty ? '⚠️ Kosong' : cfg.wsUrl,
           valueColor: cfg.wsUrl.isEmpty ? _gold : Colors.white70),
      if (cfg.lastError != null) ...[
        const SizedBox(height: 8),
        Container(width: double.infinity, padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: _acc.withOpacity(0.08), borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _acc.withOpacity(0.3))),
          child: Text(cfg.lastError!, style: const TextStyle(fontFamily: _mono, fontSize: 9, color: _acc))),
      ],
    ])),

    const SizedBox(height: 10),

    // Gist URL info
    _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _sectionTitle('⚙️ GIST URL'),
      const SizedBox(height: 8),
      Text('https://gist.githubusercontent.com/pakun-afk/97f1b034dfac9756313f4519b793f91a/raw/config.json',
        style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white38)),
      const SizedBox(height: 10),
      Row(children: [
        _btn('Copy Base URL', _acc, () {
          Clipboard.setData(ClipboardData(text: cfg.baseUrl));
          _snack('✅ Disalin: ${cfg.baseUrl}');
        }),
        const SizedBox(width: 8),
        _btn('Copy WS URL', _neon, () {
          Clipboard.setData(ClipboardData(text: cfg.wsUrl));
          _snack('✅ Disalin: ${cfg.wsUrl}');
        }),
      ]),
    ])),
  ]);

  // ─── TEST LOGIN TAB ──────────────────────────────────────────
  Widget _testLoginTab() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const SizedBox(height: 14),

    if (cfg.baseUrl.isEmpty)
      _errorBox('⚠️ Base URL belum ada!\nGist belum berhasil dimuat. Refresh dulu.')
    else ...[
      _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _sectionTitle('🔑 TEST LOGIN API'),
        const SizedBox(height: 4),
        Text('Target: ${cfg.baseUrl}/login', style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white38)),
        const SizedBox(height: 14),

        // Username
        _input(_userCtrl, 'Username', Icons.person_outline),
        const SizedBox(height: 10),
        // Password
        _inputPass(),
        const SizedBox(height: 14),

        // Tombol test
        SizedBox(width: double.infinity,
          child: GestureDetector(
            onTap: _testLoading ? null : _doTestLogin,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(vertical: 13),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: _testLoading
                  ? [Colors.white.withOpacity(0.12), Colors.white.withOpacity(0.12)]
                  : [_red, _acc]),
                borderRadius: BorderRadius.circular(10),
                boxShadow: _testLoading ? [] : [BoxShadow(color: _acc.withOpacity(0.35), blurRadius: 12)],
              ),
              child: Center(child: _testLoading
                ? const Row(mainAxisSize: MainAxisSize.min, children: [
                    SizedBox(width: 14, height: 14, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                    SizedBox(width: 8),
                    Text('TESTING...', style: TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white)),
                  ])
                : const Text('🚀 TEST LOGIN', style: TextStyle(fontFamily: _orb, fontSize: 12, color: Colors.white, letterSpacing: 1))),
            ),
          ),
        ),
      ])),
    ],

    // Hasil test
    if (_testResult != null) ...[
      const SizedBox(height: 12),
      _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _sectionTitle('📊 HASIL'),
          const Spacer(),
          _badge(_testResult!['ok'] == true ? '✅ BERHASIL' : '❌ GAGAL',
                 _testResult!['ok'] == true ? _neon : _acc),
        ]),
        const SizedBox(height: 10),
        if (_testResult!['status'] != null) _row('HTTP', '${_testResult!['status']}'),
        if (_testResult!['ping'] != null)   _row('Waktu', '${_testResult!['ping']}ms'),
        _row('Pesan', _testResult!['msg'] ?? '-', valueColor: _testResult!['ok'] == true ? _neon : _acc),
        if (_testResult!['raw'] != null) ...[
          const SizedBox(height: 10),
          _sectionTitle('RAW RESPONSE'),
          const SizedBox(height: 6),
          Container(width: double.infinity, padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(8)),
            child: Text(_testResult!['raw'].toString(),
              style: const TextStyle(fontFamily: _mono, fontSize: 8, color: Colors.white54))),
        ],
      ])),
    ],
  ]);

  // ─── LOGS TAB ────────────────────────────────────────────────
  Widget _logsTab() {
    final logs = List<String>.from(ConfigService.logs.reversed);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 14),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('${logs.length} log entries', style: TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white38)),
        GestureDetector(
          onTap: () { ConfigService.logs.clear(); setState(() {}); },
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: _acc.withOpacity(0.1), borderRadius: BorderRadius.circular(6),
              border: Border.all(color: _acc.withOpacity(0.3))),
            child: const Text('Clear', style: TextStyle(fontFamily: _mono, fontSize: 10, color: _acc)))),
      ]),
      const SizedBox(height: 10),
      _card(child: logs.isEmpty
        ? const Text('Belum ada log', style: TextStyle(fontFamily: _mono, fontSize: 11, color: Colors.white24))
        : Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: logs.map((l) {
              Color c = Colors.white38;
              if (l.contains('✅') || l.contains('OK'))    c = _neon;
              if (l.contains('❌') || l.contains('gagal')) c = _acc;
              if (l.contains('⚠️'))                        c = _gold;
              return Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(l, style: TextStyle(fontFamily: _mono, fontSize: 9, color: c)));
            }).toList())),
    ]);
  }

  // ─── WIDGETS ─────────────────────────────────────────────────
  Widget _card({required Widget child}) => Container(
    width: double.infinity, padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(13),
      border: Border.all(color: Colors.white.withOpacity(0.07))),
    child: child,
  );

  Widget _sectionTitle(String t) => Text(t,
    style: const TextStyle(fontFamily: _orb, fontSize: 10, color: Colors.white60, letterSpacing: 1));

  Widget _row(String k, String v, {Color? valueColor}) => Padding(
    padding: const EdgeInsets.only(bottom: 5),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 72, child: Text(k, style: const TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white38))),
      const Text(' : ', style: TextStyle(color: Colors.white24, fontSize: 9)),
      Expanded(child: Text(v, style: TextStyle(fontFamily: _mono, fontSize: 9, color: valueColor ?? Colors.white70))),
    ]),
  );

  Widget _badge(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(6),
      border: Border.all(color: color.withOpacity(0.4))),
    child: Text(label, style: TextStyle(fontFamily: _mono, fontSize: 9, color: color)));

  Widget _btn(String label, Color color, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.35))),
      child: Text(label, style: TextStyle(fontFamily: _mono, fontSize: 10, color: color))));

  Widget _input(TextEditingController c, String hint, IconData icon) => Container(
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(9),
      border: Border.all(color: Colors.white.withOpacity(0.1))),
    child: TextField(controller: c, style: const TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white),
      decoration: InputDecoration(
        hintText: hint, hintStyle: const TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white24),
        prefixIcon: Icon(icon, color: Colors.white38, size: 16),
        border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 13))));

  Widget _inputPass() => Container(
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(9),
      border: Border.all(color: Colors.white.withOpacity(0.1))),
    child: TextField(controller: _passCtrl, obscureText: _obscure,
      style: const TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white),
      decoration: InputDecoration(
        hintText: 'Password', hintStyle: const TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white24),
        prefixIcon: const Icon(Icons.lock_outline, color: Colors.white38, size: 16),
        suffixIcon: GestureDetector(onTap: () => setState(() => _obscure = !_obscure),
          child: Icon(_obscure ? Icons.visibility_off : Icons.visibility, color: Colors.white38, size: 16)),
        border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 13))));

  Widget _errorBox(String msg) => Container(
    width: double.infinity, padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: _gold.withOpacity(0.08), borderRadius: BorderRadius.circular(12),
      border: Border.all(color: _gold.withOpacity(0.3))),
    child: Text(msg, style: const TextStyle(fontFamily: _mono, fontSize: 11, color: _gold)));

  // ─── ACTIONS ─────────────────────────────────────────────────
  Future<void> _doRefresh() async {
    setState(() { _refreshing = true; _testResult = null; });
    await cfg.refresh();
    if (mounted) setState(() => _refreshing = false);
  }

  Future<void> _doTestLogin() async {
    if (_userCtrl.text.trim().isEmpty || _passCtrl.text.isEmpty) {
      _snack('⚠️ Isi username & password dulu');
      return;
    }
    setState(() { _testLoading = true; _testResult = null; });
    final result = await cfg.testLogin(_userCtrl.text.trim(), _passCtrl.text);
    if (mounted) setState(() { _testLoading = false; _testResult = result; });
  }

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(fontFamily: _mono, fontSize: 11)),
    backgroundColor: const Color(0xFF1A1A1A),
    duration: const Duration(seconds: 2)));
}
