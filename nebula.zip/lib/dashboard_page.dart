import 'dart:ui'; // Untuk ImageFilter
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'config_service.dart';
import 'package:provider/provider.dart'; // <-- TAMBAHKAN INI
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'admin_page.dart';
import 'owner_page.dart';
import 'rat_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'settings_page.dart';
import 'theme_provider.dart'; // <-- TAMBAHKAN INI
import 'game_hub.dart';
import 'public_chat.dart';
import 'vps_page.dart';
import 'cvps_panel_page.dart';
import 'dart:math' as math;

// CLIPPER UNTUK MEMBUAT BAGIAN BAWAH MELENGKUNG - DILUAR CLASS
class BottomCurveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - 40);
    path.quadraticBezierTo(size.width / 2, size.height, size.width, size.height - 40);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // --- State Variabel ---
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  // --- Fitur Profil & Menu Baru ---
  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- VARIABEL UNTUK FLOATING WINDOW ---
  bool _isFloatingMenuOpen = false;
  late AnimationController _floatingController;
  late Animation<double> _floatingScaleAnimation;
  late Animation<double> _floatingFadeAnimation;
  late Animation<Offset> _floatingSlideAnimation;
  
  // Variabel untuk draggable floating button
  Offset _floatingButtonPosition = const Offset(20, 100);
  final double _floatingButtonSize = 65;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    // Inisialisasi Floating Button Animation dengan durasi lebih smooth
    _floatingController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    
    _floatingScaleAnimation = CurvedAnimation(
      parent: _floatingController,
      curve: Curves.easeOutBack,
    );
    
    _floatingFadeAnimation = CurvedAnimation(
      parent: _floatingController,
      curve: Curves.easeIn,
    );
    
    _floatingSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _floatingController,
      curve: Curves.easeOutCubic,
    ));

    // Set posisi awal setelah layout terbentuk
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _setInitialPosition();
    });

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
    _loadFloatingButtonPosition();
  }

  void _setInitialPosition() {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    setState(() {
      _floatingButtonPosition = Offset(
        screenWidth - _floatingButtonSize - 20,
        screenHeight * 0.3,
      );
    });
  }

  Future<void> _loadFloatingButtonPosition() async {
    final prefs = await SharedPreferences.getInstance();
    final double dx = prefs.getDouble('floating_button_dx') ?? _floatingButtonPosition.dx;
    final double dy = prefs.getDouble('floating_button_dy') ?? _floatingButtonPosition.dy;
    
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    
    double validDx = dx.clamp(0, screenWidth - _floatingButtonSize);
    double validDy = dy.clamp(0, screenHeight - _floatingButtonSize - kBottomNavigationBarHeight);
    
    setState(() {
      _floatingButtonPosition = Offset(validDx, validDy);
    });
  }

  Future<void> _saveFloatingButtonPosition(Offset position) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('floating_button_dx', position.dx);
    await prefs.setDouble('floating_button_dy', position.dy);
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  void _initMenuVideo() {
    _menuVideoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() {});
        _menuVideoController?.setLooping(true);
        _menuVideoController?.play();
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('${wsBaseUrl}/ws'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    
    final theme = Theme.of(context);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: theme.scaffoldBackgroundColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("⚠️ Session Expired", 
          style: TextStyle(
            color: theme.colorScheme.secondary, 
            fontWeight: FontWeight.bold
          )
        ),
        content: Text(message, style: TextStyle(color: Colors.grey.shade500)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: Text("OK", 
              style: TextStyle(
                color: theme.primaryColor, 
                fontWeight: FontWeight.bold
              )
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToPage(Widget page) {
    _toggleFloatingMenu();
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _navigateToPageAndReplace(Widget page) {
    _toggleFloatingMenu();
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
  }

  void _toggleFloatingMenu() {
    if (_isDragging) return;
    
    setState(() {
      _isFloatingMenuOpen = !_isFloatingMenuOpen;
      if (_isFloatingMenuOpen) {
        _floatingController.forward();
      } else {
        _floatingController.reverse();
      }
    });
  }

  void _closeFloatingMenu() {
    if (_isFloatingMenuOpen) {
      _toggleFloatingMenu();
    }
  }

  void _onFloatingButtonDragStart(DragStartDetails details) {
    setState(() {
      _isDragging = true;
    });
  }

  void _onFloatingButtonDragUpdate(DragUpdateDetails details) {
    setState(() {
      double newDx = _floatingButtonPosition.dx + details.delta.dx;
      double newDy = _floatingButtonPosition.dy + details.delta.dy;
      
      final screenWidth = MediaQuery.of(context).size.width;
      final screenHeight = MediaQuery.of(context).size.height;
      final safeAreaTop = MediaQuery.of(context).padding.top + kToolbarHeight + 10;
      final safeAreaBottom = screenHeight - MediaQuery.of(context).padding.bottom - kBottomNavigationBarHeight - 10;
      
      newDx = newDx.clamp(5, screenWidth - _floatingButtonSize - 5);
      newDy = newDy.clamp(safeAreaTop, safeAreaBottom);
      
      _floatingButtonPosition = Offset(newDx, newDy);
    });
  }

  void _onFloatingButtonDragEnd(DragEndDetails details) {
    setState(() {
      _isDragging = false;
    });
    _saveFloatingButtonPosition(_floatingButtonPosition);
  }

  void _openHomePage() {
    _navigateToPageAndReplace(DashboardPage(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      listBug: listBug,
      listDoos: listDoos,
      sessionKey: sessionKey,
      news: newsList,
    ));
  }

  void _openWhatsAppPage() {
    _navigateToPage(HomePage(
      username: username,
      password: password,
      listBug: listBug,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey,
    ));
  }

  void _openInfoPage() {
    _navigateToPage(InfoPage(sessionKey: sessionKey));
  }

  void _openToolsPage() {
    _navigateToPage(ToolsPage(
      sessionKey: sessionKey,
      userRole: role,
      listDoos: listDoos,
    ));
  }

  void _openChangePassword() {
    _navigateToPage(ChangePasswordPage(
      username: username,
      sessionKey: sessionKey,
    ));
  }

  void _openBugSender() {
    _navigateToPage(HomePage(
      username: username,
      password: password,
      listBug: listBug,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey,
    ));
  }

  void _openToolsGateway() {
    _navigateToPage(ToolsPage(
      sessionKey: sessionKey,
      userRole: role,
      listDoos: listDoos,
    ));
  }

  void _openProfile() {
    _navigateToPage(ProfilePage(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey,
    ));
  }

  void _openRiwayat() {
    _navigateToPage(RiwayatPage(
      sessionKey: sessionKey,
      role: role,
    ));
  }

  void _openContact() {
    _navigateToPage(ContactPage());
  }

  void _openSellerPage() {
    if (role == "reseller") {
      _navigateToPage(SellerPage(keyToken: sessionKey));
    }
  }

  void _openAdminPage() {
    if (role == "admin") {
      _navigateToPage(AdminPage(sessionKey: sessionKey));
    }
  }

  void _openOwnerPage() {
    if (role == "owner") {
      _navigateToPage(OwnerPage(sessionKey: sessionKey, username: username));
    }
  }

  void _openRatPage() {
    Navigator.push(context, PageRouteBuilder(
      pageBuilder: (_, __, ___) => ControlCenterPage(sessionKey: sessionKey),
      transitionDuration: const Duration(milliseconds: 400),
      transitionsBuilder: (_, anim, __, child) =>
        FadeTransition(opacity: anim, child: child)));
  }

  void _openSettingsPage() {
    _toggleFloatingMenu();
    Navigator.push(context, MaterialPageRoute(builder: (context) => SettingsPage()));
  }

  void _openVpsManager() {
    _navigateToPage(VpsPage(sessionKey: sessionKey));
  }

  void _openCvpsPanel() {
    _toggleFloatingMenu();
    Navigator.push(context, PageRouteBuilder(
      pageBuilder: (_, __, ___) => CvpsPanelPage(username: username, sessionKey: sessionKey),
      transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
    ));
  }

  void _openGameHub() {
    _toggleFloatingMenu();
    Navigator.push(context, MaterialPageRoute(builder: (_) => GameHubPage(username: username, sessionKey: sessionKey)));
  }

  void _openPublicChat() {
    _toggleFloatingMenu();
    Navigator.push(context, MaterialPageRoute(builder: (_) => PublicChatPage(username: username, sessionKey: sessionKey, role: role)));
  }

  void _logout() async {
    _toggleFloatingMenu();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  // WIDGET DENGAN EFEK GLOW (MENGGUNAKAN THEME)
  Widget _buildGlowContainer({
    required Widget child,
    double blurRadius = 20,
    double spreadRadius = 1,
    Color? glowColor,
    double opacity = 0.3,
    BorderRadius? borderRadius,
  }) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        borderRadius: borderRadius,
        boxShadow: [
          BoxShadow(
            color: (glowColor ?? theme.primaryColor).withOpacity(opacity),
            blurRadius: blurRadius,
            spreadRadius: spreadRadius,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _buildGlowText({
    required String text,
    required TextStyle style,
    double blurRadius = 10,
    Color? glowColor,
  }) {
    final theme = Theme.of(context);
    return Text(
      text,
      style: style.copyWith(
        shadows: [
          Shadow(
            color: (glowColor ?? theme.primaryColor).withOpacity(0.5),
            blurRadius: blurRadius,
          ),
        ],
      ),
    );
  }

  Widget _buildNewsPage() {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;
    
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            bgColor,
            primaryColor.withOpacity(0.2),
            bgColor,
          ],
          stops: const [0.0, 0.3, 1.0],
        ),
      ),
      child: Stack(
        children: [
          // Efek blur background
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
              child: Container(
                color: Colors.transparent,
              ),
            ),
          ),
          
          // Efek glow background
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.15),
                    blurRadius: 150,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          
          Positioned(
            bottom: -50,
            left: -50,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.1),
                    blurRadius: 100,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),
          
          // Konten utama
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // HEADER DENGAN DESAIN MENARIK - FOTO MELENGKUNG
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 25),
                  child: Stack(
                    children: [
                      // Background image dengan border radius melengkung
                      ClipPath(
                        clipper: BottomCurveClipper(),
                        child: Container(
                          height: 260,
                          width: double.infinity,
                          child: Image.asset(
                            'assets/images/titit.png',
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                color: primaryColor.withOpacity(0.3),
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.broken_image, color: accentColor, size: 50),
                                      const SizedBox(height: 10),
                                      Text(
                                        'titit.png not found',
                                        style: TextStyle(color: Colors.grey.shade500),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      
                      // Overlay gradient
                      ClipPath(
                        clipper: BottomCurveClipper(),
                        child: Container(
                          height: 260,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                bgColor.withOpacity(0.7),
                                bgColor.withOpacity(0.95),
                              ],
                              stops: const [0.0, 0.5, 1.0],
                            ),
                          ),
                        ),
                      ),
                      
                      // Efek garis di bagian bawah lengkungan
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          height: 3,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                accentColor,
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                      ),
                      
                      // Konten teks
                      Positioned(
                        bottom: 40,
                        left: 20,
                        right: 20,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 5,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: accentColor,
                                    borderRadius: BorderRadius.circular(5),
                                    boxShadow: [
                                      BoxShadow(
                                        color: accentColor.withOpacity(0.8),
                                        blurRadius: 15,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 15),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      _buildGlowText(
                                        text: "Arya developer",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 32,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Orbitron',
                                          letterSpacing: 2,
                                        ),
                                        blurRadius: 25,
                                      ),
                                      const SizedBox(height: 5),
                                      Row(
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                            decoration: BoxDecoration(
                                              color: accentColor.withOpacity(0.2),
                                              borderRadius: BorderRadius.circular(12),
                                              border: Border.all(color: accentColor.withOpacity(0.5)),
                                            ),
                                            child: Text(
                                              "Paviliun",
                                              style: TextStyle(
                                                color: accentColor,
                                                fontSize: 10,
                                                fontWeight: FontWeight.bold,
                                                letterSpacing: 1,
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 10),
                                          Text(
                                            "Phoenix",
                                            style: TextStyle(
                                              color: Colors.white70,
                                              fontSize: 12,
                                              fontFamily: 'ShareTechMono',
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 15),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.4),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: accentColor.withOpacity(0.3)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.timer, color: accentColor, size: 14),
                                  const SizedBox(width: 5),
                                  Text(
                                    expiredDate,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 11,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Efek dekoratif
                      Positioned(
                        top: 20,
                        right: 20,
                        child: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: accentColor.withOpacity(0.3), width: 1),
                            boxShadow: [
                              BoxShadow(
                                color: accentColor.withOpacity(0.2),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Icon(Icons.circle, color: accentColor, size: 8),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ONLINE & CONNECTIONS dengan glow
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  child: _buildGlowContainer(
                    blurRadius: 30,
                    spreadRadius: 2,
                    opacity: 0.2,
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: theme.cardColor.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: _buildModernInfoItem(
                              icon: Icons.people,
                              label: "Online Users",
                              value: "$onlineUsers",
                              color: Colors.blue,
                            ),
                          ),
                          Container(
                            height: 40,
                            width: 1,
                            color: accentColor.withOpacity(0.3),
                          ),
                          Expanded(
                            child: _buildModernInfoItem(
                              icon: Icons.link,
                              label: "Online Sender",
                              value: "$activeConnections",
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // STATS CARD
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildStatsCard(
                          icon: Icons.speed,
                          label: "Server Status",
                          value: "Online",
                          color: Colors.green,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildStatsCard(
                          icon: Icons.access_time,
                          label: "Uptime",
                          value: "99.9%",
                          color: accentColor,
                        ),
                      ),
                    ],
                  ),
                ),

                // Welcome Text
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  child: _buildGlowContainer(
                    blurRadius: 20,
                    opacity: 0.15,
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: theme.cardColor.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white.withOpacity(0.05)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 3,
                                height: 30,
                                decoration: BoxDecoration(
                                  color: accentColor,
                                  borderRadius: BorderRadius.circular(3),
                                ),
                              ),
                              const SizedBox(width: 12),
                              _buildGlowText(
                                text: "Arya developer Is Impossible...",
                                style: TextStyle(
                                  color: accentColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                ),
                                blurRadius: 15,
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 15,
                                  backgroundColor: accentColor.withOpacity(0.3),
                                  child: Text(
                                    username[0].toUpperCase(),
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Welcome back,",
                                        style: TextStyle(color: Colors.grey.shade500, fontSize: 11),
                                      ),
                                      Text(
                                        username,
                                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: primaryColor.withOpacity(0.3),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    role,
                                    style: TextStyle(color: accentColor, fontSize: 10, fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // Feature Cards
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildModernFeatureCard(
                          icon: Icons.flash_on,
                          title: "Gacor",
                          subtitle: "Fast Bug",
                          color: const Color(0xFFFFD700),
                          gradientColors: [Color(0xFFFFD700).withOpacity(0.2), Color(0xFFFFA500).withOpacity(0.1)],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildModernFeatureCard(
                          icon: Icons.verified,
                          title: "High Quality",
                          subtitle: "Server Stable",
                          color: const Color(0xFF4CAF50),
                          gradientColors: [Color(0xFF4CAF50).withOpacity(0.2), Color(0xFF2E7D32).withOpacity(0.1)],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildModernFeatureCard(
                          icon: Icons.whatshot,
                          title: "Damn",
                          subtitle: "Simple",
                          color: accentColor,
                          gradientColors: [accentColor.withOpacity(0.2), primaryColor.withOpacity(0.1)],
                        ),
                      ),
                    ],
                  ),
                ),

                // PROJECT INFO CARD
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  child: _buildGlowContainer(
                    blurRadius: 20,
                    opacity: 0.15,
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: theme.cardColor.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white.withOpacity(0.05)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: accentColor.withOpacity(0.2),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.terminal, color: Colors.white, size: 24),
                          ),
                          const SizedBox(width: 15),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildGlowText(
                                  text: "developer is Arya [Paviliun Phoenix]",
                                  style: TextStyle(
                                    color: accentColor,
                                    fontSize: 13,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.bold,
                                  ),
                                  blurRadius: 8,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  "Buy Access Chat Me @UPINNOFFICIALREAL",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [accentColor, primaryColor],
                              ),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: accentColor.withOpacity(0.5),
                                  blurRadius: 15,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                            child: const Icon(Icons.telegram, color: Colors.white, size: 18),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // ACTION BUTTONS
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildModernActionButton(
                          icon: Icons.people_outline,
                          label: "Join Community",
                          onTap: () => _openUrl("https://t.me/allinfo_PAVILIUN_PHOENIX"),
                          gradientColors: [const Color(0xFF0088cc), const Color(0xFF0055aa)],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildModernActionButton(
                          icon: Icons.bug_report,
                          label: "Manage Bug",
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => BugSenderPage(
                                  sessionKey: sessionKey,
                                  username: username,
                                  role: role,
                                ),
                              ),
                            );
                          },
                          gradientColors: [accentColor, primaryColor],
                        ),
                      ),
                    ],
                  ),
                ),

                // ROLE PANEL BUTTON (Owner / Admin / Reseller)
                if (role == "owner" || role == "admin" || role == "reseller")
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                    child: GestureDetector(
                      onTap: role == "owner" ? _openOwnerPage
                           : role == "admin" ? _openAdminPage
                           : _openSellerPage,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: role == "owner"
                              ? [const Color(0xFFFFD700), const Color(0xFFFFA500)]
                              : role == "admin"
                              ? [const Color(0xFF7B2FBE), const Color(0xFF4A00E0)]
                              : [const Color(0xFF00C6FF), const Color(0xFF0078FF)],
                          ),
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [BoxShadow(
                            color: (role == "owner"
                              ? Color(0xFFFFD700)
                              : role == "admin"
                              ? Color(0xFF7B2FBE)
                              : Color(0xFF00C6FF)).withOpacity(0.4),
                            blurRadius: 16, spreadRadius: 1,
                          )],
                        ),
                        child: Row(children: [
                          Icon(
                            role == "owner" ? Icons.workspace_premium
                            : role == "admin" ? Icons.admin_panel_settings
                            : Icons.storefront,
                            color: Colors.white, size: 22,
                          ),
                          const SizedBox(width: 12),
                          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(
                              role == "owner" ? "OWNER PANEL"
                              : role == "admin" ? "ADMIN PANEL"
                              : "RESELLER PANEL",
                              style: const TextStyle(fontFamily: 'Orbitron', fontSize: 13,
                                color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1),
                            ),
                            Text(
                              role == "owner" ? "Kelola seluruh sistem"
                              : role == "admin" ? "Kelola user & notifikasi"
                              : "Kelola akun & penjualan",
                              style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9,
                                color: Colors.white.withOpacity(0.7)),
                            ),
                          ]),
                          const Spacer(),
                          const Icon(Icons.arrow_forward_ios, color: Colors.white, size: 14),
                        ]),
                      ),
                    ),
                  ),

                // RAT — GHOST CONTROL (owner only)
                if (role == "owner")
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
                    child: GestureDetector(
                      onTap: _openRatPage,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 18),
                        decoration: BoxDecoration(
                          color: const Color(0xFF060608),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Color(0xFF00FFFF).withOpacity(0.35)),
                          boxShadow: [BoxShadow(
                            color: Color(0xFF00FFFF).withOpacity(0.08),
                            blurRadius: 16, spreadRadius: 0)],
                        ),
                        child: Row(children: [
                          Container(
                            width: 36, height: 36,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFF00FFFF).withOpacity(0.07),
                              border: Border.all(color: Color(0xFF00FFFF).withOpacity(0.3))),
                            child: const Center(child: Text('◈',
                              style: TextStyle(fontSize: 18, color: Color(0xFF00FFFF))))),
                          const SizedBox(width: 14),
                          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            const Text('GHOST CONTROL',
                              style: TextStyle(fontFamily: 'Orbitron', fontSize: 12,
                                color: Color(0xFF00FFFF), letterSpacing: 1.5,
                                shadows: [Shadow(color: Color(0xFF00FFFF), blurRadius: 6)])),
                            Text('Remote Access  •  Target Monitor',
                              style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9,
                                color: Colors.white.withOpacity(0.35))),
                          ]),
                          const Spacer(),
                          Text('▶', style: TextStyle(
                            color: Color(0xFF00FFFF).withOpacity(0.5), fontSize: 14)),
                        ]),
                      ),
                    ),
                  ),

                // VPS MANAGER BUTTON
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  child: GestureDetector(
                    onTap: _openVpsManager,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFF0D47A1), Color(0xFF1565C0)]),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [BoxShadow(color: Color(0xFF1565C0).withOpacity(0.4), blurRadius: 14, spreadRadius: 1)],
                      ),
                      child: Row(children: [
                        const Icon(Icons.dns_rounded, color: Colors.white, size: 22),
                        const SizedBox(width: 12),
                        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('VPS MANAGER', style: TextStyle(fontFamily: 'Orbitron', fontSize: 13,
                            color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1)),
                          Text('DigitalOcean · Vultr · Linode', style: TextStyle(
                            fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white70)),
                        ]),
                        const Spacer(),
                        const Icon(Icons.arrow_forward_ios, color: Colors.white, size: 14),
                      ]),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // NEWS SECTION
                Container(
                  width: double.infinity,
                  height: 210,
                  margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 5, bottom: 10),
                        child: Row(
                          children: [
                            Container(
                              width: 3,
                              height: 20,
                              decoration: BoxDecoration(
                                color: accentColor,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              "LATEST NEWS",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: PageView.builder(
                          controller: PageController(viewportFraction: 0.9),
                          itemCount: newsList.isEmpty ? 1 : newsList.length,
                          itemBuilder: (context, index) {
                            if (newsList.isEmpty) {
                              return _buildEmptyNewsCard();
                            }
                            final item = newsList[index];
                            return _buildModernNewsCard(item);
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // MODERN INFO ITEM
  Widget _buildModernInfoItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(color: Colors.grey.shade500, fontSize: 10),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // STATS CARD
  Widget _buildStatsCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    final theme = Theme.of(context);
    return _buildGlowContainer(
      blurRadius: 20,
      spreadRadius: 0.5,
      opacity: 0.15,
      glowColor: color,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: theme.cardColor.withOpacity(0.3),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(color: Colors.grey.shade500, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  // MODERN FEATURE CARD
  Widget _buildModernFeatureCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required List<Color> gradientColors,
  }) {
    final theme = Theme.of(context);
    return _buildGlowContainer(
      blurRadius: 20,
      spreadRadius: 0.5,
      opacity: 0.2,
      glowColor: color,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: gradientColors,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.3), width: 1),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 9,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // MODERN ACTION BUTTON
  Widget _buildModernActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required List<Color> gradientColors,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: _buildGlowContainer(
        blurRadius: 30,
        spreadRadius: 2,
        opacity: 0.3,
        glowColor: gradientColors.last,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: gradientColors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // MODERN NEWS CARD
  Widget _buildModernNewsCard(Map<String, dynamic> item) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    
    return _buildGlowContainer(
      blurRadius: 30,
      spreadRadius: 1,
      opacity: 0.2,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: theme.cardColor.withOpacity(0.3),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              if (item['image'] != null && item['image'].toString().isNotEmpty)
                NewsMedia(url: item['image']),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withOpacity(0.8),
                      Colors.transparent,
                      primaryColor.withOpacity(0.3),
                    ],
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                  ),
                ),
              ),
              Positioned(
                bottom: 16,
                left: 16,
                right: 16,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildGlowText(
                      text: item['title'] ?? 'No Title',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: "Orbitron",
                        fontWeight: FontWeight.bold,
                      ),
                      blurRadius: 15,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item['desc'] ?? '',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.3),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.new_releases, color: Colors.white, size: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyNewsCard() {
    final theme = Theme.of(context);
    return _buildGlowContainer(
      blurRadius: 15,
      opacity: 0.1,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: theme.cardColor.withOpacity(0.3),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.newspaper, color: Colors.grey.shade500, size: 40),
              const SizedBox(height: 10),
              Text(
                "No News Available",
                style: TextStyle(color: Colors.grey.shade500),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── RADIAL MENU ──────────────────────────────────────────────────────────────
  Widget _buildFloatingMenu() {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final cx = _floatingButtonPosition.dx + _floatingButtonSize / 2;
    final cy = _floatingButtonPosition.dy + _floatingButtonSize / 2;

    // Semua item menu melingkar
    final items = [
      {'icon': Icons.home,                 'label': 'Home',         'onTap': _openHomePage},
      {'icon': Icons.forum_rounded,        'label': 'Chat',         'onTap': _openPublicChat},
      {'icon': Icons.sports_esports,       'label': 'Games',        'onTap': _openGameHub},
      {'icon': Icons.bug_report,           'label': 'Bug',          'onTap': _openBugSender},
      {'icon': Icons.build_circle_outlined,'label': 'Tools',        'onTap': _openToolsPage},
      {'icon': Icons.dns_rounded,           'label': 'VPS',          'onTap': _openVpsManager},
      {'icon': Icons.terminal,              'label': 'CVPS',         'onTap': _openCvpsPanel},
      {'icon': Icons.info_outline,         'label': 'Info',         'onTap': _openInfoPage},
      {'icon': Icons.person,               'label': 'Profil',       'onTap': _openProfile},
      {'icon': Icons.color_lens,           'label': 'Warna',        'onTap': _openSettingsPage},
      {'icon': Icons.logout,               'label': 'Keluar',       'onTap': _logout,       'danger': true},
    ];

    final count = items.length;
    final radius = 105.0;

    return Stack(
      children: [
        // Overlay gelap
        Positioned.fill(
          child: GestureDetector(
            onTap: _closeFloatingMenu,
            child: Container(color: Colors.black.withOpacity(0.65)),
          ),
        ),

        // Lingkaran glow di tengah
        ...List.generate(count, (i) {
          final angle = (2 * math.pi / count) * i - math.pi / 2;
          final x = cx + radius * math.cos(angle) - 30;
          final y = cy + radius * math.sin(angle) - 30;
          final item = items[i];
          final isDanger = item['danger'] == true;
          final color = isDanger ? Colors.redAccent : accentColor;
          final label = item['label'] as String;
          final iconData = item['icon'] as IconData;
          final onTap = item['onTap'] as VoidCallback;

          return AnimatedBuilder(
            animation: _floatingScaleAnimation,
            builder: (_, __) {
              final scale = _floatingScaleAnimation.value;
              final px = cx + radius * math.cos(angle) * scale - 30;
              final py = cy + radius * math.sin(angle) * scale - 30;
              return Positioned(
                left: px,
                top: py,
                child: Opacity(
                  opacity: _floatingFadeAnimation.value.clamp(0.0, 1.0),
                  child: GestureDetector(
                    onTap: onTap,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 52, height: 52,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: isDanger
                                  ? [const Color(0xFF8B0000), Colors.redAccent]
                                  : [primaryColor.withOpacity(0.9), accentColor],
                              begin: Alignment.topLeft, end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: color.withOpacity(0.6),
                                blurRadius: 18, spreadRadius: 2,
                              ),
                            ],
                            border: Border.all(color: Colors.white.withOpacity(0.25), width: 1.5),
                          ),
                          child: Icon(iconData, color: Colors.white, size: 22),
                        ),
                        const SizedBox(height: 5),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.75),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: color.withOpacity(0.4)),
                          ),
                          child: Text(label, style: TextStyle(
                            fontFamily: 'ShareTechMono', fontSize: 9,
                            color: color, letterSpacing: 0.5,
                          )),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        }),

        // Role buttons moved to main dashboard
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;
    
    return Scaffold(
      backgroundColor: bgColor,
      body: Stack(
        children: [
          // Background dengan efek blur
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topLeft,
                radius: 1.5,
                colors: [
                  bgColor,
                  primaryColor.withOpacity(0.2),
                  bgColor,
                ],
              ),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
              child: Container(
                color: Colors.transparent,
              ),
            ),
          ),
          
          // Efek glow besar di background
          Positioned(
            top: -150,
            right: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.2),
                    blurRadius: 200,
                    spreadRadius: 100,
                  ),
                ],
              ),
            ),
          ),
          
          Positioned(
            bottom: -100,
            left: -50,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.15),
                    blurRadius: 150,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          
          // Konten utama
          SafeArea(
            child: _buildNewsPage(),
          ),
          
          if (_isFloatingMenuOpen)
            GestureDetector(
              onTap: _closeFloatingMenu,
              child: Container(
                color: Colors.black.withOpacity(0.7),
              ),
            ),
          
          // FLOATING BUTTON DENGAN QB.PNG dengan efek glow
          Positioned(
            left: _floatingButtonPosition.dx,
            top: _floatingButtonPosition.dy,
            child: GestureDetector(
              onTap: _toggleFloatingMenu,
              onPanStart: _onFloatingButtonDragStart,
              onPanUpdate: _onFloatingButtonDragUpdate,
              onPanEnd: _onFloatingButtonDragEnd,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: _floatingButtonSize,
                height: _floatingButtonSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: const DecorationImage(
                    image: AssetImage('assets/images/qb.png'),
                    fit: BoxFit.cover,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accentColor.withOpacity(_isFloatingMenuOpen ? 0.8 : 0.5),
                      blurRadius: _isFloatingMenuOpen ? 30 : 20,
                      spreadRadius: _isFloatingMenuOpen ? 5 : 2,
                    ),
                    BoxShadow(
                      color: primaryColor.withOpacity(0.3),
                      blurRadius: 40,
                      spreadRadius: 5,
                    ),
                  ],
                  border: Border.all(
                    color: Colors.white.withOpacity(0.8),
                    width: _isFloatingMenuOpen ? 3 : 2,
                  ),
                ),
              ),
            ),
          ),
          
          if (_isFloatingMenuOpen) _buildFloatingMenu(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _floatingController.dispose();
    _menuVideoController?.dispose();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return Center(
          child: CircularProgressIndicator(
            color: accentColor,
          ),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.grey.shade900,
          child: Icon(Icons.error, color: accentColor),
        ),
      );
    }
  }
}