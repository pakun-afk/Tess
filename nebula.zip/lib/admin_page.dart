import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config_service.dart';
import 'dart:async';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'theme_provider.dart';

// baseUrl dari config_service.dart

class AdminPage extends StatefulWidget {
  final String sessionKey;
  const AdminPage({super.key, required this.sessionKey});
  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> with SingleTickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = ['member', 'vip', 'reseller', 'admin'];
  String selectedRole = 'member';
  int currentPage = 1;
  final int itemsPerPage = 25;

  final deleteCtrl = TextEditingController();
  final usernameCtrl = TextEditingController();
  final passwordCtrl = TextEditingController();
  final dayCtrl = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  late TabController _tabCtrl;
  List<Map<String, dynamic>> _notifications = [];
  bool _loadingNotif = false;
  int _unreadCount = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _tabCtrl = TabController(length: 2, vsync: this);
    _fetchUsers();
    _fetchNotifications();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    deleteCtrl.dispose();
    usernameCtrl.dispose();
    passwordCtrl.dispose();
    dayCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('${baseUrl}/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert('Error', data['message'] ?? 'Tidak diizinkan.');
      }
    } catch (_) {
      _alert('Error', 'Gagal memuat user list.');
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() => setState(() {
    currentPage = 1;
    filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
  });

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteCtrl.text.trim();
    if (username.isEmpty) { _alert('Error', 'Masukkan username.'); return; }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('${baseUrl}/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert('Berhasil', "User '${data['user']['username']}' dihapus.");
        deleteCtrl.clear();
        _fetchUsers();
      } else {
        _alert('Gagal', data['message'] ?? 'Gagal menghapus.');
      }
    } catch (_) {
      _alert('Error', 'Tidak dapat menghubungi server.');
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = usernameCtrl.text.trim();
    final p = passwordCtrl.text.trim();
    final d = dayCtrl.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) { _alert('Error', 'Semua field wajib diisi.'); return; }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        '${baseUrl}/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      ));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert('Sukses', "Akun '${data['user']['username']}' dibuat.");
        usernameCtrl.clear(); passwordCtrl.clear(); dayCtrl.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _alert('Gagal', data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert('Error', 'Gagal menghubungi server.');
    }
    setState(() => isLoading = false);
  }

  Future<void> _fetchNotifications() async {
    setState(() => _loadingNotif = true);
    try {
      final res = await http.get(Uri.parse('${baseUrl}/adminNotifications?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        setState(() {
          _notifications = List<Map<String, dynamic>>.from(data['notifications'] ?? []);
          _unreadCount = _notifications.where((n) => n['read'] != true).length;
        });
      } else { _loadDemoNotif(); }
    } catch (_) { _loadDemoNotif(); }
    setState(() => _loadingNotif = false);
  }

  void _loadDemoNotif() => setState(() {
    _notifications = [
      {'type': 'login',    'message': 'User baru login dari device baru',     'time': DateTime.now().subtract(const Duration(minutes: 2)).toIso8601String(),  'read': false},
      {'type': 'register', 'message': 'Akun baru: testuser99',                'time': DateTime.now().subtract(const Duration(minutes: 15)).toIso8601String(), 'read': false},
      {'type': 'bug',      'message': 'Bug dikirim ke target +62812xxxx',     'time': DateTime.now().subtract(const Duration(hours: 1)).toIso8601String(),    'read': true},
      {'type': 'warning',  'message': 'Login gagal 3x berturut-turut',        'time': DateTime.now().subtract(const Duration(hours: 3)).toIso8601String(),    'read': true},
      {'type': 'info',     'message': 'Server uptime normal — 99.9%',         'time': DateTime.now().subtract(const Duration(hours: 6)).toIso8601String(),    'read': true},
    ];
    _unreadCount = _notifications.where((n) => n['read'] != true).length;
  });

  void _markAllRead() => setState(() {
    for (final n in _notifications) n['read'] = true;
    _unreadCount = 0;
  });

  String _fmtTime(String iso) {
    try {
      final diff = DateTime.now().difference(DateTime.parse(iso).toLocal());
      if (diff.inMinutes < 1) return 'Baru saja';
      if (diff.inHours < 1) return '${diff.inMinutes} menit lalu';
      if (diff.inDays < 1) return '${diff.inHours} jam lalu';
      return '${diff.inDays} hari lalu';
    } catch (_) { return ''; }
  }

  void _alert(String title, String msg) {
    if (!mounted) return;
    final theme = Theme.of(context);
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: theme.scaffoldBackgroundColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: theme.colorScheme.secondary.withOpacity(0.3))),
      title: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
      content: Text(msg, style: const TextStyle(color: Colors.white70)),
      actions: [Center(child: Container(
        decoration: BoxDecoration(gradient: LinearGradient(colors: [theme.primaryColor, theme.colorScheme.secondary]), borderRadius: BorderRadius.circular(10)),
        child: TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      ))],
    ));
  }

  Widget _input({required String label, required TextEditingController ctrl, required IconData icon, TextInputType type = TextInputType.text, bool obscure = false}) {
    final ac = Theme.of(context).colorScheme.secondary;
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: ctrl, keyboardType: type, obscureText: obscure,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label, labelStyle: TextStyle(color: ac),
          prefixIcon: Icon(icon, color: ac),
          filled: true, fillColor: theme.cardColor.withOpacity(0.3),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.12))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.12))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: ac, width: 2)),
        ),
      ),
    );
  }

  Widget _card({required String title, required IconData icon, required List<Widget> children}) {
    final theme = Theme.of(context);
    final pc = theme.primaryColor; final ac = theme.colorScheme.secondary;
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: theme.cardColor.withOpacity(0.3), borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [BoxShadow(color: pc.withOpacity(0.1), blurRadius: 14, offset: Offset(0, 4))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Container(padding: EdgeInsets.all(7), decoration: BoxDecoration(color: pc.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
              child: Icon(icon, color: ac, size: 18)),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1)),
        ]),
        const SizedBox(height: 18),
        ...children,
      ]),
    );
  }

  Widget _userTile(Map user) {
    final theme = Theme.of(context);
    final pc = theme.primaryColor; final ac = theme.colorScheme.secondary;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(color: theme.cardColor.withOpacity(0.25), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.07))),
      child: Row(children: [
        Container(padding: EdgeInsets.all(7), decoration: BoxDecoration(color: pc.withOpacity(0.15), shape: BoxShape.circle), child: Icon(Icons.person, color: ac, size: 18)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(user['username'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
          Text('${(user['role'] ?? '').toString().toUpperCase()} | Exp: ${user['expiredDate'] ?? '-'}', style: const TextStyle(color: Colors.white60, fontSize: 11)),
          Text('Parent: ${user['parent'] ?? 'SYSTEM'}', style: const TextStyle(color: Colors.white30, fontSize: 10)),
        ])),
        GestureDetector(
          onTap: () async {
            final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
              backgroundColor: theme.scaffoldBackgroundColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: Colors.redAccent.withOpacity(0.4))),
              title: const Text('Konfirmasi', style: TextStyle(color: Colors.white, fontSize: 14)),
              content: Text("Hapus user '${user['username']}'?", style: const TextStyle(color: Colors.white70)),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal', style: TextStyle(color: Colors.white38))),
                Container(
                  decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.redAccent, Colors.red]), borderRadius: BorderRadius.circular(8)),
                  child: TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                ),
              ],
            ));
            if (ok == true) { deleteCtrl.text = user['username']; _deleteUser(); }
          },
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), shape: BoxShape.circle, border: Border.all(color: Colors.redAccent.withOpacity(0.3))),
            child: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 16),
          ),
        ),
      ]),
    );
  }

  Widget _pagination() {
    final ac = Theme.of(context).colorScheme.secondary;
    return Wrap(spacing: 6, runSpacing: 6,
      children: List.generate(totalPages, (i) {
        final p = i + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = p),
          style: ElevatedButton.styleFrom(
            backgroundColor: currentPage == p ? ac : Colors.transparent,
            foregroundColor: currentPage == p ? Colors.white : Colors.white38,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            minimumSize: const Size(36, 32),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8), side: BorderSide(color: Colors.white.withOpacity(0.12))),
          ),
          child: Text('$p', style: const TextStyle(fontSize: 11)),
        );
      }),
    );
  }

  Widget _notifTab() {
    final theme = Theme.of(context);
    final pc = theme.primaryColor; final ac = theme.colorScheme.secondary;
    final bg = theme.scaffoldBackgroundColor;
    return Container(
      decoration: BoxDecoration(gradient: LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [bg, pc.withOpacity(0.06), bg],
      )),
      child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: Row(children: [
          Text('AKTIVITAS REAL-TIME', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, color: ac, letterSpacing: 1)),
          const Spacer(),
          if (_unreadCount > 0) GestureDetector(
            onTap: _markAllRead,
            child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: ac.withOpacity(0.12), borderRadius: BorderRadius.circular(8), border: Border.all(color: ac.withOpacity(0.4))),
              child: Text('TANDAI DIBACA', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: ac))),
          ),
          const SizedBox(width: 8),
          GestureDetector(onTap: _fetchNotifications, child: Icon(Icons.refresh, color: ac.withOpacity(0.5), size: 17)),
        ])),
        Expanded(child: _loadingNotif
          ? Center(child: CircularProgressIndicator(color: ac, strokeWidth: 2))
          : _notifications.isEmpty
            ? const Center(child: Text('Tidak ada notifikasi', style: TextStyle(color: Colors.white24, fontSize: 12, fontFamily: 'ShareTechMono')))
            : RefreshIndicator(
                color: ac, backgroundColor: bg, onRefresh: _fetchNotifications,
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  itemCount: _notifications.length,
                  itemBuilder: (_, i) {
                    final n = _notifications[i];
                    final type = n['type']?.toString() ?? 'info';
                    final read = n['read'] == true;
                    Color nc; IconData ni;
                    switch (type) {
                      case 'login':    nc = Colors.blueAccent;  ni = Icons.login;          break;
                      case 'register': nc = Colors.greenAccent; ni = Icons.person_add;     break;
                      case 'bug':      nc = Colors.orange;      ni = Icons.bug_report;     break;
                      case 'warning':  nc = Colors.redAccent;   ni = Icons.warning_amber;  break;
                      default:         nc = ac;                  ni = Icons.info_outline;
                    }
                    return GestureDetector(
                      onTap: () => setState(() { n['read'] = true; _unreadCount = _notifications.where((x) => x['read'] != true).length; }),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: read ? Colors.white.withOpacity(0.03) : nc.withOpacity(0.09),
                          borderRadius: BorderRadius.circular(13),
                          border: Border.all(color: read ? Colors.white.withOpacity(0.06) : nc.withOpacity(0.4)),
                          boxShadow: read ? [] : [BoxShadow(color: nc.withOpacity(0.14), blurRadius: 10)],
                        ),
                        child: Row(children: [
                          Container(width: 36, height: 36,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: nc.withOpacity(0.14), border: Border.all(color: nc.withOpacity(0.4))),
                            child: Icon(ni, color: nc, size: 17)),
                          const SizedBox(width: 11),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(n['message']?.toString() ?? '', style: TextStyle(color: read ? Colors.white54 : Colors.white, fontSize: 12, fontWeight: read ? FontWeight.normal : FontWeight.bold)),
                            const SizedBox(height: 2),
                            Text(_fmtTime(n['time']?.toString() ?? ''), style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, color: Colors.white24)),
                          ])),
                          if (!read) Container(width: 7, height: 7, decoration: BoxDecoration(shape: BoxShape.circle, color: nc, boxShadow: [BoxShadow(color: nc, blurRadius: 5)])),
                        ]),
                      ),
                    );
                  },
                ),
              ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final pc = theme.primaryColor; final ac = theme.colorScheme.secondary;
    final bg = theme.scaffoldBackgroundColor;
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg, elevation: 0,
        leading: BackButton(color: ac),
        title: Text('ADMIN PANEL', style: TextStyle(fontFamily: 'Orbitron', fontSize: 14, color: Colors.white, letterSpacing: 2)),
        actions: [
          Stack(children: [
            IconButton(icon: Icon(Icons.notifications_outlined, color: ac), onPressed: () => _tabCtrl.animateTo(1)),
            if (_unreadCount > 0) Positioned(right: 8, top: 8, child: Container(
              width: 15, height: 15, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
              child: Center(child: Text('$_unreadCount', style: const TextStyle(fontSize: 8, color: Colors.white, fontWeight: FontWeight.bold))),
            )),
          ]),
          IconButton(icon: Icon(Icons.refresh, color: ac), onPressed: () { _fetchUsers(); _fetchNotifications(); }),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: ac, indicatorWeight: 3,
          labelStyle: const TextStyle(fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 1),
          unselectedLabelColor: Colors.white38, labelColor: Colors.white,
          tabs: [
            const Tab(text: 'KELOLA USER'),
            Tab(text: _unreadCount > 0 ? 'NOTIFIKASI ($_unreadCount)' : 'NOTIFIKASI'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          // TAB 1
          Container(
            decoration: BoxDecoration(gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [bg, pc.withOpacity(0.07), bg],
            )),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Icon(Icons.admin_panel_settings, color: ac, size: 44),
                const SizedBox(height: 8),
                Text('ADMIN DASHBOARD', style: TextStyle(
                  color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron', letterSpacing: 2,
                  shadows: [Shadow(color: pc.withOpacity(0.8), blurRadius: 10)],
                )),
                const SizedBox(height: 28),

                _card(title: 'DELETE USER', icon: FontAwesomeIcons.userSlash, children: [
                  _input(label: 'Username Target', ctrl: deleteCtrl, icon: FontAwesomeIcons.user),
                  const SizedBox(height: 6),
                  SizedBox(height: 46, child: Container(
                    decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.redAccent, Colors.red]),
                        borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.3), blurRadius: 10, offset: Offset(0, 4))]),
                    child: ElevatedButton.icon(
                      onPressed: isLoading ? null : _deleteUser,
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      icon: const Icon(Icons.delete, size: 15, color: Colors.white),
                      label: const Text('DELETE ACCOUNT', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1, color: Colors.white)),
                    ),
                  )),
                ]),

                _card(title: 'CREATE ACCOUNT', icon: FontAwesomeIcons.userPlus, children: [
                  _input(label: 'Username', ctrl: usernameCtrl, icon: FontAwesomeIcons.user),
                  _input(label: 'Password', ctrl: passwordCtrl, icon: FontAwesomeIcons.lock, obscure: true),
                  _input(label: 'Durasi (Hari)', ctrl: dayCtrl, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.2), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.12))),
                    child: DropdownButtonHideUnderline(child: DropdownButton<String>(
                      value: newUserRole, dropdownColor: bg, style: const TextStyle(color: Colors.white),
                      items: roleOptions.map((r) => DropdownMenuItem(value: r, child: Text(r.toUpperCase()))).toList(),
                      onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
                    )),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(height: 46, child: Container(
                    decoration: BoxDecoration(gradient: LinearGradient(colors: [pc, ac]),
                        borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: pc.withOpacity(0.4), blurRadius: 10, offset: Offset(0, 4))]),
                    child: ElevatedButton(
                      onPressed: isLoading ? null : _createAccount,
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      child: isLoading
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Text('CREATE ACCOUNT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1)),
                    ),
                  )),
                ]),

                _card(title: 'USER MANAGEMENT', icon: FontAwesomeIcons.users, children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.2), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.12))),
                    child: DropdownButtonHideUnderline(child: DropdownButton<String>(
                      value: selectedRole, dropdownColor: bg, style: const TextStyle(color: Colors.white),
                      items: roleOptions.map((r) => DropdownMenuItem(value: r, child: Text(r.toUpperCase()))).toList(),
                      onChanged: (val) { if (val != null) { selectedRole = val; _filterAndPaginate(); } },
                    )),
                  ),
                  const SizedBox(height: 14),
                  isLoading
                    ? Center(child: CircularProgressIndicator(color: ac))
                    : Column(children: [
                        ..._getCurrentPageData().map((u) => _userTile(u)).toList(),
                        const SizedBox(height: 12),
                        _pagination(),
                      ]),
                ]),

                const SizedBox(height: 20),
              ]),
            ),
          ),
          // TAB 2
          _notifTab(),
        ],
      ),
    );
  }
}
