import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'config_service.dart';

class CvpsPanelPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const CvpsPanelPage({super.key, required this.username, required this.sessionKey});
  @override State<CvpsPanelPage> createState() => _CvpsPanelPageState();
}

class _CvpsPanelPageState extends State<CvpsPanelPage> with TickerProviderStateMixin {

  // ─── Konstanta ───────────────────────────────────────────────────
  static const _bg   = Color(0xFF080808);
  static const _card = Color(0xFF111111);
  static const _acc  = Color(0xFFFF4444);
  static const _neon = Color(0xFF00FF88);
  static const _gold = Color(0xFFFFD700);
  static const _cyan = Color(0xFF00BFFF);
  static const _orb  = 'Orbitron';
  static const _mono = 'ShareTechMono';

  // ─── State ───────────────────────────────────────────────────────
  late TabController _tab;

  bool   _hasSession = false;
  String _sessionIp  = '';

  List<Map<String,dynamic>> _doKeys = [];
  bool _loadingKeys                 = false;
  int  _selectedDoSlot              = 1;

  bool   _showProg  = false;
  double _progVal   = 0.0;
  String _progMsg   = '';
  Color  _progColor = _neon;
  final  List<String> _logs = [];

  // ─── Lifecycle ───────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    _loadSshStatus();
    _loadDoKeys();
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  // ─── API ─────────────────────────────────────────────────────────
  String get _base => baseUrl;
  String get _key  => widget.sessionKey;

  Future<Map<String,dynamic>> _post(String path, Map<String,dynamic> body) async {
    try {
      final r = await http.post(
        Uri.parse('$_base$path'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({...body, 'key': _key}),
      ).timeout(const Duration(seconds: 25));
      return jsonDecode(r.body);
    } catch (e) { return {'valid': false, 'message': '$e'}; }
  }

  Future<Map<String,dynamic>> _get(String path, [Map<String,String>? p]) async {
    try {
      final uri = Uri.parse('$_base$path')
          .replace(queryParameters: {...?p, 'key': _key});
      final r = await http.get(uri).timeout(const Duration(seconds: 20));
      return jsonDecode(r.body);
    } catch (e) { return {'valid': false, 'message': '$e'}; }
  }

  // ─── Loaders ─────────────────────────────────────────────────────
  Future<void> _loadSshStatus() async {
    final d = await _get('/sshStatus');
    if (!mounted) return;
    setState(() {
      _hasSession = d['hasSession'] == true;
      _sessionIp  = d['session']?['ip'] ?? '';
    });
  }

  Future<void> _loadDoKeys() async {
    setState(() => _loadingKeys = true);
    final d = await _get('/doKeyList');
    if (!mounted) return;
    setState(() {
      _loadingKeys = false;
      if (d['valid'] == true)
        _doKeys = List<Map<String,dynamic>>.from(d['keys'] ?? []);
    });
  }

  // ─── Snack / Copy ─────────────────────────────────────────────────
  void _snack(String msg, {bool ok = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: _mono, fontSize: 11)),
      backgroundColor: ok ? const Color(0xFF1A3A1A) : const Color(0xFF3A1A1A),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 3)));
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    _snack('📋 Disalin!');
  }

  // ─── Progress helpers ────────────────────────────────────────────
  void _startProg(String msg, {Color? color}) {
    if (!mounted) return;
    setState(() {
      _showProg  = true;
      _progVal   = 0.0;
      _progMsg   = msg;
      _progColor = color ?? _neon;
      _logs..clear()..add('▶ $msg');
    });
  }

  void _setProg(double val, String msg, {String? log}) {
    if (!mounted) return;
    setState(() {
      _progVal = val.clamp(0.0, 1.0);
      _progMsg = msg;
      if (log != null) _logs.add(log);
    });
  }

  void _addLog(String msg) {
    if (!mounted) return;
    setState(() => _logs.add(msg));
  }

  void _doneProg(String msg, {bool ok = true}) {
    if (!mounted) return;
    setState(() {
      _progVal   = 1.0;
      _progMsg   = msg;
      _progColor = ok ? _neon : _acc;
      _logs.add(ok ? '✅ $msg' : '❌ $msg');
    });
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) setState(() => _showProg = false);
    });
  }

  // ════════════════════════════════════════════════════════════════
  //  BUILD
  // ════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(children: [
        _bgGradient(),
        SafeArea(
          child: Column(children: [
            _buildHeader(),
            const SizedBox(height: 6),
            _buildTabBar(),
            const SizedBox(height: 6),
            Expanded(
              child: TabBarView(
                controller: _tab,
                physics: const NeverScrollableScrollPhysics(),
                children: [_tabApiKey(), _tabProtect(), _tabInstall()],
              ),
            ),
            if (_showProg) _buildProgressBar(),
          ]),
        ),
      ]),
    );
  }

  Widget _bgGradient() => Container(
    decoration: BoxDecoration(
      gradient: RadialGradient(
        center: Alignment.topCenter, radius: 1.4,
        colors: [_acc.withValues(alpha: 0.06), Colors.black])));

  // ─── Header ──────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Row(children: [
        // Tombol kembali
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: _acc.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _acc.withValues(alpha: 0.25))),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white60, size: 14))),
        const SizedBox(width: 14),
        // Judul
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('CVPS PANEL',
            style: TextStyle(fontFamily: _orb, fontSize: 15, fontWeight: FontWeight.bold,
              color: Colors.white, letterSpacing: 2,
              shadows: [Shadow(color: Color(0xFFFF4444), blurRadius: 10)])),
          Text(widget.username,
            style: const TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white30)),
        ]),
        const Spacer(),
        // SSH pill — tap ke tab INSTALL
        GestureDetector(
          onTap: () => _tab.animateTo(2),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _hasSession ? _neon.withValues(alpha: 0.08) : _acc.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _hasSession ? _neon.withValues(alpha: 0.45) : _acc.withValues(alpha: 0.4))),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 6, height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _hasSession ? _neon : _acc,
                  boxShadow: [BoxShadow(color: _hasSession ? _neon : _acc, blurRadius: 5)])),
              const SizedBox(width: 6),
              Text(_hasSession ? 'SSH ON' : 'SSH OFF',
                style: TextStyle(fontFamily: _mono, fontSize: 9,
                  color: _hasSession ? _neon : _acc, fontWeight: FontWeight.bold)),
            ])),
        ),
      ]),
    );
  }

  // ─── Tab Bar ─────────────────────────────────────────────────────
  Widget _buildTabBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.04),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withValues(alpha: 0.07))),
        child: TabBar(
          controller: _tab,
          indicatorSize: TabBarIndicatorSize.tab,
          dividerColor: Colors.transparent,
          indicator: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: LinearGradient(colors: [
              _acc.withValues(alpha: 0.25), _acc.withValues(alpha: 0.08)]),
            border: Border.all(color: _acc.withValues(alpha: 0.4))),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white30,
          labelStyle: const TextStyle(fontFamily: _orb, fontSize: 8, letterSpacing: 0.5),
          tabs: const [
            Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.vpn_key_rounded,   size: 12), SizedBox(width: 4), Text('API KEY')])),
            Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.shield_rounded,    size: 12), SizedBox(width: 4), Text('PROTECT')])),
            Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.build_rounded,     size: 12), SizedBox(width: 4), Text('INSTALL')])),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════
  //  TAB 1 — API KEY
  // ════════════════════════════════════════════════════════════════
  Widget _tabApiKey() {
    final filled = _doKeys.where((k) => k['hasKey'] == true).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: [

        // ── Judul + counter ──
        Row(children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('API KEY',
              style: TextStyle(fontFamily: _orb, fontSize: 13, color: Colors.white, letterSpacing: 1)),
            const Text('DigitalOcean',
              style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white30)),
          ]),
          const Spacer(),
          _pill('${filled.length}', '/50', _gold),
        ]),
        const SizedBox(height: 14),

        // ── Tombol tambah ──
        GestureDetector(
          onTap: _showAddKeyDialog,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                colors: [_gold.withValues(alpha: 0.14), _gold.withValues(alpha: 0.04)]),
              border: Border.all(color: _gold.withValues(alpha: 0.45))),
            child: Row(children: [
              Container(width: 34, height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _gold.withValues(alpha: 0.15),
                  border: Border.all(color: _gold.withValues(alpha: 0.35))),
                child: const Icon(Icons.add_rounded, color: _gold, size: 18)),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('TAMBAH API KEY',
                  style: TextStyle(fontFamily: _orb, fontSize: 11, color: _gold, letterSpacing: 0.5)),
                const Text('Validasi otomatis ke DigitalOcean',
                  style: TextStyle(fontFamily: _mono, fontSize: 9, color: Color.fromRGBO(255,255,255,0.28))),
              ])),
              Icon(Icons.chevron_right_rounded, color: _gold.withValues(alpha: 0.4), size: 18),
            ]),
          ),
        ),
        const SizedBox(height: 20),

        // ── Daftar key ──
        if (_loadingKeys)
          const Padding(padding: EdgeInsets.all(32),
            child: Center(child: CircularProgressIndicator(color: _gold, strokeWidth: 2)))
        else if (filled.isEmpty)
          _emptyState(Icons.vpn_key_off_rounded, 'Belum ada API Key', 'Tambah key untuk mulai kelola VPS')
        else ...[
          _sectionLabel('TERDAFTAR  •  ${filled.length} akun'),
          const SizedBox(height: 8),
          ...filled.map((k) => _keyCard(k)),
        ],
      ],
    );
  }

  Widget _keyCard(Map<String,dynamic> k) {
    final slot     = k['slot']    as int;
    final email    = k['email']   as String? ?? 'Akun DO';
    final preview  = k['preview'] as String? ?? '•••••••••••';
    final status   = k['status']  as String? ?? 'active';
    final limit    = (k['limit']  as num?)?.toInt() ?? 0;
    final used     = (k['used']   as num?)?.toInt() ?? 0;
    final isActive = _selectedDoSlot == slot;
    final pct      = limit > 0 ? (used / limit).clamp(0.0, 1.0) : 0.0;
    final barColor = pct > 0.8 ? _acc : pct > 0.5 ? Colors.orange : _neon;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isActive ? _neon.withValues(alpha: 0.04) : Colors.white.withValues(alpha: 0.03),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isActive ? _neon.withValues(alpha: 0.35) : _gold.withValues(alpha: 0.15),
          width: isActive ? 1.5 : 1.0)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // Baris 1: avatar + info + menu
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 38, height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _gold.withValues(alpha: 0.12),
                border: Border.all(color: _gold.withValues(alpha: 0.35))),
              child: Center(child: Text('$slot',
                style: const TextStyle(fontFamily: _orb, fontSize: 11,
                  color: _gold, fontWeight: FontWeight.bold)))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(email,
                style: const TextStyle(fontFamily: _mono, fontSize: 11,
                  color: Colors.white, fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis),
              const SizedBox(height: 3),
              Text(preview,
                style: TextStyle(fontFamily: _mono, fontSize: 9,
                  color: Color.fromRGBO(255,255,255,0.25), letterSpacing: 1)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              _statusDot(status == 'active'),
              const SizedBox(height: 6),
              SizedBox(height: 24, width: 24,
                child: PopupMenuButton<String>(
                  padding: EdgeInsets.zero,
                  icon: Icon(Icons.more_vert_rounded, color: Color.fromRGBO(255,255,255,0.25), size: 18),
                  color: const Color(0xFF1A1A1A),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: Colors.white.withValues(alpha: 0.07))),
                  itemBuilder: (_) => [
                    _popItem('info',   Icons.info_outline_rounded,   _cyan, 'Info Akun'),
                    _popItem('use',    Icons.check_circle_outline,   _neon, 'Set Aktif'),
                    const PopupMenuDivider(),
                    _popItem('delete', Icons.delete_outline_rounded, _acc,  'Hapus Key'),
                  ],
                  onSelected: (val) {
                    if (val == 'info')   _showKeyInfo(slot);
                    if (val == 'use')    { setState(() => _selectedDoSlot = slot); _snack('✅ Slot $slot aktif'); }
                    if (val == 'delete') _deleteKey(slot);
                  },
                )),
            ]),
          ]),

          const SizedBox(height: 12),
          Divider(color: Colors.white.withValues(alpha: 0.05), height: 1),
          const SizedBox(height: 10),

          // Baris 2: usage bar
          Row(children: [
            const Text('Droplet',
              style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white30)),
            const Spacer(),
            Text('$used / $limit',
              style: TextStyle(fontFamily: _mono, fontSize: 9, color: _gold.withValues(alpha: 0.85))),
          ]),
          const SizedBox(height: 5),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: pct,
              minHeight: 5,
              backgroundColor: Colors.white.withValues(alpha: 0.06),
              valueColor: AlwaysStoppedAnimation<Color>(barColor))),

          // Badge aktif
          if (isActive) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: _neon.withValues(alpha: 0.07),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _neon.withValues(alpha: 0.2))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.check_circle_rounded, color: _neon, size: 12),
                const SizedBox(width: 6),
                const Text('Aktif untuk VPS Manager',
                  style: TextStyle(fontFamily: _mono, fontSize: 9, color: _neon)),
              ])),
          ],
        ]),
      ),
    );
  }

  void _showAddKeyDialog() {
    final keyCtrl = TextEditingController();
    bool obscure  = true;
    final used    = _doKeys.where((k) => k['hasKey'] == true)
        .map((k) => k['slot'] as int).toSet();
    int next = 1;
    for (int i = 1; i <= 50; i++) { if (!used.contains(i)) { next = i; break; } }

    showDialog(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, ss) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: _gold.withValues(alpha: 0.3))),
        titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
        contentPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        title: Row(children: [
          _avatarIcon(Icons.vpn_key_rounded, _gold),
          const SizedBox(width: 12),
          const Text('Tambah API Key',
            style: TextStyle(fontFamily: _orb, fontSize: 13, color: Colors.white)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          // Info slot
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: _gold.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _gold.withValues(alpha: 0.2))),
            child: Row(children: [
              Icon(Icons.bookmark_rounded, color: _gold.withValues(alpha: 0.7), size: 13),
              const SizedBox(width: 8),
              Text('Akan disimpan di Slot $next',
                style: TextStyle(fontFamily: _mono, fontSize: 10, color: _gold.withValues(alpha: 0.9))),
            ])),
          const SizedBox(height: 14),
          _inputField(keyCtrl, 'API Key DigitalOcean',
            hint: 'dop_v1_xxxxxxxxxxxxxxxx',
            icon: Icons.key_rounded,
            obscure: obscure,
            toggle: () => ss(() => obscure = !obscure),
            helper: 'Akan divalidasi ke DO sebelum disimpan'),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.white30))),
          _dialogBtn('SIMPAN', _gold, () async {
            final k = keyCtrl.text.trim();
            if (k.isEmpty) return;
            Navigator.pop(ctx);
            _startProg('Validasi API Key...', color: _gold);
            _setProg(0.3, 'Menghubungi DigitalOcean...', log: '→ Slot $next');
            final d = await _post('/doKeySave', {'slot': next, 'apiKey': k});
            if (d['valid'] == true) {
              _setProg(0.85, 'Menyimpan...', log: '✅ Email: ${d['email'] ?? '-'}');
              _doneProg('Slot $next tersimpan!', ok: true);
              _loadDoKeys();
            } else {
              _addLog('❌ ${d['message'] ?? 'Key tidak valid'}');
              _doneProg('API Key ditolak', ok: false);
            }
          }),
        ],
      ),
    ));
  }

  void _showKeyInfo(int slot) async {
    _startProg('Ambil info akun DO...', color: _gold);
    _setProg(0.5, 'Menghubungi DO API...', log: '→ Slot $slot');
    final d = await _post('/doKeyInfo', {'slot': slot});
    if (!mounted) return;
    if (d['valid'] != true) {
      _addLog('❌ ${d['message'] ?? 'Gagal'}');
      _doneProg('Gagal ambil info', ok: false);
      return;
    }
    _doneProg('Info dimuat', ok: true);
    final limit = (d['limit'] as num?)?.toInt() ?? 0;
    final used  = (d['used']  as num?)?.toInt() ?? 0;
    final pct   = limit > 0 ? (used / limit).clamp(0.0, 1.0) : 0.0;

    showDialog(context: context, builder: (dialogCtx) => AlertDialog(
      backgroundColor: _card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: _gold.withValues(alpha: 0.3))),
      titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      contentPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      title: Row(children: [
        _avatarIcon(Icons.account_circle_rounded, _gold),
        const SizedBox(width: 12),
        Text('Slot $slot',
          style: const TextStyle(fontFamily: _orb, fontSize: 12, color: Colors.white)),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        _infoRow('Email',    d['email']  ?? '-',      _gold),
        _infoRow('Status',   d['status'] ?? '-',      Colors.white54),
        _infoRow('Limit',    '$limit droplet',        Colors.white54),
        _infoRow('Terpakai', '$used droplet',         Colors.white54),
        _infoRow('Tersedia', '${limit - used} droplet', _neon),
        const SizedBox(height: 14),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Penggunaan',
            style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white30)),
          Text('${(pct * 100).toStringAsFixed(0)}%',
            style: TextStyle(fontFamily: _orb, fontSize: 9,
              color: pct > 0.8 ? _acc : _gold)),
        ]),
        const SizedBox(height: 5),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct, minHeight: 6,
            backgroundColor: Colors.white.withValues(alpha: 0.06),
            valueColor: AlwaysStoppedAnimation<Color>(pct > 0.8 ? _acc : _neon))),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogCtx),
          child: const Text('Tutup', style: TextStyle(color: Colors.white30))),
        _dialogBtn('GUNAKAN', _neon, () {
          Navigator.pop(dialogCtx);
          setState(() => _selectedDoSlot = slot);
          _snack('✅ Slot $slot aktif');
        }),
      ],
    ));
  }

  void _deleteKey(int slot) async {
    final ok = await _confirm('Hapus Slot $slot?', 'API Key ini akan dihapus permanen.');
    if (ok != true) return;
    final d = await _post('/doKeyDelete', {'slot': slot});
    _snack(d['message'] ?? 'Gagal', ok: d['valid'] == true);
    if (d['valid'] == true) _loadDoKeys();
  }

  // ════════════════════════════════════════════════════════════════
  //  TAB 2 — PROTECT
  // ════════════════════════════════════════════════════════════════
  Widget _tabProtect() {
    const protects = [
      ['1',  'Anti Otak Atik Server In Settings'],
      ['2',  'Anti Intip User & Cadmin Manual'],
      ['3',  'Anti Intip Location'],
      ['4',  'Anti Intip Nodes'],
      ['5',  'Anti Intip Nest'],
      ['6',  'Anti Intip Settings'],
      ['7',  'Anti Akses File & Download'],
      ['8',  'Anti Intip Server User Lain'],
      ['9',  'Anti Intip & Create Apikey'],
      ['10', 'Anti Create Capikey'],
      ['11', 'Anti Intip Database'],
      ['12', 'Anti Intip Location v2'],
      ['13', 'Anti Intip Nodes v2'],
      ['14', 'Anti Intip Settings v2'],
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: [

        // ── SSH Banner ──
        _sshBanner(),
        const SizedBox(height: 16),

        // ── Judul + counter ──
        Row(children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('PROTECT',
              style: TextStyle(fontFamily: _orb, fontSize: 13, color: Colors.white, letterSpacing: 1)),
            const Text('Pterodactyl Protection',
              style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white30)),
          ]),
          const Spacer(),
          _pill('14', 'protect', _cyan),
        ]),
        const SizedBox(height: 14),

        // ── Install All / Uninstall All ──
        Row(children: [
          Expanded(child: _solidBtn(
            icon: Icons.security_rounded, label: 'INSTALL ALL',
            color: _neon, onTap: () => _execProtect('all', 'install'))),
          const SizedBox(width: 10),
          Expanded(child: _solidBtn(
            icon: Icons.remove_circle_rounded, label: 'UNINSTALL ALL',
            color: _acc, onTap: () => _execProtect('all', 'uninstall'))),
        ]),
        const SizedBox(height: 16),
        _sectionLabel('INDIVIDUAL'),
        const SizedBox(height: 8),

        // ── List protect ──
        ...protects.map((p) => Container(
          margin: const EdgeInsets.only(bottom: 7),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.03),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _cyan.withValues(alpha: 0.13))),
          child: Row(children: [
            Container(width: 28, height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _cyan.withValues(alpha: 0.1),
                border: Border.all(color: _cyan.withValues(alpha: 0.3))),
              child: Center(child: Text(p[0],
                style: const TextStyle(fontFamily: _orb, fontSize: 9,
                  color: _cyan, fontWeight: FontWeight.bold)))),
            const SizedBox(width: 12),
            Expanded(child: Text(p[1],
              style: TextStyle(fontFamily: _mono, fontSize: 10, color: Color.fromRGBO(255,255,255,0.55)))),
            const SizedBox(width: 8),
            _miniBtn('INSTALL', _neon, () => _execProtect(p[0], 'install')),
            const SizedBox(width: 6),
            _miniBtn('UNINSTALL', _acc, () => _execProtect(p[0], 'uninstall')),
          ]),
        )),
      ],
    );
  }

  void _execProtect(String num, String action) async {
    if (!_hasSession) { _snack('⚠️ Login SSH dulu!', ok: false); return; }
    final label    = num == 'all' ? 'Semua (1-14)' : 'Protect $num';
    final isIn     = action == 'install';
    final ok       = await _confirm('${isIn ? 'Install' : 'Uninstall'} $label?',
      'Akan dieksekusi via SSH ke $_sessionIp');
    if (ok != true) return;

    _startProg('${isIn ? 'Install' : 'Uninstall'} $label...', color: isIn ? _cyan : _acc);
    _setProg(0.1, 'Menyiapkan kode PHP...', log: '→ Target: $_sessionIp');
    await Future.delayed(const Duration(milliseconds: 300));
    _setProg(0.35, 'Koneksi SSH...', log: '→ $_sessionIp:22');
    await Future.delayed(const Duration(milliseconds: 200));
    _setProg(0.55, 'Upload file...', log: '→ Kirim protect...');
    final r = await _post('/sshExecProtect', {'protectNum': num, 'action': action});
    if (r['valid'] == true) {
      _setProg(0.85, 'php artisan optimize...', log: '→ Cache di-refresh');
      await Future.delayed(const Duration(milliseconds: 400));
      _doneProg('${isIn ? 'Install' : 'Uninstall'} selesai!', ok: true);
    } else {
      _addLog('❌ ${r['message'] ?? 'Error'}');
      _doneProg('Gagal', ok: false);
    }
  }

  // ════════════════════════════════════════════════════════════════
  //  TAB 3 — INSTALL
  // ════════════════════════════════════════════════════════════════
  Widget _tabInstall() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: [

        // ═══ SSH SESSION ═══
        _tabSection('SSH SESSION', Icons.terminal_rounded, _neon),
        const SizedBox(height: 10),
        _sshCard(),
        const SizedBox(height: 20),

        // ═══ PANEL ═══
        _tabSection('PANEL PTERODACTYL', Icons.dns_rounded, _gold),
        const SizedBox(height: 10),
        _actionCard(Icons.download_rounded, 'Install Panel',
          'Pterodactyl + Wings  •  5–15 menit', _gold, _showInstallPanelDialog),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _actionCard(Icons.hub_rounded, 'Create Node',
            'Setup wings', _cyan, () => _execInstall('create_node'))),
          const SizedBox(width: 8),
          Expanded(child: _actionCard(Icons.delete_rounded, 'Uninstall',
            'Hapus panel', _acc, () => _execInstall('uninstall_panel'))),
        ]),
        const SizedBox(height: 20),

        // ═══ TEMA ═══
        _tabSection('TEMA', Icons.palette_rounded, Colors.purple),
        const SizedBox(height: 10),
        _temaGrid(),
        const SizedBox(height: 8),
        _actionCard(Icons.delete_sweep_rounded, 'Uninstall Tema',
          'Hapus tema aktif', _acc, () => _execTema('uninstall')),
      ],
    );
  }

  Widget _sshCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _hasSession ? _neon.withValues(alpha: 0.04) : Colors.white.withValues(alpha: 0.03),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: _hasSession ? _neon.withValues(alpha: 0.3) : Colors.white.withValues(alpha: 0.08),
          width: _hasSession ? 1.5 : 1.0)),
      child: _hasSession
        ? Row(children: [
            Container(width: 10, height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: _neon,
                boxShadow: [BoxShadow(color: _neon, blurRadius: 6)])),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Terhubung',
                style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white30)),
              Text(_sessionIp,
                style: const TextStyle(fontFamily: _mono, fontSize: 14,
                  color: Colors.white, fontWeight: FontWeight.w600)),
            ])),
            _miniBtn('LOGOUT', _acc, _sshLogout),
          ])
        : Row(children: [
            Container(width: 10, height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.12),
                border: Border.all(color: Colors.white.withOpacity(0.12)))),
            const SizedBox(width: 12),
            const Expanded(child: Text('Belum ada sesi aktif',
              style: TextStyle(fontFamily: _mono, fontSize: 11, color: Colors.white30))),
            _miniBtn('LOGIN', _neon, _showSshLoginDialog),
          ]),
    );
  }

  Widget _temaGrid() {
    const items = [
      ['stellar',   'Stellar',   '🌟'],
      ['billing',   'Billing',   '💳'],
      ['enigma',    'Enigma',    '🔮'],
      ['nightcore', 'NightCore', '🌙'],
      ['elysium',   'Elysium',   '✨'],
      ['nook',      'Nook',      '📚'],
      ['wallpaper', 'Wallpaper', '🖼️'],
    ];
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      childAspectRatio: 2.8,
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      children: items.map((t) => GestureDetector(
        onTap: () => _execTema(t[0]),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.03),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.purple.withValues(alpha: 0.22))),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(t[2], style: const TextStyle(fontSize: 14)),
            const SizedBox(width: 8),
            Text(t[1], style: const TextStyle(
              fontFamily: _mono, fontSize: 10, color: Color.fromRGBO(255,255,255,0.65))),
          ])),
      )).toList(),
    );
  }

  void _showSshLoginDialog() async {
    final ipCtrl   = TextEditingController();
    final passCtrl = TextEditingController();
    bool obscure   = true;

    final ok = await showDialog<bool>(context: context, builder: (ctx) =>
      StatefulBuilder(builder: (ctx, ss) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: _neon.withValues(alpha: 0.3))),
        titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
        contentPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        title: Row(children: [
          _avatarIcon(Icons.terminal_rounded, _neon),
          const SizedBox(width: 12),
          const Text('Login SSH',
            style: TextStyle(fontFamily: _orb, fontSize: 13, color: Colors.white)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          _inputField(ipCtrl, 'IP / Hostname', hint: '123.45.67.89', icon: Icons.cloud_rounded),
          const SizedBox(height: 12),
          _inputField(passCtrl, 'Password Root',
            icon: Icons.lock_rounded, obscure: obscure,
            toggle: () => ss(() => obscure = !obscure)),
          const SizedBox(height: 8),
          Row(children: [
            Icon(Icons.info_outline_rounded, size: 11, color: Color.fromRGBO(255,255,255,0.20)),
            const SizedBox(width: 6),
            const Text('Port default: 22',
              style: TextStyle(fontFamily: _mono, fontSize: 9, color: Color.fromRGBO(255,255,255,0.20))),
          ]),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white30))),
          _dialogBtn('CONNECT', _neon, () => Navigator.pop(ctx, true)),
        ],
      )));
    if (ok != true) return;
    final ip = ipCtrl.text.trim();
    _startProg('Menghubungkan ke $ip...', color: _neon);
    _setProg(0.2, 'TCP handshake...', log: '→ $ip:22');
    await Future.delayed(const Duration(milliseconds: 400));
    _setProg(0.5, 'Autentikasi SSH...', log: '→ Mengirim kredensial');
    final r = await _post('/sshLogin', {'ip': ip, 'password': passCtrl.text.trim(), 'port': '22'});
    if (r['valid'] == true) {
      _setProg(0.85, 'Sesi dibuat...', log: '✅ Berhasil ke $ip');
      await Future.delayed(const Duration(milliseconds: 300));
      _doneProg('SSH aktif: $ip', ok: true);
      _loadSshStatus();
    } else {
      _addLog('❌ ${r['message'] ?? 'Gagal konek'}');
      _doneProg('Koneksi gagal', ok: false);
    }
  }

  void _sshLogout() async {
    final ok = await _confirm('Logout SSH?', 'Sesi ke $_sessionIp akan dihapus.');
    if (ok != true) return;
    final r = await _post('/sshLogout', {});
    _snack(r['message'] ?? 'Gagal', ok: r['valid'] == true);
    if (r['valid'] == true) _loadSshStatus();
  }

  void _showInstallPanelDialog() async {
    final domCtrl  = TextEditingController();
    final nodeCtrl = TextEditingController();
    final ramCtrl  = TextEditingController(text: '8000');
    final ipCtrl   = TextEditingController(text: _sessionIp);
    final passCtrl = TextEditingController();
    bool  passObscure = true;

    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, ss) => AlertDialog(
      backgroundColor: _card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: _gold.withValues(alpha: 0.3))),
      titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      contentPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      title: const Text('Install Pterodactyl',
        style: TextStyle(fontFamily: _orb, fontSize: 13, color: Colors.white)),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        _infoBox('Proses 5–15 menit. Jangan restart server selama install.', Colors.orange),
        const SizedBox(height: 12),
        if (!_hasSession) ...[
          _inputField(ipCtrl, 'IP VPS', icon: Icons.cloud_rounded),
          const SizedBox(height: 10),
          _inputField(passCtrl, 'Password Root',
            icon: Icons.lock_rounded, obscure: passObscure,
            toggle: () => ss(() => passObscure = !passObscure)),
          const SizedBox(height: 10),
        ],
        _inputField(domCtrl, 'Domain Panel', hint: 'panel.domain.com', icon: Icons.language_rounded),
        const SizedBox(height: 10),
        _inputField(nodeCtrl, 'Domain Node', hint: 'node.domain.com', icon: Icons.hub_rounded),
        const SizedBox(height: 10),
        _inputField(ramCtrl, 'RAM (MB)', hint: '8000', icon: Icons.memory_rounded),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Batal', style: TextStyle(color: Colors.white30))),
        _dialogBtn('INSTALL', _gold, () => Navigator.pop(ctx, true)),
      ],
    )));
    if (ok != true) return;
    _startProg('Install Panel Pterodactyl...', color: _gold);
    _setProg(0.05, 'Menyiapkan installer...', log: '→ ${domCtrl.text.trim()}');
    await Future.delayed(const Duration(milliseconds: 300));
    _setProg(0.15, 'Kirim ke server...', log: '→ ${ipCtrl.text.isNotEmpty ? ipCtrl.text.trim() : _sessionIp}');
    final r = await _post('/installPanel', {
      'ip': ipCtrl.text.trim(), 'password': passCtrl.text.trim(),
      'domain': domCtrl.text.trim(), 'domainNode': nodeCtrl.text.trim(),
      'ram': ramCtrl.text.trim(),
    });
    if (r['valid'] == true) {
      _setProg(0.4, 'Installer berjalan...', log: '→ Background process di VPS');
      _addLog('💡 Pantau: tail -f /tmp/install.log');
      _doneProg('Install dimulai!  5–15 menit', ok: true);
    } else {
      _addLog('❌ ${r['message'] ?? 'Gagal'}');
      _doneProg('Gagal memulai install', ok: false);
    }
  }

  void _execInstall(String type) async {
    if (!_hasSession) { _snack('⚠️ Login SSH dulu!', ok: false); return; }
    final labels = {'uninstall_panel': 'Uninstall Panel', 'create_node': 'Create Node'};
    final label  = labels[type]!;
    final col    = type == 'create_node' ? _cyan : _acc;
    final ok     = await _confirm('$label?', 'Akan dieksekusi di $_sessionIp');
    if (ok != true) return;
    _startProg('$label...', color: col);
    _setProg(0.1, 'Menyiapkan...', log: '→ $_sessionIp');
    await Future.delayed(const Duration(milliseconds: 300));
    _setProg(0.35, 'Eksekusi via SSH...', log: '→ Running script');
    final r = await _post(type == 'create_node' ? '/createNode' : '/uninstallPanel', {});
    if (r['valid'] == true) {
      _doneProg('$label berhasil!', ok: true);
    } else {
      _addLog('❌ ${r['message'] ?? 'Error'}');
      _doneProg('$label gagal', ok: false);
    }
  }

  void _execTema(String tema) async {
    if (!_hasSession) { _snack('⚠️ Login SSH dulu!', ok: false); return; }
    final isUn = tema == 'uninstall';
    final label = isUn ? 'Uninstall Tema' : 'Install "$tema"';
    final ok = await _confirm('$label?', 'Dieksekusi di $_sessionIp  •  2–5 menit');
    if (ok != true) return;
    _startProg('$label...', color: isUn ? _acc : Colors.purple);
    _setProg(0.15, 'Menyiapkan skrip...', log: '→ $tema');
    await Future.delayed(const Duration(milliseconds: 250));
    _setProg(0.35, 'Koneksi SSH...', log: '→ $_sessionIp');
    await Future.delayed(const Duration(milliseconds: 200));
    _setProg(0.5, 'Menjalankan installer...', log: '→ Download & apply');
    final r = await _post('/sshExecTema', {'tema': tema});
    if (r['valid'] == true) {
      _doneProg('$label berhasil dimulai!', ok: true);
    } else {
      _addLog('❌ ${r['message'] ?? 'Error'}');
      _doneProg('$label gagal', ok: false);
    }
  }

  // ════════════════════════════════════════════════════════════════
  //  PROGRESS BAR
  // ════════════════════════════════════════════════════════════════
  Widget _buildProgressBar() {
    final pct = (_progVal * 100).toStringAsFixed(0);
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0C0C0C),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _progColor.withValues(alpha: 0.35)),
        boxShadow: [BoxShadow(color: _progColor.withValues(alpha: 0.07), blurRadius: 16)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          SizedBox(width: 14, height: 14,
            child: CircularProgressIndicator(
              value: _progVal < 1.0 ? null : 1.0,
              strokeWidth: 1.5, color: _progColor)),
          const SizedBox(width: 10),
          Expanded(child: Text(_progMsg,
            style: TextStyle(fontFamily: _mono, fontSize: 10, color: _progColor),
            overflow: TextOverflow.ellipsis)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: _progColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(6)),
            child: Text('$pct%',
              style: TextStyle(fontFamily: _orb, fontSize: 9, color: _progColor))),
        ]),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: LinearProgressIndicator(
            value: _progVal, minHeight: 5,
            backgroundColor: Colors.white.withValues(alpha: 0.06),
            valueColor: AlwaysStoppedAnimation<Color>(_progColor))),
        if (_logs.isNotEmpty) ...[
          const SizedBox(height: 8),
          Container(
            height: 54,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.black45,
              borderRadius: BorderRadius.circular(8)),
            child: ListView.builder(
              reverse: true,
              itemCount: _logs.length,
              itemBuilder: (_, i) {
                final log = _logs[_logs.length - 1 - i];
                final c = log.contains('❌') ? _acc : log.contains('✅') ? _neon : Colors.white30;
                return Text(log,
                  style: TextStyle(fontFamily: _mono, fontSize: 8, color: c));
              }),
          ),
        ],
      ]),
    );
  }

  // ════════════════════════════════════════════════════════════════
  //  WIDGET HELPERS
  // ════════════════════════════════════════════════════════════════

  // Tombol padat 2-kolom
  Widget _solidBtn({required IconData icon, required String label,
      required Color color, required VoidCallback onTap}) =>
    GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.4))),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(fontFamily: _orb, fontSize: 9, color: color, letterSpacing: 0.5)),
        ])));

  // Card aksi dengan ikon kiri
  Widget _actionCard(IconData icon, String title, String sub,
      Color color, VoidCallback onTap) =>
    GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.03),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.2))),
        child: Row(children: [
          Container(width: 32, height: 32,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(9)),
            child: Icon(icon, color: color, size: 15)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontFamily: _mono, fontSize: 11, color: color)),
            Text(sub, style: TextStyle(fontFamily: _mono, fontSize: 9, color: Color.fromRGBO(255,255,255,0.25))),
          ])),
        ])));

  // Mini button inline
  Widget _miniBtn(String label, Color color, VoidCallback onTap) =>
    GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(7),
          border: Border.all(color: color.withValues(alpha: 0.35))),
        child: Text(label,
          style: TextStyle(fontFamily: _orb, fontSize: 8, color: color, letterSpacing: 0.3))));

  // Section header dengan icon
  Widget _tabSection(String title, IconData icon, Color color) =>
    Row(children: [
      Container(width: 28, height: 28,
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8)),
        child: Icon(icon, color: color, size: 14)),
      const SizedBox(width: 10),
      Text(title, style: TextStyle(fontFamily: _orb, fontSize: 10, color: color, letterSpacing: 1)),
    ]);

  // Label kecil abu
  Widget _sectionLabel(String t) =>
    Text(t, style: TextStyle(fontFamily: _mono, fontSize: 9, color: Color.fromRGBO(255,255,255,0.20), letterSpacing: 1));

  // Pill badge
  Widget _pill(String val, String unit, Color color) =>
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.25))),
      child: RichText(text: TextSpan(children: [
        TextSpan(text: val,
          style: TextStyle(fontFamily: _orb, fontSize: 12, color: color, fontWeight: FontWeight.bold)),
        TextSpan(text: '  $unit',
          style: TextStyle(fontFamily: _mono, fontSize: 9, color: Color.fromRGBO(255,255,255,0.25))),
      ])));

  // Status dot kecil
  Widget _statusDot(bool active) =>
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: active ? _neon.withValues(alpha: 0.1) : _acc.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: active ? _neon.withValues(alpha: 0.3) : _acc.withValues(alpha: 0.3))),
      child: Text(active ? 'ACTIVE' : 'INACTIVE',
        style: TextStyle(fontFamily: _mono, fontSize: 7,
          color: active ? _neon : _acc, letterSpacing: 0.5)));

  // Avatar icon bulat
  Widget _avatarIcon(IconData icon, Color color) =>
    Container(width: 32, height: 32,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withValues(alpha: 0.12),
        border: Border.all(color: color.withValues(alpha: 0.35))),
      child: Icon(icon, color: color, size: 16));

  // SSH banner
  Widget _sshBanner() =>
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _hasSession ? _neon.withValues(alpha: 0.07) : Colors.orange.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: _hasSession ? _neon.withValues(alpha: 0.3) : Colors.orange.withValues(alpha: 0.3))),
      child: Row(children: [
        Icon(_hasSession ? Icons.check_circle_rounded : Icons.warning_rounded,
          color: _hasSession ? _neon : Colors.orange, size: 13),
        const SizedBox(width: 8),
        Text(_hasSession ? 'SSH aktif: $_sessionIp' : '⚠️ Login SSH dulu di tab INSTALL',
          style: TextStyle(fontFamily: _mono, fontSize: 9,
            color: _hasSession ? _neon : Colors.orange)),
      ]));

  // Empty state
  Widget _emptyState(IconData icon, String title, String sub) =>
    Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(children: [
        Icon(icon, color: Colors.white10, size: 52),
        const SizedBox(height: 12),
        Text(title, style: TextStyle(fontFamily: _mono, fontSize: 13, color: Color.fromRGBO(255,255,255,0.20))),
        const SizedBox(height: 4),
        Text(sub, style: TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white.withOpacity(0.12))),
      ]));

  // Info row tap-to-copy
  Widget _infoRow(String label, String value, Color valColor) =>
    GestureDetector(
      onTap: () => _copy(value),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(children: [
          SizedBox(width: 72,
            child: Text(label, style: TextStyle(fontFamily: _mono, fontSize: 9, color: Color.fromRGBO(255,255,255,0.28)))),
          Text('  ·  ', style: TextStyle(color: Colors.white.withOpacity(0.12))),
          Expanded(child: Text(value, style: TextStyle(fontFamily: _mono, fontSize: 9, color: valColor))),
          Icon(Icons.copy_rounded, size: 10, color: Colors.white.withOpacity(0.12)),
        ])));

  // Info box
  Widget _infoBox(String msg, Color color) =>
    Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.25))),
      child: Text(msg, style: TextStyle(fontFamily: _mono, fontSize: 9, color: color.withValues(alpha: 0.9))));

  // Input field
  Widget _inputField(TextEditingController ctrl, String label,
    {String? hint, IconData? icon, bool obscure = false,
     VoidCallback? toggle, String? helper}) =>
    TextField(
      controller: ctrl, obscureText: obscure,
      style: const TextStyle(color: Colors.white, fontFamily: _mono, fontSize: 12),
      decoration: InputDecoration(
        labelText: label, hintText: hint,
        labelStyle: const TextStyle(color: Colors.white38, fontSize: 10),
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.12), fontSize: 10),
        helperText: helper,
        helperStyle: const TextStyle(color: Colors.white24, fontSize: 9),
        prefixIcon: icon != null ? Icon(icon, color: Colors.white24, size: 16) : null,
        suffixIcon: toggle != null
          ? GestureDetector(onTap: toggle,
              child: Icon(obscure ? Icons.visibility_off : Icons.visibility,
                color: Colors.white38, size: 16))
          : null,
        filled: true,
        fillColor: Colors.white.withValues(alpha: 0.03),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.1))),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: _acc.withValues(alpha: 0.5)))));

  // Popup menu item
  PopupMenuItem<String> _popItem(String val, IconData icon, Color color, String label) =>
    PopupMenuItem<String>(
      value: val,
      child: Row(children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 10),
        Text(label, style: TextStyle(fontFamily: _mono, fontSize: 11, color: color)),
      ]));

  // Dialog button
  Widget _dialogBtn(String label, Color color, VoidCallback onTap) =>
    ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: color.withValues(alpha: 0.15),
        side: BorderSide(color: color.withValues(alpha: 0.5)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
      child: Text(label,
        style: TextStyle(fontFamily: _orb, fontSize: 9, color: color, letterSpacing: 1)));

  // Confirm dialog
  Future<bool?> _confirm(String title, String content) =>
    showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: _acc.withValues(alpha: 0.2))),
      titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
      contentPadding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      title: Text(title, style: const TextStyle(fontFamily: _orb, fontSize: 13, color: Colors.white)),
      content: Text(content, style: const TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white38)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false),
          child: const Text('Batal', style: TextStyle(color: Colors.white30))),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          style: ElevatedButton.styleFrom(
            backgroundColor: _acc.withValues(alpha: 0.2),
            side: BorderSide(color: _acc.withValues(alpha: 0.45)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          child: const Text('YA', style: TextStyle(fontFamily: _orb, fontSize: 10, color: _acc))),
      ]));
}
