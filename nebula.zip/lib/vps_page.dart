import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'config_service.dart';

// ══════════════════════════════════════════════════════════════════
//  VPS MANAGER — proxy via API server kita
//  Endpoints: /vpsSetKey /vpsGetKeys /vpsList /vpsCreate /vpsDelete
// ══════════════════════════════════════════════════════════════════

enum VpsProvider { digitalocean, vultr, linode }

extension VpsExt on VpsProvider {
  String get id    => toString().split('.').last;
  String get label {
    switch (this) {
      case VpsProvider.digitalocean: return 'DigitalOcean';
      case VpsProvider.vultr:        return 'Vultr';
      case VpsProvider.linode:       return 'Linode';
    }
  }
  Color get color {
    switch (this) {
      case VpsProvider.digitalocean: return const Color(0xFF0080FF);
      case VpsProvider.vultr:        return const Color(0xFF00BFFF);
      case VpsProvider.linode:       return const Color(0xFF00C853);
    }
  }
  IconData get icon {
    switch (this) {
      case VpsProvider.digitalocean: return Icons.water_drop_rounded;
      case VpsProvider.vultr:        return Icons.bolt_rounded;
      case VpsProvider.linode:       return Icons.cloud_rounded;
    }
  }
  String get keyHint {
    switch (this) {
      case VpsProvider.digitalocean: return 'dop_v1_xxxxxxxxxxxxxxxxxxxx';
      case VpsProvider.vultr:        return 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX';
      case VpsProvider.linode:       return 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
    }
  }
  String get guide {
    switch (this) {
      case VpsProvider.digitalocean:
        return '1. Buka cloud.digitalocean.com\n2. Klik API → Tokens\n3. Generate New Token\n4. Centang Read + Write\n5. Copy token → paste di sini';
      case VpsProvider.vultr:
        return '1. Buka my.vultr.com\n2. Account → API\n3. Enable API Access\n4. Copy API Key → paste di sini';
      case VpsProvider.linode:
        return '1. Buka cloud.linode.com\n2. Profile → API Tokens\n3. Create Personal Token\n4. Linodes: Read/Write\n5. Copy token → paste di sini';
    }
  }
  String get defRegion {
    switch (this) {
      case VpsProvider.digitalocean: return 'sgp1';
      case VpsProvider.vultr:        return 'sgp';
      case VpsProvider.linode:       return 'ap-southeast';
    }
  }
  String get defSize {
    switch (this) {
      case VpsProvider.digitalocean: return 's-1vcpu-1gb';
      case VpsProvider.vultr:        return 'vc2-1c-1gb';
      case VpsProvider.linode:       return 'g6-nanode-1';
    }
  }
  String get regionHint {
    switch (this) {
      case VpsProvider.digitalocean: return 'sgp1 · nyc1 · lon1 · ams3 · fra1';
      case VpsProvider.vultr:        return 'sgp · ewr · lhr · ams · fra';
      case VpsProvider.linode:       return 'ap-southeast · us-east · eu-west';
    }
  }
  String get sizeHint {
    switch (this) {
      case VpsProvider.digitalocean: return 's-1vcpu-1gb · s-1vcpu-2gb · s-2vcpu-2gb';
      case VpsProvider.vultr:        return 'vc2-1c-1gb · vc2-1c-2gb · vc2-2c-4gb';
      case VpsProvider.linode:       return 'g6-nanode-1 · g6-standard-1 · g6-standard-2';
    }
  }

  List<Map<String,String>> get specPlans {
    switch (this) {
      case VpsProvider.digitalocean: return [
        {'label':'Starter',   'cpu':'1 vCPU', 'ram':'1 GB', 'disk':'25 GB', 'price':'\$6/bln',  'slug':'s-1vcpu-1gb'},
        {'label':'Basic',     'cpu':'1 vCPU', 'ram':'2 GB', 'disk':'50 GB', 'price':'\$12/bln', 'slug':'s-1vcpu-2gb'},
        {'label':'Standard',  'cpu':'2 vCPU', 'ram':'2 GB', 'disk':'60 GB', 'price':'\$18/bln', 'slug':'s-2vcpu-2gb'},
        {'label':'Pro',       'cpu':'2 vCPU', 'ram':'4 GB', 'disk':'80 GB', 'price':'\$24/bln', 'slug':'s-2vcpu-4gb'},
        {'label':'Power',     'cpu':'4 vCPU', 'ram':'8 GB', 'disk':'160GB', 'price':'\$48/bln', 'slug':'s-4vcpu-8gb'},
      ];
      case VpsProvider.vultr: return [
        {'label':'Starter',   'cpu':'1 vCPU', 'ram':'1 GB', 'disk':'25 GB', 'price':'\$6/bln',  'slug':'vc2-1c-1gb'},
        {'label':'Basic',     'cpu':'1 vCPU', 'ram':'2 GB', 'disk':'55 GB', 'price':'\$12/bln', 'slug':'vc2-1c-2gb'},
        {'label':'Standard',  'cpu':'2 vCPU', 'ram':'4 GB', 'disk':'80 GB', 'price':'\$24/bln', 'slug':'vc2-2c-4gb'},
        {'label':'Pro',       'cpu':'4 vCPU', 'ram':'8 GB', 'disk':'160GB', 'price':'\$48/bln', 'slug':'vc2-4c-8gb'},
        {'label':'Power',     'cpu':'6 vCPU', 'ram':'16GB', 'disk':'320GB', 'price':'\$96/bln', 'slug':'vc2-6c-16gb'},
      ];
      case VpsProvider.linode: return [
        {'label':'Nanode',    'cpu':'1 vCPU', 'ram':'1 GB', 'disk':'25 GB', 'price':'\$5/bln',  'slug':'g6-nanode-1'},
        {'label':'Linode 2G', 'cpu':'1 vCPU', 'ram':'2 GB', 'disk':'50 GB', 'price':'\$10/bln', 'slug':'g6-standard-1'},
        {'label':'Linode 4G', 'cpu':'2 vCPU', 'ram':'4 GB', 'disk':'80 GB', 'price':'\$20/bln', 'slug':'g6-standard-2'},
        {'label':'Linode 8G', 'cpu':'4 vCPU', 'ram':'8 GB', 'disk':'160GB', 'price':'\$40/bln', 'slug':'g6-standard-4'},
        {'label':'Linode 16G','cpu':'6 vCPU', 'ram':'16GB', 'disk':'320GB', 'price':'\$80/bln', 'slug':'g6-standard-6'},
      ];
    }
  }
}

// ══════════════════════════════════════════════════════════════════
class VpsPage extends StatefulWidget {
  final String sessionKey;
  const VpsPage({super.key, required this.sessionKey});

  @override State<VpsPage> createState() => _VpsPageState();
}

class _VpsPageState extends State<VpsPage> with SingleTickerProviderStateMixin {
  static const _bg   = Colors.black;
  static const _red  = Color(0xFFB22222);
  static const _acc  = Color(0xFFFF4444);
  static const _neon = Color(0xFF00FF88);
  static const _gold = Color(0xFFFFD700);
  static const _mono = 'ShareTechMono';
  static const _orb  = 'Orbitron';

  late TabController _tabs;
  VpsProvider _prov = VpsProvider.digitalocean;
  final Map<VpsProvider, bool> _hasSavedKey = {};
  final Map<VpsProvider, TextEditingController> _keyCtrl = {
    for (var p in VpsProvider.values) p: TextEditingController()
  };
  final Map<VpsProvider, bool> _keyObscure = {
    for (var p in VpsProvider.values) p: true
  };

  List<Map<String, dynamic>> _servers = [];
  bool _loadingList  = false;
  bool _savingKey    = false;
  bool _creating     = false;

  final _nameCtrl   = TextEditingController();
  final _regionCtrl = TextEditingController();
  final _sizeCtrl   = TextEditingController();
  final _sshPassCtrl = TextEditingController();
  bool _sshObscure   = true;
  String _osSlug    = 'ubuntu-22-04-x64';
  Map<String,String>? _selectedPlan;

  String? _err;
  String? _ok;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _regionCtrl.text = _prov.defRegion;
    _loadSavedKeys();
  }

  @override
  void dispose() {
    _tabs.dispose();
    _nameCtrl.dispose(); _regionCtrl.dispose(); _sizeCtrl.dispose(); _sshPassCtrl.dispose();
    for (final c in _keyCtrl.values) c.dispose();
    super.dispose();
  }

  // ── API HELPER ───────────────────────────────────────────────────
  Future<Map<String, dynamic>> _api(String path, {Map<String, dynamic>? body}) async {
    try {
      final uri = Uri.parse('$baseUrl$path');
      late http.Response res;
      if (body != null) {
        res = await http.post(uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(body)
        ).timeout(const Duration(seconds: 15));
      } else {
        res = await http.get(uri).timeout(const Duration(seconds: 15));
      }
      return jsonDecode(res.body) as Map<String, dynamic>;
    } catch (e) {
      return {'valid': false, 'message': 'Koneksi gagal: $e'};
    }
  }

  // ── LOAD SAVED KEYS STATUS ───────────────────────────────────────
  Future<void> _loadSavedKeys() async {
    final r = await _api('/vpsGetKeys?key=${widget.sessionKey}');
    if (r['valid'] == true && r['providers'] != null) {
      final p = r['providers'] as Map<String, dynamic>;
      setState(() {
        _hasSavedKey[VpsProvider.digitalocean] = p['digitalocean'] == true;
        _hasSavedKey[VpsProvider.vultr]        = p['vultr']        == true;
        _hasSavedKey[VpsProvider.linode]       = p['linode']       == true;
      });
    }
  }

  // ── SAVE API KEY ─────────────────────────────────────────────────
  Future<void> _saveKey(VpsProvider prov) async {
    final apiKey = _keyCtrl[prov]!.text.trim();
    if (apiKey.isEmpty) { setState(() => _err = 'API Key tidak boleh kosong'); return; }
    setState(() { _savingKey = true; _err = null; _ok = null; });
    final r = await _api('/vpsSetKey', body: {
      'key': widget.sessionKey,
      'provider': prov.id,
      'apiKey': apiKey,
    });
    setState(() {
      _savingKey = false;
      if (r['valid'] == true) {
        _ok = '✅ API Key ${prov.label} berhasil disimpan di server';
        _hasSavedKey[prov] = true;
        _keyCtrl[prov]!.clear();
      } else {
        _err = r['message'] ?? 'Gagal simpan';
      }
    });
  }

  // ── LIST VPS ─────────────────────────────────────────────────────
  Future<void> _fetchServers() async {
    if (_hasSavedKey[_prov] != true) {
      setState(() => _err = 'API Key ${_prov.label} belum disimpan. Isi di tab 🔑 API Key');
      return;
    }
    setState(() { _loadingList = true; _err = null; _ok = null; _servers = []; });
    final r = await _api('/vpsList?key=${widget.sessionKey}&provider=${_prov.id}');
    setState(() {
      _loadingList = false;
      if (r['valid'] == true) {
        _servers = List<Map<String, dynamic>>.from(r['servers'] ?? []);
      } else {
        _err = r['message'] ?? 'Gagal ambil list VPS';
      }
    });
  }

  // ── CREATE VPS ───────────────────────────────────────────────────
  Future<void> _createVps() async {
    if (_hasSavedKey[_prov] != true) { setState(() => _err = 'API Key ${_prov.label} belum disimpan'); return; }
    if (_nameCtrl.text.trim().isEmpty)   { setState(() => _err = 'Nama VPS wajib diisi'); return; }
    if (_regionCtrl.text.trim().isEmpty) { setState(() => _err = 'Region wajib diisi'); return; }
    if (_selectedPlan == null)            { setState(() => _err = 'Pilih spek VPS terlebih dahulu'); return; }

    setState(() { _creating = true; _err = null; _ok = null; });
    final r = await _api('/vpsCreate', body: {
      'key':      widget.sessionKey,
      'provider': _prov.id,
      'name':     _nameCtrl.text.trim(),
      'region':   _regionCtrl.text.trim(),
      'size':     _selectedPlan!['slug']!,
      'os':       _osSlug,
      'sshPass':  _sshPassCtrl.text.trim(),
    });
    setState(() {
      _creating = false;
      if (r['valid'] == true) {
        _ok = r['message'] ?? '✅ VPS berhasil dibuat!';
        _nameCtrl.clear();
        _sshPassCtrl.clear();
        _tabs.animateTo(1);
        Future.delayed(const Duration(milliseconds: 700), _fetchServers);
      } else {
        _err = r['message'] ?? 'Gagal buat VPS';
      }
    });
  }

  // ── DELETE VPS ───────────────────────────────────────────────────
  Future<void> _deleteVps(String id, String name) async {
    final ok = await showDialog<bool>(context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: _acc.withOpacity(0.3))),
        title: const Text('Hapus VPS?', style: TextStyle(fontFamily: _orb, color: Colors.white, fontSize: 14)),
        content: Text('VPS "$name" akan dihapus permanen!',
          style: const TextStyle(fontFamily: _mono, color: Colors.white70, fontSize: 11)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white38))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _acc,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('HAPUS', style: TextStyle(color: Colors.white, fontFamily: _mono))),
        ],
      ));
    if (ok != true) return;

    setState(() { _loadingList = true; _err = null; _ok = null; });
    final r = await _api('/vpsDelete', body: {
      'key': widget.sessionKey, 'provider': _prov.id, 'id': id, 'name': name,
    });
    setState(() {
      if (r['valid'] == true) {
        _ok = r['message'] ?? '✅ VPS dihapus';
        _servers.removeWhere((s) => s['id'] == id);
      } else {
        _err = r['message'] ?? 'Gagal hapus';
      }
      _loadingList = false;
    });
  }

  // ── UTILS ────────────────────────────────────────────────────────
  Color _statusColor(String s) {
    switch (s.toLowerCase()) {
      case 'active': case 'running': return _neon;
      case 'off': case 'stopped':   return _acc;
      default:                       return _gold;
    }
  }

  // ══════════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════════
  // ── DIALOG INFO VPS LENGKAP ──────────────────────────────────────
  void _showVpsCreatedDialog(Map<String, dynamic> info) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _neon.withOpacity(0.3))),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Header
            Row(children: [
              Container(width: 8, height: 8,
                decoration: BoxDecoration(shape: BoxShape.circle, color: _neon,
                  boxShadow: [BoxShadow(color: _neon, blurRadius: 6)])),
              const SizedBox(width: 8),
              const Text('VPS BERHASIL DIBUAT', style: TextStyle(fontFamily: _orb, fontSize: 12,
                color: Colors.white, letterSpacing: 1)),
            ]),
            const SizedBox(height: 4),
            Text('Simpan info ini sekarang!',
              style: TextStyle(fontFamily: _mono, fontSize: 9, color: _acc)),
            Divider(color: Colors.white.withOpacity(0.12), height: 20),

            // Info rows
            ...[
              ['📛 Nama',      info['name']     ?? '-'],
              ['🌐 Provider',  info['provider'] ?? '-'],
              ['📍 Region',    info['region']   ?? '-'],
              ['💻 Size',      info['size']     ?? '-'],
              ['🐧 OS',        info['os']       ?? '-'],
              ['🌍 IP',        info['ip']       ?? '-'],
              ['👤 SSH User',  info['sshUser']  ?? 'root'],
              ['🔐 Password',  info['sshPass']  ?? '-'],
              ['🔌 Port SSH',  '${info['sshPort'] ?? 22}'],
              ['📅 Dibuat',    info['createdAt'] ?? '-'],
            ].map((row) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SizedBox(width: 90, child: Text(row[0],
                  style: const TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white38))),
                const Text(': ', style: TextStyle(color: Colors.white24)),
                Expanded(child: GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: row[1]));
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text('${row[0]} disalin!',
                        style: const TextStyle(fontFamily: _mono, fontSize: 10)),
                      backgroundColor: const Color(0xFF1A1A1A),
                      duration: const Duration(seconds: 1)));
                  },
                  child: Text(row[1],
                    style: TextStyle(fontFamily: _mono, fontSize: 10,
                      color: row[0].contains('Password') ? _acc :
                             row[0].contains('IP') ? _neon : Colors.white70)),
                )),
                Icon(Icons.copy, size: 10, color: Colors.white.withOpacity(0.12)),
              ]),
            )),

            const SizedBox(height: 4),
            Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _gold.withOpacity(0.07),
                borderRadius: BorderRadius.circular(7),
                border: Border.all(color: _gold.withOpacity(0.25))),
              child: Text('💡 ${info['note'] ?? ''}',
                style: const TextStyle(fontFamily: _mono, fontSize: 9, color: _gold))),

            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.07),
                    borderRadius: BorderRadius.circular(9)),
                  child: const Center(child: Text('Tutup',
                    style: TextStyle(fontFamily: _mono, fontSize: 11, color: Colors.white54)))))),
              const SizedBox(width: 8),
              Expanded(child: GestureDetector(
                onTap: () { Navigator.pop(context); _shareVpsTxt(info); },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF00AA55), Color(0xFF00FF88)]),
                    borderRadius: BorderRadius.circular(9),
                    boxShadow: [BoxShadow(color: _neon.withOpacity(0.3), blurRadius: 8)]),
                  child: const Center(child: Text('📤 Bagikan .txt',
                    style: TextStyle(fontFamily: _mono, fontSize: 11, color: Colors.black,
                      fontWeight: FontWeight.bold)))))),
            ]),
          ]),
        ),
      ),
    );
  }

  Future<void> _shareVpsTxt(Map<String, dynamic> info) async {
    try {
      final content = """
╔══════════════════════════════════════╗
          INFO VPS — ${(info['provider'] ?? '').toUpperCase()}
╚══════════════════════════════════════╝

📛 Nama VPS   : ${info['name'] ?? '-'}
🌐 Provider   : ${info['provider'] ?? '-'}
📍 Region     : ${info['region'] ?? '-'}
💻 Size/Plan  : ${info['size'] ?? '-'}
🐧 OS         : ${info['os'] ?? '-'}
📅 Dibuat     : ${info['createdAt'] ?? '-'}

══════════ AKSES SSH ══════════

🌍 IP Address  : ${info['ip'] ?? 'Cek List VPS 1-3 menit lagi'}
👤 Username    : ${info['sshUser'] ?? 'root'}
🔐 Password    : ${info['sshPass'] ?? '-'}
🔌 Port        : ${info['sshPort'] ?? 22}

Perintah SSH:
  ssh ${info['sshUser'] ?? 'root'}@<IP_VPS> -p ${info['sshPort'] ?? 22}

══════════ CATATAN ══════════

⚠️  IP aktif dalam 1-3 menit setelah dibuat
⚠️  Cek tab List VPS untuk mendapatkan IP terbaru
💡  Gunakan Termius / JuiceSSH untuk koneksi
🔒  Segera ganti password setelah login pertama!

══════════════════════════════════════
  Dibuat via Riff Base
══════════════════════════════════════
""".trim();

      final dir = await getTemporaryDirectory();
      final fname = 'vps_${info['name'] ?? 'info'}_${DateTime.now().millisecondsSinceEpoch}.txt'
        .replaceAll(RegExp(r'[^a-zA-Z0-9_.]'), '_');
      final file = File('${dir.path}/$fname');
      await file.writeAsString(content);

      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'text/plain')],
        subject: 'Info VPS ${info['name'] ?? ''}',
        text: 'Data VPS ${info['name'] ?? ''} dari Riff Base',
      );
    } catch (e) {
      if (mounted) setState(() => _err = 'Gagal share: \$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _bg,
    body: Stack(children: [
      Positioned(top: -60, right: -40, child: Container(width: 220, height: 220,
        decoration: BoxDecoration(shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: _red.withOpacity(0.1), blurRadius: 120, spreadRadius: 60)]))),
      SafeArea(child: Column(children: [
        _header(),
        _providerBar(),
        _tabBar(),
        if (_err != null) _banner(_err!, isErr: true),
        if (_ok  != null) _banner(_ok!,  isErr: false),
        Expanded(child: TabBarView(controller: _tabs, children: [
          _tabApiKey(),
          _tabList(),
          _tabCreate(),
        ])),
      ])),
    ]),
  );

  Widget _header() => Container(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: _acc.withOpacity(0.12)))),
    child: Row(children: [
      GestureDetector(onTap: () => Navigator.pop(context),
        child: Container(width: 36, height: 36,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.07),
            borderRadius: BorderRadius.circular(9), border: Border.all(color: Colors.white24)),
          child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 14))),
      const SizedBox(width: 12),
      const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('VPS MANAGER', style: TextStyle(fontFamily: _orb, fontSize: 14, color: Colors.white,
          letterSpacing: 2, shadows: [Shadow(color: Color(0xFF00FF88), blurRadius: 8)])),
        Text('DigitalOcean · Vultr · Linode', style: TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white38)),
      ]),
      const Spacer(),
      if (_loadingList || _savingKey || _creating)
        const SizedBox(width: 18, height: 18,
          child: CircularProgressIndicator(color: _neon, strokeWidth: 2)),
    ]),
  );

  Widget _providerBar() => SizedBox(
    height: 50,
    child: ListView(scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      children: VpsProvider.values.map((p) {
        final active = _prov == p;
        final hasKey = _hasSavedKey[p] == true;
        return GestureDetector(
          onTap: () => setState(() {
            _prov = p; _servers = []; _err = null; _ok = null;
            _regionCtrl.text = p.defRegion; _selectedPlan = null;
          }),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            decoration: BoxDecoration(
              color: active ? p.color.withOpacity(0.15) : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: active ? p.color : Colors.white.withOpacity(0.08))),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(p.icon, color: active ? p.color : Colors.white38, size: 13),
              const SizedBox(width: 6),
              Text(p.label, style: TextStyle(fontFamily: _mono, fontSize: 10,
                color: active ? p.color : Colors.white38)),
              if (hasKey) ...[const SizedBox(width: 5),
                Container(width: 6, height: 6,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: _neon,
                    boxShadow: [BoxShadow(color: _neon, blurRadius: 4)]))],
            ]),
          ),
        );
      }).toList()),
  );

  Widget _tabBar() => Container(
    margin: const EdgeInsets.fromLTRB(14, 0, 14, 4),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(10)),
    child: TabBar(controller: _tabs,
      indicator: BoxDecoration(color: _acc.withOpacity(0.18), borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _acc.withOpacity(0.45))),
      labelColor: _acc, unselectedLabelColor: Colors.white38,
      labelStyle: const TextStyle(fontFamily: _mono, fontSize: 10),
      tabs: const [Tab(text: '🔑  API Key'), Tab(text: '🖥  List VPS'), Tab(text: '➕  Buat VPS')],
    ),
  );

  Widget _banner(String msg, {required bool isErr}) {
    final c = isErr ? _acc : _neon;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 6, 14, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(color: c.withOpacity(0.09), borderRadius: BorderRadius.circular(10),
        border: Border.all(color: c.withOpacity(0.35))),
      child: Row(children: [
        Icon(isErr ? Icons.error_outline : Icons.check_circle_outline, color: c, size: 14),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: TextStyle(fontFamily: _mono, fontSize: 10, color: c))),
        GestureDetector(onTap: () => setState(() { _err = null; _ok = null; }),
          child: const Icon(Icons.close, color: Colors.white24, size: 13)),
      ]),
    );
  }

  // ── TAB 1: API KEY ───────────────────────────────────────────────
  Widget _tabApiKey() => ListView(
    padding: const EdgeInsets.all(14),
    children: [
      Container(padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: _gold.withOpacity(0.07), borderRadius: BorderRadius.circular(9),
          border: Border.all(color: _gold.withOpacity(0.3))),
        child: const Text(
          '🔒 API Key disimpan di server kita (terenkripsi per akun), tidak bocor ke pihak lain.',
          style: TextStyle(fontFamily: _mono, fontSize: 10, color: _gold))),
      const SizedBox(height: 14),
      ...VpsProvider.values.map(_keyCard),
    ],
  );

  Widget _keyCard(VpsProvider p) {
    final saved = _hasSavedKey[p] == true;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: saved ? p.color.withOpacity(0.4) : Colors.white.withOpacity(0.07))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(p.icon, color: p.color, size: 16),
          const SizedBox(width: 8),
          Text(p.label, style: TextStyle(fontFamily: _orb, fontSize: 12, color: p.color, letterSpacing: 1)),
          const Spacer(),
          if (saved) _badge('✅ Tersimpan', _neon) else _badge('Belum ada', Colors.white24),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _inputField(
            ctrl: _keyCtrl[p]!,
            hint: p.keyHint,
            obscure: _keyObscure[p]!,
            suffix: GestureDetector(
              onTap: () => setState(() => _keyObscure[p] = !_keyObscure[p]!),
              child: Icon(_keyObscure[p]! ? Icons.visibility_off : Icons.visibility,
                color: Colors.white38, size: 14)),
          )),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _savingKey ? null : () => _saveKey(p),
            child: Container(width: 42, height: 42,
              decoration: BoxDecoration(color: p.color.withOpacity(0.15), borderRadius: BorderRadius.circular(9),
                border: Border.all(color: p.color.withOpacity(0.4))),
              child: Icon(Icons.save_rounded, color: p.color, size: 18))),
        ]),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: () => _showGuide(p),
          child: Text('📖 Cara dapat API Key ${p.label} →',
            style: TextStyle(fontFamily: _mono, fontSize: 9, color: p.color.withOpacity(0.7),
              decoration: TextDecoration.underline, decorationColor: p.color.withOpacity(0.4)))),
      ]),
    );
  }

  void _showGuide(VpsProvider p) => showModalBottomSheet(
    context: context, backgroundColor: const Color(0xFF111111),
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
    builder: (_) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(p.icon, color: p.color, size: 18), const SizedBox(width: 8),
          Text('Cara dapat API Key ${p.label}', style: TextStyle(fontFamily: _orb, fontSize: 12, color: p.color))]),
        const SizedBox(height: 14),
        Container(width: double.infinity, padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(10)),
          child: Text(p.guide, style: const TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white70, height: 2.0))),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: p.color,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(fontFamily: _mono, color: Colors.white)))),
      ]),
    ));

  // ── TAB 2: LIST VPS ──────────────────────────────────────────────
  Widget _tabList() => Column(children: [
    Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      child: Row(children: [
        Icon(_prov.icon, color: _prov.color, size: 13),
        const SizedBox(width: 6),
        Text('${_servers.length} VPS · ${_prov.label}',
          style: const TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white38)),
        const Spacer(),
        GestureDetector(onTap: _fetchServers,
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(color: _neon.withOpacity(0.1), borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _neon.withOpacity(0.3))),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.refresh_rounded, color: _neon, size: 13),
              SizedBox(width: 5),
              Text('Load', style: TextStyle(fontFamily: _mono, fontSize: 10, color: _neon)),
            ]))),
      ]),
    ),
    Expanded(child: _loadingList
      ? const Center(child: CircularProgressIndicator(color: _neon, strokeWidth: 2))
      : _servers.isEmpty
        ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.dns_outlined, color: Colors.white.withOpacity(0.12), size: 48),
            const SizedBox(height: 10),
            const Text('Tekan Load untuk ambil list VPS',
              style: TextStyle(fontFamily: _mono, fontSize: 11, color: Colors.white24)),
            const SizedBox(height: 14),
            GestureDetector(onTap: _fetchServers,
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(color: _neon.withOpacity(0.1), borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _neon.withOpacity(0.3))),
                child: const Text('🔄  Load VPS', style: TextStyle(fontFamily: _mono, fontSize: 11, color: _neon)))),
          ]))
        : ListView.builder(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 20),
            itemCount: _servers.length,
            itemBuilder: (_, i) => _vpsCard(_servers[i]))),
  ]);

  Widget _vpsCard(Map<String, dynamic> s) {
    final sc = _statusColor(s['status'] ?? '');
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: sc.withOpacity(0.2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          AnimatedContainer(duration: const Duration(milliseconds: 400),
            width: 8, height: 8,
            decoration: BoxDecoration(shape: BoxShape.circle, color: sc,
              boxShadow: [BoxShadow(color: sc, blurRadius: 6)])),
          const SizedBox(width: 8),
          Expanded(child: Text(s['name'] ?? '-',
            style: const TextStyle(fontFamily: _orb, fontSize: 12, color: Colors.white, letterSpacing: 0.5))),
          _badge(s['status'] ?? '-', sc),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _deleteVps(s['id'], s['name']),
            child: Container(width: 30, height: 30,
              decoration: BoxDecoration(color: _acc.withOpacity(0.1), borderRadius: BorderRadius.circular(7),
                border: Border.all(color: _acc.withOpacity(0.3))),
              child: const Icon(Icons.delete_outline, color: _acc, size: 14))),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _chip(Icons.computer, s['vcpu'] ?? '-')),
          const SizedBox(width: 6),
          Expanded(child: _chip(Icons.memory, s['ram'] ?? '-')),
          const SizedBox(width: 6),
          Expanded(child: _chip(Icons.storage, s['disk'] ?? '-')),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          const Icon(Icons.location_on_outlined, size: 11, color: Colors.white38),
          const SizedBox(width: 4),
          Text(s['region'] ?? '-', style: const TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white38)),
          const Spacer(),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: s['ip'] ?? ''));
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('IP disalin!', style: TextStyle(fontFamily: _mono, fontSize: 11)),
                backgroundColor: Color(0xFF1A1A1A), duration: Duration(seconds: 1)));
            },
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Text(s['ip'] ?? '-', style: const TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white70)),
              const SizedBox(width: 4),
              const Icon(Icons.copy, size: 11, color: Colors.white24),
            ])),
        ]),
      ]),
    );
  }

  // ── TAB 3: BUAT VPS ─────────────────────────────────────────────
  Widget _tabCreate() => ListView(
    padding: const EdgeInsets.all(14),
    children: [
      Container(padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: _prov.color.withOpacity(0.08), borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _prov.color.withOpacity(0.3))),
        child: Row(children: [
          Icon(_prov.icon, color: _prov.color, size: 16),
          const SizedBox(width: 8),
          Text('Buat VPS di ${_prov.label}',
            style: TextStyle(fontFamily: _mono, fontSize: 11, color: _prov.color)),
          const Spacer(),
          if (_hasSavedKey[_prov] != true)
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: _acc.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
              child: const Text('API Key belum ada', style: TextStyle(fontFamily: _mono, fontSize: 9, color: _acc))),
        ])),
      const SizedBox(height: 14),

      _label('Nama VPS'),
      _inputField(ctrl: _nameCtrl, hint: 'contoh: vps-prod-sg'),
      const SizedBox(height: 12),

      _label('Region'),
      _inputField(ctrl: _regionCtrl, hint: _prov.defRegion),
      Padding(padding: const EdgeInsets.only(top: 4),
        child: Text(_prov.regionHint, style: const TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white24))),
      const SizedBox(height: 12),

      _label('Pilih Spek VPS'),
      _specSelector(),
      const SizedBox(height: 12),

      _label('Sistem Operasi'),
      _osSelector(),
      const SizedBox(height: 12),

      _label('Password SSH (opsional)'),
      _inputField(
        ctrl: _sshPassCtrl,
        hint: 'Kosongkan untuk auto-generate',
        obscure: _sshObscure,
        suffix: GestureDetector(
          onTap: () => setState(() => _sshObscure = !_sshObscure),
          child: Icon(_sshObscure ? Icons.visibility_off : Icons.visibility,
            color: Colors.white38, size: 14))),
      Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text('Min 8 karakter · huruf + angka + simbol',
          style: const TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white24))),

      const SizedBox(height: 20),

      GestureDetector(
        onTap: _creating ? null : _createVps,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            gradient: _creating
              ? LinearGradient(colors: [Colors.white.withOpacity(0.12), Colors.white.withOpacity(0.12)])
              : const LinearGradient(colors: [Color(0xFFB22222), Color(0xFFFF4444)]),
            borderRadius: BorderRadius.circular(12),
            boxShadow: _creating ? [] : [BoxShadow(color: _acc.withOpacity(0.35), blurRadius: 14)]),
          child: Center(child: _creating
            ? const Row(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(width: 14, height: 14, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                SizedBox(width: 10),
                Text('Membuat VPS...', style: TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white)),
              ])
            : const Text('🚀  BUAT VPS SEKARANG',
                style: TextStyle(fontFamily: _orb, fontSize: 12, color: Colors.white, letterSpacing: 1))),
        ),
      ),
      const SizedBox(height: 20),
    ],
  );

  // ── SHARED WIDGETS ───────────────────────────────────────────────
  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(t, style: const TextStyle(fontFamily: _mono, fontSize: 10, color: Colors.white38, letterSpacing: 1)));

  Widget _inputField({required TextEditingController ctrl, String hint='', bool obscure=false, Widget? suffix}) =>
    Container(
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(9),
        border: Border.all(color: Colors.white.withOpacity(0.1))),
      child: TextField(controller: ctrl, obscureText: obscure,
        style: const TextStyle(fontFamily: _mono, fontSize: 12, color: Colors.white),
        decoration: InputDecoration(hintText: hint,
          hintStyle: const TextStyle(fontFamily: _mono, fontSize: 11, color: Colors.white24),
          suffixIcon: suffix, border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13))));

  Widget _badge(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
    decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(6),
      border: Border.all(color: color.withOpacity(0.35))),
    child: Text(label, style: TextStyle(fontFamily: _mono, fontSize: 9, color: color)));

  Widget _chip(IconData icon, String val) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(7)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 10, color: Colors.white38),
      const SizedBox(width: 4),
      Flexible(child: Text(val, style: const TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white54))),
    ]));

  Widget _specSelector() {
    final plans = _prov.specPlans;
    return Column(children: [
      // Grid 1 kolom — card per plan
      ...plans.map((plan) {
        final active = _selectedPlan?['slug'] == plan['slug'];
        return GestureDetector(
          onTap: () => setState(() => _selectedPlan = plan),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: BoxDecoration(
              color: active ? _acc.withOpacity(0.12) : Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(
                color: active ? _acc : Colors.white.withOpacity(0.08),
                width: active ? 1.5 : 1),
              boxShadow: active ? [BoxShadow(color: _acc.withOpacity(0.2), blurRadius: 10)] : [],
            ),
            child: Row(children: [
              // Radio dot
              Container(width: 18, height: 18,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: active ? _acc : Colors.white24, width: 2),
                  color: active ? _acc : Colors.transparent),
                child: active ? const Icon(Icons.check, size: 11, color: Colors.white) : null),
              const SizedBox(width: 12),
              // Label
              Text(plan['label']!,
                style: TextStyle(fontFamily: _orb, fontSize: 11,
                  color: active ? _acc : Colors.white70, letterSpacing: 0.5)),
              const SizedBox(width: 10),
              // Specs
              Expanded(child: Row(children: [
                _specChip(Icons.memory,    plan['ram']!),
                const SizedBox(width: 5),
                _specChip(Icons.computer,  plan['cpu']!),
                const SizedBox(width: 5),
                _specChip(Icons.storage,   plan['disk']!),
              ])),
              // Harga
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: active ? _acc.withOpacity(0.15) : Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(6)),
                child: Text(plan['price']!,
                  style: TextStyle(fontFamily: _mono, fontSize: 9,
                    color: active ? _acc : Colors.white38, fontWeight: FontWeight.bold))),
            ]),
          ),
        );
      }),
    ]);
  }

  Widget _specChip(IconData icon, String val) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(5)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 9, color: Colors.white38),
      const SizedBox(width: 3),
      Text(val, style: const TextStyle(fontFamily: _mono, fontSize: 9, color: Colors.white54)),
    ]));

  Widget _osSelector() {
    const opts = [
      {'slug':'ubuntu-22-04-x64','label':'Ubuntu 22.04'},
      {'slug':'ubuntu-20-04-x64','label':'Ubuntu 20.04'},
      {'slug':'debian-11-x64',   'label':'Debian 11'},
    ];
    return Row(children: opts.map((o) {
      final active = _osSlug == o['slug'];
      return Expanded(child: GestureDetector(
        onTap: () => setState(() => _osSlug = o['slug']!),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.only(right: 6),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? _acc.withOpacity(0.15) : Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: active ? _acc : Colors.white.withOpacity(0.08))),
          child: Text(o['label']!, textAlign: TextAlign.center,
            style: TextStyle(fontFamily: _mono, fontSize: 9, color: active ? _acc : Colors.white38)),
        )));
    }).toList());
  }
}
